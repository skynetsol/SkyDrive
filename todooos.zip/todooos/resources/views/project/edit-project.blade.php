@extends('layouts.authprojectwleft')
@section('pageTitle')
Edit project
@stop
@section('styles')
@stop
@section('content')
<form method="post" action="" id="frmeditproject">
  @csrf
  <div class="inviteTab">
  <div class="m-5">
    <div class="form-group">
        <input type="text" id="pprojectname" name="pprojectname" value="{{$project->projectname}}" class="form-control" placeholder="Type your project name." readonly>
    </div>
    <div class="form-group">
        <textarea rows="4" id="projectdescription" name="projectdescription" class="form-control" placeholder="Type your project description here.">{{$project->projectdescription}}</textarea>
    </div>
  </div>
    <ul class="nav nav-tabs" id="myTab" role="tablist">
      <li class="nav-item">
        <a class="nav-link active" id="team-tab" data-toggle="tab" href="#ourTeam" role="tab" aria-controls="home"
          aria-selected="true">Our Team <i class="fa"></i></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="client-tab" data-toggle="tab" href="#theClient" role="tab" aria-controls="profile"
          aria-selected="false">The Client <i class="fa"></i></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="estimate-tab" data-toggle="tab" href="#estimate" role="tab" aria-controls="estimate"
        aria-selected="false">Estimate <i class="fa"></i></a>
      </li>
    </ul>
    <div class="tab-content" id="myTabContent">
      <div class="tab-pane fade show active" id="ourTeam" role="tabpanel" aria-labelledby="team-tab">
        <div class="row">
          <div class="col-md-6 inviteBorder">
            <div class="m-5">
              <div class="form-group m-4">
                <h5>Type names or emails to invite people to your team:</h5>
                <select class="js-example-basic-single"  name="email[]" id="email" multiple>
                  <option value="">Select User</option>
                    @if(count($users) > 0 ) 
                      @foreach($users as $user) 
                      <option value="{{ $user->email }}">{{ $user->firstname." ".$user->lastname }}</option>
                      @endforeach 
                    @endif
                </select>
              </div>
              <div class="form-group">
                <h5>Add a welcome message for your team:</h5>
                <textarea rows="4" class="form-control" id="mailtext" name="mailtext" placeholder="Hi, there. We'll be using todooos to share ideas, gather feedback, and track progress during this project."></textarea>
              </div>
            </div>
          </div>
          <div class="col-md-6 inviteBorder2">
            <p>Anyone on your team will see everything posted to this project. Every message, todo-list, file, event, and text document.</p>
            @if(count($inviteusers) > 0)
              @foreach($inviteusers as $inviteuser)
                @if($inviteuser->invitetype == 'T')
                <div class="media meProfile inviteMedia" id="invitediv-{!! $inviteuser->inviteid !!}"> 
                  @if($inviteuser->profilepic != '' && file_exists('public/img/profile_img/thum/'.$inviteuser->profilepic)) 
                    <img class="meProfileImg" src="{{ URL::asset('img/profile_img/thum/'.$inviteuser->profilepic) }}" alt="{{ $inviteuser->firstname ." ".$inviteuser->lastname }}"> 
                  @else 
                    <img class="meProfileImg" src="{{ URL::asset('img/profileImg') }}" alt="{{ $inviteuser->firstname ." ".$inviteuser->lastname }}">                        
                  @endif 
                  <div class="media-body">
                    <h5 class="mt-0">{{ $inviteuser->firstname ." ".$inviteuser->lastname }}</h5>
                    <p>{{ $inviteuser->email }}</p>
                    <div>
                      @if($companyInfo->created_by == Auth::user()->id)
                        @if($inviteuser->inviteuserid != $companyInfo->created_by)
                          <div class="form-check form-check-inline">
                            <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                            <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                          </div>
                        @endif
                      @elseif(in_array("2",$companyInfo->user_type))
                        @if($inviteuser->inviteuserid == Auth::user()->id || $inviteuser->inviteuserid == $companyInfo->created_by)
                        @else
                          <div class="form-check form-check-inline">
                            <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                            <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                          </div>
                        @endif
                      @elseif(in_array("1",$companyInfo->user_type))
                        @if($inviteuser->inviteuserid != Auth::user()->id)  
                        <div class="form-check form-check-inline">
                          <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                          <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                        </div>
                        @endif
                      @endif
                    </div>
                  </div>
                </div>
                @endif
              @endforeach
            @endif    
          </div>
        </div>
      </div>
      <div class="tab-pane fade" id="theClient" role="tabpanel" aria-labelledby="client-tab">
        <div class="m-5" {!! ($totalinviteclient == 0 ? '' : 'style="display:none;"') !!} id="withoutclientlist">
          <div class="row">
            <div class="col-md-6">
              <div class="m-5">
                <h3>Working with a client on this project?</h3>
                <p>Todooos lets you hide certain messages, to-dos, files, events, and text documents from people
                  invited as clients. This is great for sharing unfinished work with your team before getting
                  client feedback.</p>

                <p>You can turn this on now to start choosing what clients can see, even if you’re not ready to
                  invite any clients yet.</p>
                <a style="cursor:pointer;" class="btn btn-primary noLinkButton" id="showTrigger-{!! $project->projectid !!}">Yes, turn on client access for this project</a>

              </div>
            </div>
            <div class="col-md-6">
              <div class="circleImg"><img src="{{ URL::asset('public/img/circleimg.jpg')}}" alt=""></div>
            </div>
          </div>
        </div>

        <div class="row" {!! ($totalinviteclient == 0  ? 'style="display:none;"' : '') !!} id="withclientlist">
          <div class="col-md-6 inviteBorder">
            <div class="m-5">
              <div class="form-group m-4">
                <h5>Type names or emails to invite people from your clients:</h5>
                <select class="js-example-basic-single"  name="cemail[]" id="cemail" multiple>
                  <option value="">Select User</option>
                    @if(count($users) > 0 ) 
                    @foreach($users as $user) 
                      <option value="{{ $user->email }}">{{ $user->firstname." ".$user->lastname }}</option>
                    @endforeach 
                    @endif
                </select>
              </div>

              <div class="form-group">
                <h5>Add a welcome message for your clients:</h5>
                <textarea rows="4" class="form-control" id="mailtext" name="mailtext" placeholder="Hi, there. We'll be using todooos to share ideas, gather feedback, and track progress during this project."></textarea>
              </div>
            </div>
          </div>
          <div class="col-md-6 inviteBorder2">
            <p>Anyone from your clients will see certain messages, to-dos, files, events, and text documents that you allow them to see.</p>
            @if(count($inviteusers) > 0)
              @foreach($inviteusers as $inviteuser)
                @if($inviteuser->invitetype == 'C')
                <div class="media meProfile inviteMedia" id="invitediv-{!! $inviteuser->inviteid !!}"> 
                  @if($inviteuser->profilepic != '' && file_exists('public/img/profile_img/thum/'.$inviteuser->profilepic)) 
                    <img class="meProfileImg" src="{{ URL::asset('img/profile_img/thum/'.$inviteuser->profilepic) }}" alt="{{ $inviteuser->firstname ." ".$inviteuser->lastname }}"> 
                  @else 
                    <img class="meProfileImg" src="{{ URL::asset('public/img/profileImg') }}" alt="{{ $inviteuser->firstname ." ".$inviteuser->lastname }}">                        
                  @endif 
                  <div class="media-body">
                    <h5 class="mt-0">{{ $inviteuser->firstname ." ".$inviteuser->lastname }}</h5>
                    <p>{{ $inviteuser->email }}</p>
                    <div>
                      @if($companyInfo->created_by == Auth::user()->id)
                        @if($inviteuser->inviteuserid != $companyInfo->created_by)
                          <div class="form-check form-check-inline">
                            <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                            <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                          </div>
                        @endif
                      @elseif(in_array("2",$companyInfo->user_type))
                        @if($inviteuser->inviteuserid == Auth::user()->id || $inviteuser->inviteuserid == $companyInfo->created_by)
                        @else
                          <div class="form-check form-check-inline">
                            <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                            <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                          </div>
                        @endif
                      @elseif(in_array("1",$companyInfo->user_type))
                        @if($inviteuser->inviteuserid != Auth::user()->id)  
                        <div class="form-check form-check-inline">
                          <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                          <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                        </div>
                        @endif
                      @endif
                    </div>
                  </div>
                </div>
                @endif
              @endforeach
            @endif
          </div>
        </div>
      </div>
      <div class="tab-pane fade" id="estimate" role="tabpanel" aria-labelledby="estimate-tab">
          <div class="row">
              <div class="col-md-3 inviteBorder">
                  <div class="m-5">
                      <h3>Rates</h3>
                      <div class="form-group m-4">
                          <h5>Client</h5>
                          <select class="js-example-basic-clientname" name="clientname" id="clientname">
                              @if(count($users) > 0 ) 
                                  <option value=""></option>
                                  @foreach($users as $user) 
                                      <option value="{{ $user->userid }}">{{ $user->firstname." ".$user->lastname }}</option>
                                  @endforeach 
                              @endif
                          </select>
                      </div>
                      <div class="form-group m-4">
                          <h5>Billing Method</h5>
                          <select class="js-example-basic-bmethod" name="billingmethod" id="billingmethod">
                              <option value=""></option>
                              <option value="1">Flat Project Amount</option>
                              <option value="2">Hourly Project Rate</option>
                              <option value="3">Hourly Task Rate</option>
                              <option value="4">Hourly Staff Rate</option>
                          </select>
                      </div>
                      <div class="form-group m-4" id="divaddps">
                          <div class="float-right">
                              <div class="input-group">
                                  <input type="button" class="btn btn-primary" value="Add" id="addps">
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-md-9 inviteBorder2">
                  <div id="estimatelist">
                  <div id="flatprojectrate" {!! ($project->estimatecost == 0.00 ? "style='display:none;'": "")!!}>
                          <h3>Flat Project Cost</h3>
                          <div class="form-group m-5">
                              <div class="d-flex row flex-row bd-highlight mb-3">
                                  <div class="col-md-4 align-self-center">
                                      <p class="m-0">Cost for this project</p>
                                  </div>
                                  <div class="col-md-5">
                                      <div class="input-group">
                                          <input type="text" name="estimatecost" id="estimatecost" value="{!! ($project->estimatecost != 0.00 ? $project->estimatecost : "")!!}" class="form-control decimal" aria-describedby="basic-addon2">
                                          <div class="input-group-append">
                                              <span class="input-group-text" id="basic-addon2"> $ </span>
                                          </div>
                                      </div>
                                  </div>
                                  <div class="col-md-1 align-self-center text-center">
                                      <p class='m-0' id="hourlyflattotal">{!! ($project->estimatecost != 0.00 ? "$".$project->estimatecost: "$0.00")!!}</p>
                                  </div>
                                  <div class="col-md-2 align-self-center">
                                      <p class="m-0"><a id="deletebm-1" style="cursor:pointer;" class="text-danger"><i class="fas fa-minus-circle"></i>
                                              Remove</a></p>
                                  </div>
                              </div>
                          </div>
                          <hr>    
                      </div>
                      
                      <div id="hourlyprojectrate" {!!($project->projecthour != '0.00' ? '': 'style="display:none;"')!!}>
                          <h3>Hourly Project Cost</h3>
                          <div class="form-group m-4">
                              <div class="d-flex row flex-row bd-highlight mb-3">
                                  <div class="col-md-4">
                                      <div class="input-group">
                                          <input type="text" name="projectrate" id="projectrate" value="{!! ($project->projectrate != 0.00 ? $project->projectrate : "")!!}" class="form-control decimal" aria-describedby="basic-addon2">
                                          <div class="input-group-append">
                                              <span class="input-group-text" id="basic-addon2">$ per hour </span>
                                          </div>
                                      </div>
                                  </div>
                                  <div class="col-md-1 align-self-center text-center">
                                      <p class="m-0">for</p>
                                  </div>
                                  <div class="col-md-4">
                                      <div class="input-group">
                                          <input type="text" name="projecthour" id="projecthour" value="{!! ($project->projecthour != 0.00 ? $project->projecthour : "")!!}" class="form-control decimal" aria-describedby="basic-addon2">
                                          <div class="input-group-append">
                                              <span class="input-group-text" id="basic-addon2">hours </span>
                                          </div>
                                      </div>
                                  </div>
                                  <div class="col-md-1 align-self-center text-center">
                                      <p class='m-0' id="hourlyprojecttotal">${!!($project->projectrate!= 0.00 && $project->projecthour != 0.00  ? $project->projectrate * $project->projecthour:'0.00') !!}</p>
                                  </div>
                                  <div class="col-md-2 align-self-center">
                                      <p class="m-0"><a id="deletebm-2" style="cursor:pointer;" class="text-danger"><i class="fas fa-minus-circle"></i>
                                              Remove</a></p>
                                  </div>
                              </div>
                          </div>
                          <hr>
                      </div>
                      @if(isset($projectestimates) && count($projectestimates) > 0)
                      <div id="hourlytaskrate">
                          <h3>Hourly Task Cost</h3>
                          <div id="hourlytaskratelist">
                              @foreach($projectestimates as $projectestimate)
                              @if($projectestimate->estimatetype == 'T')
                              <div class="form-group m-4" id="taskdiv-{!! $projectestimate->entityid!!}">
                                  <div class="d-flex row flex-row bd-highlight mb-3">
                                      <div class="col-md-2 align-self-center">
                                          <p class="m-0">{!! $projectestimate->entityname!!}</p>
                                      </div>
                                      <div class="col-md-3">
                                          <div class="input-group">
                                            <input type="text" name="taskrate[]" id="taskrate-{!! $projectestimate->entityid!!}"
                                                  class="form-control decimal" aria-describedby="basic-addon2" value="{!! $projectestimate->rate!!}">
                                              <div class="input-group-append"><span class="input-group-text" id="basic-addon2">$ per hour</span></div>
                                          </div>
                                      </div>
                                      <div class="col-md-1 align-self-center">
                                          <p class="m-0">for</p>
                                      </div>
                                      <div class="col-md-3">
                                          <div class="input-group">
                                                  <input type="text" name="taskhour[]" id="taskhour-{!! $projectestimate->entityid!!}" class="form-control decimal" value="{!! $projectestimate->hours!!}">
                                                  <input type="hidden" name="task_id[]" value="{!! $projectestimate->entityid!!}">
                                              <div class="input-group-append"><span class="input-group-text" id="basic-addon2">hours</span></div>
                                          </div>
                                      </div>
                                      <div class="col-md-1 align-self-center">
                                          <p class="m-0" id="tasklinetotal-{!! $projectestimate->entityid!!}">${!! $projectestimate->linetotalformat!!}</p>
                                      </div>
                                      <div class="col-md-2 align-self-center">
                                          <p class="m-0"><a id="deletetask-{!! $projectestimate->entityid!!}" style="cursor:pointer;" class="text-danger"><i
                                                      class="fas fa-minus-circle"></i> Remove</a></p>
                                      </div>
                                  </div>
                              </div>
                              @endif
                              @endforeach
                          </div>
                          <div class="form-group m-4">
                              <div class="d-flex row flex-row bd-highlight mb-3">
                                  <div class="col-md-5">
                                      <select class="js-example-basic-task" name="taskid" id="taskid">
                                          <option value=""></option>
                                          @if(count($tasks) > 0 ) 
                                              <option value=""></option>
                                              @foreach($tasks as $task) 
                                                  <option value="{{ $task->taskid }}">{{ $task->taskname }}</option>
                                              @endforeach 
                                          @endif
                                      </select>
                                  </div>
                                  <div class="col-md-2 align-self-center text-center">
                                      <p class="m-0"><a id="addtask" style="cursor:pointer;"><i class="fas fa-plus-circle"></i> Add</a></p>
                                  </div>
                                  <div class="col-md-3 align-self-center">
                                      <p class="m-0"><a id="removealltask" style="cursor:pointer;" class="text-danger"><i class="fas fa-minus-circle"></i> Remove all task</a></p>
                                  </div>
                                  <div class="col-md-2 align-self-center">
                                      <p class="m-0"><a id="deletebm-3" style="cursor:pointer;" style="cursor:pointer;" class="text-danger"><i class="fas fa-minus-circle"></i> Remove</a></p>
                                  </div>
                              </div>
                          </div>
                          <hr>
                      </div>
                      @else
                      <div id="hourlytaskrate" style="display:none;">
                        <h3>Hourly Task Cost</h3>
                          <div id="hourlytaskratelist"></div>
                          <div class="form-group m-4">
                              <div class="d-flex row flex-row bd-highlight mb-3">
                                  <div class="col-md-5">
                                      <select class="js-example-basic-task" name="taskid" id="taskid">
                                          <option value=""></option>
                                          @if(count($tasks) > 0 ) 
                                              <option value=""></option>
                                              @foreach($tasks as $task) 
                                                  <option value="{{ $task->taskid }}">{{ $task->taskname }}</option>
                                              @endforeach 
                                          @endif
                                      </select>
                                  </div>
                                  <div class="col-md-2 align-self-center text-center">
                                      <p class="m-0"><a id="addtask" style="cursor:pointer;"><i class="fas fa-plus-circle"></i> Add</a></p>
                                  </div>
                                  <div class="col-md-3 align-self-center">
                                      <p class="m-0"><a id="removealltask" style="cursor:pointer;" class="text-danger"><i class="fas fa-minus-circle"></i> Remove all task</a></p>
                                  </div>
                                  <div class="col-md-2 align-self-center">
                                      <p class="m-0"><a id="deletebm-3" style="cursor:pointer;" style="cursor:pointer;" class="text-danger"><i class="fas fa-minus-circle"></i> Remove</a></p>
                                  </div>
                              </div>
                          </div>
                          <hr>
                      </div>
                      @endif
                      @if(isset($projectestimates) && count($projectestimates) > 0)
                      <div id="hourlystaffrate">
                          <h3>Hourly Staff Cost</h3>
                          <div id="hourlystaffratelist">
                              @foreach($projectestimates as $projectestimate)
                              @if($projectestimate->estimatetype == 'U')
                              <div class="form-group m-4" id="staffdiv-{!! $projectestimate->entityid!!}">
                                  <div class="d-flex row flex-row bd-highlight mb-3">
                                      <div class="col-md-2 align-self-center">
                                          <p class="m-0">{!! $projectestimate->entityname!!}</p>
                                      </div>
                                      <div class="col-md-3">
                                          <div class="input-group">
                                            <input type="text" name="staffrate[]" id="staffrate-{!! $projectestimate->entityid!!}"
                                                  class="form-control decimal" aria-describedby="basic-addon2" value="{!! $projectestimate->rate!!}">
                                              <div class="input-group-append"><span class="input-group-text" id="basic-addon2">$ per hour</span></div>
                                          </div>
                                      </div>
                                      <div class="col-md-1 align-self-center">
                                          <p class="m-0">for</p>
                                      </div>
                                      <div class="col-md-3">
                                          <div class="input-group">
                                                  <input type="text" name="staffhour[]" id="staffhour-{!! $projectestimate->entityid!!}" class="form-control decimal" value="{!! $projectestimate->hours!!}">
                                                  <input type="hidden" name="staff_id[]" value="{!! $projectestimate->entityid!!}">
                                              <div class="input-group-append"><span class="input-group-text" id="basic-addon2">hours</span></div>
                                          </div>
                                      </div>
                                      <div class="col-md-1 align-self-center">
                                          <p class="m-0" id="stafflinetotal-{!! $projectestimate->entityid!!}">${!! $projectestimate->linetotalformat!!}</p>
                                      </div>
                                      <div class="col-md-2 align-self-center">
                                          <p class="m-0"><a id="deletestaff-{!! $projectestimate->entityid!!}" style="cursor:pointer;" class="text-danger"><i
                                                      class="fas fa-minus-circle"></i> Remove</a></p>
                                      </div>
                                  </div>
                              </div>
                              @endif
                              @endforeach
                          </div>
                          <div class="form-group m-4">
                              <div class="d-flex row flex-row bd-highlight mb-3">
                                  <div class="col-md-5">
                                      <select class="js-example-basic-staff" name="staffid" id="staffid">
                                          <option value=""></option>
                                          @if(count($users) > 0 ) 
                                              <option value=""></option>
                                              @foreach($users as $user) 
                                                  <option value="{{ $user->userid }}">{{ $user->firstname." ".$user->lastname }}</option>
                                              @endforeach 
                                          @endif
                                      </select>
                                  </div>
                                  <div class="col-md-2 align-self-center text-center">
                                      <p class="m-0"><a id="addstaff" style="cursor:pointer;"><i class="fas fa-plus-circle"></i> Add</a></p>
                                  </div>
                                  <div class="col-md-3 align-self-center">
                                      <p class="m-0"><a id="removeallstaff" style="cursor:pointer;" class="text-danger"><i class="fas fa-minus-circle"></i> Remove all staff</a></p>
                                  </div>
                                  <div class="col-md-2 align-self-center">
                                      <p class="m-0"><a id="deletebm-3" style="cursor:pointer;" style="cursor:pointer;" class="text-danger"><i class="fas fa-minus-circle"></i> Remove</a></p>
                                  </div>
                              </div>
                          </div>
                          <hr>
                      </div>
                      @else
                      <div id="hourlystaffrate" style="display:none;">
                        <h3>Hourly staff Cost</h3>
                          <div id="hourlystaffratelist"></div>
                          <div class="form-group m-4">
                              <div class="d-flex row flex-row bd-highlight mb-3">
                                  <div class="col-md-5">
                                      <select class="js-example-basic-staff" name="staffid" id="staffid">
                                          <option value=""></option>
                                          @if(count($users) > 0 ) 
                                            <option value=""></option>
                                            @foreach($users as $user) 
                                                <option value="{{ $user->userid }}">{{ $user->firstname." ".$user->lastname }}</option>
                                            @endforeach 
                                        @endif
                                      </select>
                                  </div>
                                  <div class="col-md-2 align-self-center text-center">
                                      <p class="m-0"><a id="addstaff" style="cursor:pointer;"><i class="fas fa-plus-circle"></i> Add</a></p>
                                  </div>
                                  <div class="col-md-3 align-self-center">
                                      <p class="m-0"><a id="removeallstaff" style="cursor:pointer;" class="text-danger"><i class="fas fa-minus-circle"></i> Remove all staff</a></p>
                                  </div>
                                  <div class="col-md-2 align-self-center">
                                      <p class="m-0"><a id="deletebm-3" style="cursor:pointer;" style="cursor:pointer;" class="text-danger"><i class="fas fa-minus-circle"></i> Remove</a></p>
                                  </div>
                              </div>
                          </div>
                          <hr>
                      </div>
                      @endif
                      <div id="estimatetotal" {!!($project->totalestimatecost != '0.00' ? '': 'style="display:none;"')!!}>
                          <div class="form-group m-4">
                            <div class="d-flex row flex-row bd-highlight mb-3">
                                <div class="col-md-9 align-self-center float-left">
                                  <h3>Total Estimate Cost</h3>
                                </div>
                                <div class="col-md-3 align-self-center float-right">
                                    <h3 id="estimatecost">${!! ($project->totalestimatecost != '' ? $project->totalestimatecost : '0.00' ) !!}</h3>
                                </div>
                            </div>
                        </div>
                        <hr>
                      </div>
                  </div>
              </div>
          </div>
        </div>
      </div>
      <div class="form-group">
            <input type="hidden" name="companyid" id="companyid" value="{!! $companyInfo->companyid !!}">
            <input type="hidden" name="projectid" id="projectid" value="{!! $project->projectid !!}">
            <input type="hidden" name="created_byproject" id="created_byproject" value="{!! Auth::user()->id !!}">
            <input type="submit" class="btn btn-primary" value="Submit" id="submitproject">
            <input type="hidden" value="{!! ($project->totalestimatecost != '0.00' ? $project->totalestimatecost : '0.00' ) !!}" id="totalestimatecost" name="totalestimatecost">
            <input type="hidden" value="{!! Auth::user()->id !!}" id="created_by" name="created_by">
            <input type="hidden" name="timezone" id="timezone" value="">
      </div>
      <div id="msgdivproject" class=""></div>
    </div>
</form>
@stop() 
@section('scripts')
{!! Html::script('js/jstz.js') !!}
<script>
    var tz = jstz.determine();
    uid = "{{Auth::user()->id}}";
    var pid = "{{$project->projectid}}";
    var psn = "{{$project->seoname}}";
</script>
{!! Html::script('js/editproject.js') !!}
@stop
