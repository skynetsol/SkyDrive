
@if($listingtype == 1)
@if(count($projectfiles) > 0) @foreach($projectfiles as $projectfile)
<div class="col-sm-6 col-md-4 col-lg-4 col-xl-3">
    <div class="card fileType text-center">
        @if($projectfile->filetypes == 'image')
            @if($projectfile->filenewname!='' && file_exists('public/img/comment_files/'.$projectfile->foldername.'/list/'.$projectfile->filenewname))
                <div class="fileTypeImg">
                    <a title="{{ $projectfile->fname}}" href="{!! URL::to('/download/'.$projectfile->foldername.'/'.base64_encode($projectfile->filenewname)) !!}">
                    <img src="{{ URL::asset('img/comment_files/'.$projectfile->foldername.'/list/'.$projectfile->filenewname) }}"
                            alt="{{ $projectfile->created_by}}">
                    </a>
                </div>
            @else
            <div class="fileTypeImg">
                @if($projectfile->fileextension!='' && file_exists('public/img/iconimg/'.$projectfile->fileextension.'.png'))
                    <img src="{{ URL::asset('img/iconimg/'.$projectfile->fileextension.'.png') }}" alt=""> 
                @else
                    <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> 
                @endif
            </div>
            @endif
        @elseif($projectfile->filetypes == 'other')
            @if($projectfile->filenewname!='' && file_exists('public/img/comment_files/'.$projectfile->foldername.'/'.$projectfile->filenewname))
            <div class="fileTypeImg">
                <a title="{{ $projectfile->fname}}" href="{!! URL::to('/download/'.$projectfile->foldername.'/'.base64_encode($projectfile->filenewname)) !!}">
                    @if($projectfile->fileextension!='' && file_exists('public/img/iconimg/'.$projectfile->fileextension.'.png'))
                        <img src="{{ URL::asset('img/iconimg/'.$projectfile->fileextension.'.png') }}" alt=""> 
                    @else
                        <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> 
                    @endif
                </a>
            </div>
            @else
            <div class="fileTypeImg" title="{{ $projectfile->fname}}">
                @if($projectfile->fileextension!='' && file_exists('public/img/iconimg/'.$projectfile->fileextension.'.png'))
                    <img src="{{ URL::asset('img/iconimg/'.$projectfile->fileextension.'.png') }}" alt=""> 
                @else
                    <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> 
                @endif
            </div>
            @endif
        @endif
        <div class="card-body">
            <h5 class="card-title" title="{{ $projectfile->fname}}" >{{ $projectfile->filename}}</h5>
            <h6>{{ $projectfile->filesize}}</h6>
            <p class="card-text">{{ $projectfile->created_by}} At {{ date("d-m-Y",strtotime($projectfile->created_at))}}</p>
            <span class="badge badge-primary"><a href="{!!URL::to($projectfile->commentseourl)!!}">{!!$projectfile->totalcomment!!} comments</a></span> <span class="badge badge-secondary"><a href="#">Label</a></span>
        </div>
    </div>
</div>
@endforeach @endif
@else
@if(count($projectfiles) > 0) 
@foreach($projectfiles as $projectfile)  
<div class="projectListViewBox everythingTrash listViewFiles" id="divfile-{!! $projectfile->fileid!!}">
    <ul class="list-group projectListView">
    <li class="list-group-item">
        <div class="row">
        <div class="col-md-9 clearfix">
            @if($projectfile->filetypes == 'image')  
            @if($projectfile->filenewname!='' && file_exists('public/img/comment_files/'.$projectfile->foldername.'/list/'.$projectfile->filenewname))
            <div class="bigIcon listViewFileImg">
                <a title="{{ $projectfile->fname}}" href="{!! URL::to('/download/'.$projectfile->foldername.'/'.base64_encode($projectfile->filenewname)) !!}">
                <img src="{{ URL::asset('img/comment_files/'.$projectfile->foldername.'/list/'.$projectfile->filenewname) }}"
                        alt="{{ $projectfile->created_by}}">
                </a>
            </div>
            @else
            <div class="bigIcon listViewFileImg">
            @if($projectfile->fileextension!='' && file_exists('public/img/iconimg/'.$projectfile->fileextension.'.png'))
                <img src="{{ URL::asset('img/iconimg/'.$projectfile->fileextension.'.png') }}" alt=""> 
            @else
                <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> 
            @endif
            </div>
            @endif
            @elseif($projectfile->filetypes == 'other')
            @if($projectfile->filenewname!='' && file_exists('public/img/comment_files/'.$projectfile->foldername.'/'.$projectfile->filenewname))
            <div class="bigIcon listViewFileImg">
                <a title="{{ $projectfile->fname}}" href="{!! URL::to('/download/'.$projectfile->foldername.'/'.base64_encode($projectfile->filenewname)) !!}">
                    @if($projectfile->fileextension!='' && file_exists('public/img/iconimg/'.$projectfile->fileextension.'.png'))
                        <img src="{{ URL::asset('img/iconimg/'.$projectfile->fileextension.'.png') }}" alt=""> 
                    @else
                        <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> 
                    @endif
                </a>
            </div>
            @else
            <div class="bigIcon listViewFileImg" title="{{ $projectfile->fname}}">
                @if($projectfile->fileextension!='' && file_exists('public/img/iconimg/'.$projectfile->fileextension.'.png'))
                    <img src="{{ URL::asset('img/iconimg/'.$projectfile->fileextension.'.png') }}" alt=""> 
                @else
                    <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> 
                @endif
            </div>
            @endif
            @endif  
            <div class="everythingTrashText">
            <div class="todoListDate"><a href="{!!URL::to($projectfile->commentseourl)!!}">{{ $projectfile->filename}}</a></div>
            <div class="todoListStatus">
                <span class="badge badge-primary">{!!$projectfile->totalcomment!!} coments</span>
                <span class="badge badge-secondary"><a href="#">Label</a></span>
            </div>
            <div class="todoListText">Created by: <strong class="text-info">{{ $projectfile->created_by}}</strong> | Created
                at: <strong class="text-info">{{ date("F d Y",strtotime($projectfile->created_at))}}</strong> | Size: <strong class="text-info">{{ $projectfile->filesize}}</strong></div>
            </div>
        </div>
        </div>
        <div class="listViewIcons">
            <div class="projectBoxIconsBox">
                <a href="{!! URL::to('/download/'.$projectfile->foldername.'/'.base64_encode($projectfile->filenewname)) !!}" data-toggle="tooltip" data-placement="bottom" id="tooltipp9" title="Download"><i class="fas fa-download"></i></a>
                <span class="projectBoxIconsBoxText">Download</span>
            </div>
            <div class="projectBoxIconsBox">
                <a style="cursor:pointer;" id="delete_{!! $projectfile->fileid!!}" data-toggle="tooltip" data-placement="bottom" id="tooltipp15" title="Delete"><i class="far fa-trash-alt"></i></a>
                <span class="projectBoxIconsBoxText">Delete</span>
            </div>
        </div>
    </li>
    </ul>
</div>
@endforeach @endif
@endif
