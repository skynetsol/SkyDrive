<ul class="list-group">
    <li class="list-group-item">
        <div class="todoListDate">{!! date("F d ",strtotime($project->created_at)) !!} at {!! date("h:i a",strtotime($project->created_at)) !!} </div>
        <div class="todoListText"> {!! $project->created_byname !!} added this project to todooos.</div>
    </li>
    @if(count($projecthistorys) > 0)
    @foreach($projecthistorys as $projecthistory)
      @if($projecthistory->action == 'todomove')
      <li class="list-group-item">
          <div class="todoListDate">{!! date("F d ",strtotime($projecthistory->created_at)) !!} at {!! date("h:i a",strtotime($projecthistory->created_at)) !!} </div>
          <div class="todoListText"> {{ $projecthistory->created_by }} move this todo {{ $projecthistory->comment }} from project: {{ $projecthistory->oldprojectstatus }} / todolist: {{ $projecthistory->oldseoname }}</b> to <b>{{ $projecthistory->newprojectstatus }} / todolist: {{ $projecthistory->newseoname }}</b>.</div>
      </li>
      @elseif($projecthistory->action == 'labeledit')
      <li class="list-group-item">
          <div class="todoListDate">{!! date("F d ",strtotime($projecthistory->created_at)) !!} at {!! date("h:i a",strtotime($projecthistory->created_at)) !!} </div>
          <div class="todoListText"> {{ $projecthistory->created_by }} change the todolist name from <b>{{ $projecthistory->oldprojectstatus }} </b> to <b> {{ $projecthistory->newprojectstatus }}</b>.</div>
      </li>
      @elseif($projecthistory->action == 'todoedit')
      <li class="list-group-item">
          <div class="todoListDate">{!! date("F d ",strtotime($projecthistory->created_at)) !!} at {!! date("h:i a",strtotime($projecthistory->created_at)) !!} </div>
          <div class="todoListText"> {{ $projecthistory->created_by }} change the todo name from <b>{{ $projecthistory->oldprojectstatus }} </b> to <b>{{ $projecthistory->newprojectstatus }}</b>.</div>
      </li>
      @elseif($projecthistory->action == 'projectedit')
      <li class="list-group-item">
          <div class="todoListDate">{!! date("F d ",strtotime($projecthistory->created_at)) !!} at {!! date("h:i a",strtotime($projecthistory->created_at)) !!} </div>
          <div class="todoListText"> {{ $projecthistory->created_by }} change the project name from <b>{{ $projecthistory->oldprojectstatus }} </b> to <b>{{ $projecthistory->newprojectstatus }}</b>.</div>
      </li>
      @elseif($projecthistory->action == 'projectstatus')
      <li class="list-group-item">
          <div class="todoListDate">{!! date("F d ",strtotime($projecthistory->created_at)) !!} at {!! date("h:i a",strtotime($projecthistory->created_at)) !!} </div>
          <div class="todoListText"> {{ $projecthistory->created_by }} change the project status from <b>{{ $projecthistory->oldprojectstatus }} </b> to <b>{{ $projecthistory->newprojectstatus }}</b>
            @if($projecthistory->comment != '')
              Comment: {{ $projecthistory->comment }}
            @endif
          </div>
      </li>
      @else
      <li class="list-group-item">
          <div class="todoListDate">{!! date("F d ",strtotime($projecthistory->created_at)) !!} at {!! date("h:i a",strtotime($projecthistory->created_at)) !!} </div>
          <div class="todoListText"> {{ $projecthistory->created_by }} change the {{ $projecthistory->action }} from <b>{{ $projecthistory->oldprojectstatus }}</b>  to <b>{{ $projecthistory->newprojectstatus }}</b>
            @if($projecthistory->comment != '')
              Comment: {{ $projecthistory->comment }}
            @endif
          </div>
      </li>
      @endif
    @endforeach
    @endif
</ul>