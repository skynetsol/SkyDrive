@extends('layouts.authprojectwleft')
@section('pageTitle')
Invite
@stop
@section('styles')
@stop
@section('content')
  @if(in_array("3",$companyInfo->user_type) && $teamorclient == 'C')
  <div class="m-5">
    <h3 class="m-3">Here’s who’s on this project <a href="{!! URL::to($project->seourl) !!}" class="text-primary">{!! $project->projectname !!}</a></h3>
    <p>Invite people to this project and start working together in seconds. Everyone you invite will receive a welcome email.</p>
  </div>
  <div class="inviteTab">
    {{-- <ul class="nav nav-tabs" id="myTab" role="tablist">
      <li class="nav-item">
        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
          aria-selected="true">Our Team</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile"
          aria-selected="false">The Client</a>
      </li>
    </ul> --}}
    <div class="tab-content" id="myTabContent">
      <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        <div class="row">
          <div class="col-md-6 inviteBorder">
            <form  method="post" action="" id="frminviteclient">
              @csrf
              <div class="m-5">
                <div class="form-group m-4">
                  <h5>Type names or emails to invite people to your team:</h5>
                  <select class="js-example-basic-single" name="cemail[]" id="cemail" multiple>
                      <option value="">Select User</option>
                      @if(count($users) > 0 ) 
                      @foreach($users as $user) 
                        <option value="{{ $user->email }}">{{ $user->firstname." ".$user->lastname }}</option>
                      @endforeach 
                      @endif
                  </select>
                </div>
                <div class="form-group">
                  <h5>Add a welcome message for your team:</h5>
                  <textarea rows="4" class="form-control" id="mailtext" name="mailtext" placeholder="Hi, there. We'll be using todooos to share ideas, gather feedback, and track progress during this project."></textarea>
                </div>
                <div class="form-group">
                    <input type="hidden" name="companyid" id="companyid" value="{!! $companyInfo->companyid !!}">
                    <input type="hidden" value="{!! Auth::user()->id !!}" id="created_by" name="created_by">
                    <input type="hidden" value="{!! $project->projectid !!}" id="projectid" name="projectid">
                    <input type="submit" class="btn btn-primary" value="Send Invitation" id="submitclientinvite">
                    <input type="hidden" value="C" id="invitetype" name="invitetype">
                    <input type="hidden" name="timezone" id="timezone" value="">
                </div>
                <div id="msgcdiv" class=""></div>
              </div>
            </form>
          </div>
          <div class="col-md-6 inviteBorder2">
            <p>Anyone from your clients will see certain messages, to-dos, files, events, and text documents that you allow them to see.</p>
            @if(count($inviteusers) > 0)
              @foreach($inviteusers as $inviteuser)
                @if($inviteuser->invitetype == 'C')
                  <div class="media meProfile inviteMedia" id="cinvitediv-{!! $inviteuser->inviteid !!}"> 
                    @if($inviteuser->profilepic != '' && file_exists('public/img/profile_img/thum/'.$inviteuser->profilepic))
                    <img class="meProfileImg" src="{{ URL::asset('img/profile_img/thum/'.$inviteuser->profilepic) }}" alt="{{ $inviteuser->firstname ." ".$inviteuser->lastname }}">
                    @else
                    <img class="meProfileImg" src="{{URL::asset('public/img/profileImg.jpg')}}" alt="">
                    @endif
                    <div class="media-body">
                      <h5 class="mt-0">{{ $inviteuser->firstname ." ".$inviteuser->lastname }}</h5>
                      <p>{{ $inviteuser->email }}</p>
                    </div>
                  </div>
                @endif
              @endforeach 
            @endif
          </div>
        </div>
      </div>
  </div>
  @else
  <div class="m-5">
    <h3 class="m-3">Here’s who’s on this project <a href="{!! URL::to($project->seourl) !!}" class="text-primary">{!! $project->projectname !!}</a></h3>
    <p>Invite people from your team or from your client and start working together in seconds. Everyone you invite will receive a welcome email.</p>
  </div>
  <div class="inviteTab">
    <ul class="nav nav-tabs" id="myTab" role="tablist">
      <li class="nav-item">
        <a class="nav-link active" id="team-tab" data-toggle="tab" href="#ourTeam" role="tab" aria-controls="home"
          aria-selected="true">Our Team</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="client-tab" data-toggle="tab" href="#theClient" role="tab" aria-controls="profile"
          aria-selected="false">The Client</a>
      </li>
    </ul>
    <div class="tab-content" id="myTabContent">
      <div class="tab-pane fade show active" id="ourTeam" role="tabpanel" aria-labelledby="team-tab">
        <div class="row">
          <div class="col-md-6 inviteBorder">
            <form  method="post" action="" id="frminvite">
            @csrf  
            <div class="m-5">
              <div class="form-group m-4">
                <h5>Type names or emails to invite people to your team:</h5>
                <select class="js-example-basic-single"  name="email[]" id="email" multiple>
                  <option value="">Select User</option>
                    @if(count($users) > 0 ) 
                      @foreach($users as $user) 
                      <option value="{{ $user->email }}">{{ $user->firstname." ".$user->lastname }}</option>
                      @endforeach 
                    @endif
                </select>
              </div>
              <div class="form-group">
                <h5>Add a welcome message for your team:</h5>
                <textarea rows="4" class="form-control" id="mailtext" name="mailtext" placeholder="Hi, there. We'll be using todooos to share ideas, gather feedback, and track progress during this project."></textarea>
              </div>
              <div class="form-group">
                <input type="hidden" name="companyid" id="companyid" value="{!! $companyInfo->companyid !!}">
                <input type="hidden" value="{!! Auth::user()->id !!}" id="created_by" name="created_by">
                <input type="hidden" value="{!! $project->projectid !!}" id="projectid" name="projectid">
                <input type="submit" class="btn btn-primary" value="Send Invitation" id="submitinvite">
                <input type="hidden" value="T" id="invitetype" name="invitetype">
                <input type="hidden" name="timezone" id="timezone" value="">
              </div>
              <div id="msgdiv" class=""></div>
            </div>
            </form>
          </div>
          <div class="col-md-6 inviteBorder2">
            <p>Anyone on your team will see everything posted to this project. Every message, todo-list, file, event, and text document.</p>
            @if(count($inviteusers) > 0)
              @foreach($inviteusers as $inviteuser)
                @if($inviteuser->invitetype == 'T')
                <div class="media meProfile inviteMedia" id="invitediv-{!! $inviteuser->inviteid !!}"> 
                  @if($inviteuser->profilepic != '' && file_exists('public/img/profile_img/thum/'.$inviteuser->profilepic)) 
                    <img class="meProfileImg" src="{{ URL::asset('img/profile_img/thum/'.$inviteuser->profilepic) }}" alt="{{ $inviteuser->firstname ." ".$inviteuser->lastname }}"> 
                  @else 
                    <img class="meProfileImg" src="{{ URL::asset('img/profileImg') }}" alt="{{ $inviteuser->firstname ." ".$inviteuser->lastname }}">                        
                  @endif 
                  <div class="media-body">
                    <h5 class="mt-0">{{ $inviteuser->firstname ." ".$inviteuser->lastname }}</h5>
                    <p>{{ $inviteuser->email }}</p>
                    <div>
                      @if($companyInfo->created_by == Auth::user()->id)
                        @if($inviteuser->inviteuserid != $companyInfo->created_by)
                          <div class="form-check form-check-inline">
                            <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                            <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                          </div>
                        @endif
                      @elseif(in_array("2",$companyInfo->user_type))
                        @if($inviteuser->inviteuserid == Auth::user()->id || $inviteuser->inviteuserid == $companyInfo->created_by)
                        @else
                          <div class="form-check form-check-inline">
                            <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                            <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                          </div>
                        @endif
                      @elseif(in_array("1",$companyInfo->user_type))
                        @if($inviteuser->inviteuserid != Auth::user()->id)  
                        <div class="form-check form-check-inline">
                          <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                          <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                        </div>
                        @endif
                      @endif
                    </div>
                  </div>
                </div>
                @endif
              @endforeach
            @endif    
          </div>
        </div>
      </div>
      <div class="tab-pane fade" id="theClient" role="tabpanel" aria-labelledby="client-tab">
        <div class="m-5" {!! ($totalinviteclient == 0 ? '' : 'style="display:none;"') !!} id="withoutclientlist">
          <div class="row">
            <div class="col-md-6">
              <div class="m-5">
                <h3>Working with a client on this project?</h3>
                <p>Todooos lets you hide certain messages, to-dos, files, events, and text documents from people
                  invited as clients. This is great for sharing unfinished work with your team before getting
                  client feedback.</p>

                <p>You can turn this on now to start choosing what clients can see, even if you’re not ready to
                  invite any clients yet.</p>
                <a style="cursor:pointer;" class="btn btn-primary noLinkButton" id="showTrigger-{!! $project->projectid !!}">Yes, turn on client access for this project</a>

              </div>
            </div>
            <div class="col-md-6">
              <div class="circleImg"><img src="{{ URL::asset('public/img/circleimg.jpg')}}" alt=""></div>
            </div>
          </div>
        </div>

        <div class="row" {!! ($totalinviteclient == 0  ? 'style="display:none;"' : '') !!} id="withclientlist">
          <div class="col-md-6 inviteBorder">
            <form  method="post" action="" id="frminviteclient">
            @csrf  
            <div class="m-5">
              <div class="form-group m-4">
                <h5>Type names or emails to invite people from your clients:</h5>
                <select class="js-example-basic-single"  name="cemail[]" id="cemail" multiple>
                  <option value="">Select User</option>
                    @if(count($users) > 0 ) 
                    @foreach($users as $user) 
                      <option value="{{ $user->email }}">{{ $user->firstname." ".$user->lastname }}</option>
                    @endforeach 
                    @endif
                </select>
              </div>

              <div class="form-group">
                <h5>Add a welcome message for your clients:</h5>
                <textarea rows="4" class="form-control" id="mailtext" name="mailtext" placeholder="Hi, there. We'll be using todooos to share ideas, gather feedback, and track progress during this project."></textarea>
              </div>
              <div class="form-group">
                <input type="hidden" name="companyid" id="companyid" value="{!! $companyInfo->companyid !!}">
                <input type="hidden" value="{!! Auth::user()->id !!}" id="created_by" name="created_by">
                <input type="hidden" value="{!! $project->projectid !!}" id="projectid" name="projectid">
                <input type="submit" class="btn btn-primary" value="Send Invitation" id="submitclientinvite">
                <input type="hidden" value="C" id="invitetype" name="invitetype">
                <input type="hidden" name="timezone" id="timezone" value="">
              </div>
              <div id="msgcdiv" class=""></div>
            </div>
            </form>
          </div>
          <div class="col-md-6 inviteBorder2">
            <p>Anyone from your clients will see certain messages, to-dos, files, events, and text documents that you allow them to see.</p>
            @if(count($inviteusers) > 0)
              @foreach($inviteusers as $inviteuser)
                @if($inviteuser->invitetype == 'C')
                <div class="media meProfile inviteMedia" id="invitediv-{!! $inviteuser->inviteid !!}"> 
                  @if($inviteuser->profilepic != '' && file_exists('public/img/profile_img/thum/'.$inviteuser->profilepic)) 
                    <img class="meProfileImg" src="{{ URL::asset('img/profile_img/thum/'.$inviteuser->profilepic) }}" alt="{{ $inviteuser->firstname ." ".$inviteuser->lastname }}"> 
                  @else 
                    <img class="meProfileImg" src="{{ URL::asset('public/img/profileImg') }}" alt="{{ $inviteuser->firstname ." ".$inviteuser->lastname }}">                        
                  @endif 
                  <div class="media-body">
                    <h5 class="mt-0">{{ $inviteuser->firstname ." ".$inviteuser->lastname }}</h5>
                    <p>{{ $inviteuser->email }}</p>
                    <div>
                      @if($companyInfo->created_by == Auth::user()->id)
                        @if($inviteuser->inviteuserid != $companyInfo->created_by)
                          <div class="form-check form-check-inline">
                            <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                            <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                          </div>
                        @endif
                      @elseif(in_array("2",$companyInfo->user_type))
                        @if($inviteuser->inviteuserid == Auth::user()->id || $inviteuser->inviteuserid == $companyInfo->created_by)
                        @else
                          <div class="form-check form-check-inline">
                            <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                            <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                          </div>
                        @endif
                      @elseif(in_array("1",$companyInfo->user_type))
                        @if($inviteuser->inviteuserid != Auth::user()->id)  
                        <div class="form-check form-check-inline">
                          <a style="cursor:pointer;" class="text-danger" id="remove-{!! $inviteuser->inviteid !!}">Remove</a>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="checkbox" id="manager-{!! $inviteuser->inviteid !!}" {!! ($inviteuser->manager == 1 ? 'checked' : '') !!}>
                          <label class="form-check-label text-warning" for="manager-{!! $inviteuser->inviteid !!}">Manager</label>
                        </div>
                        @endif
                      @endif
                    </div>
                  </div>
                </div>
                @endif
              @endforeach
            @endif
            <div id="msgcremovediv" class=""></div> 
          </div>
        </div>
      </div>
    </div>
  </div>
  @endif
@stop() 
@section('scripts')
{!! Html::script('js/jstz.js') !!}
<script>
    var tz = jstz.determine();
    uid = "{{Auth::user()->id}}";
    var id = "{{$project->projectid}}";
    var psn = "{{$project->seoname}}";
</script>
{!! Html::script('js/invite.js') !!}
@stop
