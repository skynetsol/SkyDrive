@extends('layouts.authuser')
@section('pageTitle')
All updates
@stop
@section('content')

<h3 class="m-5">Project Updates</h3>
@if(count($allupdates) > 0)

@foreach($allupdates as $allupdate)
@if($allupdate->prevCompletedDate == '')
<div class="projectUpdateBox">
    <div class="projectUpdateBoxDate">
        <h5>{!! date("d F, Y",strtotime($allupdate->created_at)) !!}</h5>
        <p>{!! date("l",strtotime($allupdate->created_at)) !!}</p>
    </div>
    <div class="media commentsBox">
        @if($allupdate->profilepic != '')
        <img class="mr-3" src="{{ URL::asset('img/profile_img/thum/'.$allupdate->profilepic) }}" alt="{{ $allupdate->commentby}}">
        @else
        <img class="mr-3" src="{{ URL::asset('img/profile-img.jpg') }}" alt="{{ $allupdate->commentby}}">
        @endif
        <div class="media-body">
            <h5 class="mt-0"><a href="{{ URL::to($allupdate->seourl)}}">{{ $allupdate->taskname}} </a><span class="updateTime">{!!
                    date("h:i a",strtotime($allupdate->created_at)) !!}</span></h5>
            <h6>Posted by {{ $allupdate->commentby}}</h6>
            <p>{!! $allupdate->description !!}</p>
            @if(count($allupdate->files) > 0)
            <div class="row">
                @foreach($allupdate->files as $file)
                <div class="col-sm-6 col-md-4 col-lg-4 col-xl-3">
                    <div class="card fileType text-center">
                        <div class="fileTypeImg">
                            @if($file->filetypes == 'image')
                                @if($file->filenewname!='' && file_exists('public/img/comment_files/'.$file->foldername.'/list/'.$file->filenewname))
                                <a href="/download/{!! $file->filenewname !!}" target="_blank"><img src="{{ URL::asset('img/comment_files/'.$file->foldername.'/list/'.$file->filenewname) }}" alt="{{ $file->created_by}}"></a>
                                @else
                                    @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                                        <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt=""> 
                                    @else
                                        <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> 
                                    @endif
                                @endif  
                            @elseif($file->filetypes == 'other') 
                                @if($file->filenewname!='' && file_exists('public/img/comment_files/'.$file->foldername.'/'.$file->filenewname)) 
                                <a href="{!! URL::to('img/comment_files/'.$file->foldername.'/'.$file->filenewname) !!}" target="_blank"><img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt=""></a>
                                @else
                                    @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                                        <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt=""> 
                                    @else
                                        <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> 
                                    @endif
                                @endif 
                            @endif    
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">{!! $file->filename !!}</h5>
                            <h6>{!! $file->filesize !!}</h6>
                            <p class="card-text">By {!! $file->created_by !!} At {{ date("d-m-Y",strtotime($file->created_at))}}</p>
                            <span class="badge badge-primary"><a href="{!!URL::to($file->commentseourl)!!}">{!! ($file->totalcomment == 1 ? $file->totalcomment .' comment' : $file->totalcomment.' comments')!!} </a></span> <span class="badge badge-secondary"><a href="#">Label</a></span>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            @endif
        </div>
    </div>
    @else
    <div class="media commentsBox">
        @if($allupdate->profilepic != '')
        <img class="mr-3" src="{{ URL::asset('img/profile_img/thum/'.$allupdate->profilepic) }}" alt="{{ $allupdate->commentby}}">
        @else
        <img class="mr-3" src="{{ URL::asset('public/img/profile-img.jpg') }}" alt="{{ $allupdate->commentby}}">
        @endif
        <div class="media-body">
            <h5 class="mt-0"><a href="{{ URL::to($allupdate->seourl)}}">{{ $allupdate->taskname}} </a><span class="updateTime">{!!
                    date("h:i a",strtotime($allupdate->created_at)) !!}</span></h5>
            <h6>Posted by {{ $allupdate->commentby}}</h6>
            <p>{!! $allupdate->description !!}</p>
            @if(count($allupdate->files) > 0)
            <div class="row">
                @foreach($allupdate->files as $file)
                <div class="col-sm-6 col-md-4 col-lg-4 col-xl-3">
                    <div class="card fileType text-center">
                        <div class="fileTypeImg">
                            @if($file->filetypes == 'image')
                                @if($file->filenewname!='' && file_exists('public/img/comment_files/'.$file->foldername.'/list/'.$file->filenewname))
                                <a href="/download/{!! $file->filenewname !!}" target="_blank"><img src="{{ URL::asset('img/comment_files/'.$file->foldername.'/list/'.$file->filenewname) }}" alt="{{ $file->created_by}}"></a>
                                @else
                                    @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                                        <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt=""> 
                                    @else
                                        <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> 
                                    @endif
                                @endif  
                            @elseif($file->filetypes == 'other') 
                                @if($file->filenewname!='' && file_exists('public/img/comment_files/'.$file->foldername.'/'.$file->filenewname)) 
                                <a href="{!! URL::to('img/comment_files/'.$file->foldername.'/'.$file->filenewname) !!}" target="_blank"><img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt=""></a>
                                @else
                                    @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                                        <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt=""> 
                                    @else
                                        <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> 
                                    @endif
                                @endif 
                            @endif    
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">{!! $file->filename !!}</h5>
                            <h6>{!! $file->filesize !!}</h6>
                            <p class="card-text">By {!! $file->created_by !!} At 17-04-2018</p>
                            <span class="badge badge-primary">1 coments</span> <span class="badge badge-secondary"><a href="#">Label</a></span>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            @endif
        </div>
    </div>
    @endif
    @if(($allupdate->prevCompletedDate != date("Y-m-d",strtotime($allupdate->nextCompletedDate)) ) && $allupdate->prevCompletedDate != ''  )
    </div>
    @elseif((date("Y-m-d",strtotime($allupdate->nextCompletedDate)) != date("Y-m-d",strtotime($allupdate->created_at)) ) && $allupdate->prevCompletedDate == ''  )
    </div>
    @endif
@endforeach
@endif
</div>
@stop()
@section('scripts')
<script>
    uid = "{{Auth::user()->id}}";
</script>
@stop
