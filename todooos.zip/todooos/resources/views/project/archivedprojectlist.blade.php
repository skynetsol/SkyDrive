@extends('layouts.authother')
@section('pageTitle')
Archived Projects
@stop
@section('styles')
@stop
@section('content')
<div class="archiveTop m-5">
    <div class="d-flex flex-row bd-highlight align-items-center">
        <div>
            <div class="archiveTopLeft"><a class="btn btn-secondary">Archived</a></div>
        </div>
        <div>
            <div class="archiveTopRight">
                <p class="m-0">These projects are locked and archived.</p>
            </div>
        </div>
    </div>
</div>
<div class="d-flex flex-column flex-sm-row m-3">
    <div>
        <h3>All ({!! (isset($totarchivedproject) ? $totarchivedproject : 0 )!!}) Archived Projects A-Z</h3>
    </div>
    <div class="blankSpace"></div>
</div>
<div class="projectArea clearfix">
    <div class="projectRight">
        <div class="dropdown-divider"></div>
        <div id="ajaxprojectlist">
            @if(count($projects) > 0)
            @foreach($projects as $projectlist)
            @if($projectlist->prevFirstAlpha == '')
            <div class="projectListViewBox">
                <h2 class="text-primary m-1">{!! $projectlist->firstalpha !!}</h2>
                <ul class="list-group projectListView">
                    <li class="list-group-item" id="liarchiveproject-{!! $projectlist->projectid !!}">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="todoListDate"><a href="{!! URL::to($projectlist->seourl) !!}">{!!
                                        $projectlist->projectname !!}</a></div>
                            </div>
                        </div>
                        <div class="listViewIcons">
                            <div class="projectBoxIconsBox">
                                <a style="cursor:pointer;" id="projectunarchived-{!! $projectlist->projectid.'|'.implode("
                                    , ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom"
                                    title="Un-Archive"><i class="fas fa-archive"></i></a>
                                <span class="projectBoxIconsBoxText">Un-Archive</span>
                            </div>
                            @if(in_array(2,$companyInfo->user_type))
                            <div class="projectBoxIconsBox">
                                <a style="cursor:pointer;" id="projectdelete-{!! $projectlist->projectid.'|'.implode("
                                    , ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom"
                                    title="Delete"><i class="far fa-trash-alt"></i></a>
                                <span class="projectBoxIconsBoxText">Delete</span>
                            </div>
                            @endif
                            <div class="projectBoxIconsBox">
                                <a href="{!! URL::to($projectlist->seourl.'/time-entry-report') !!}" class="text-primary"
                                    data-toggle="tooltip" data-placement="bottom" title="{!! ($projectlist->totaltime!=NULL ? substr($projectlist->totaltime,0,5) : '00:00') !!}
                                            Hrs"><i
                                        class="far fa-clock"></i></a>
                                <span class="projectBoxIconsBoxText">{!! ($projectlist->totaltime!=NULL ?
                                    substr($projectlist->totaltime,0,5) : '00:00') !!}
                                    Hrs</span>
                            </div>
                            <div class="projectBoxIconsBox">
                                @if($projectlist->totalopentasks == 0 && $projectlist->totaltasks > 0)
                                <a href="{!! URL::to($projectlist->seourl.'/completed-todo') !!}" title="to-dos" class="text-primary"
                                    data-toggle="tooltip" data-placement="bottom" title="All Done"><i class="fas fa-chart-pie"></i></a>
                                <span class="projectBoxIconsBoxText">All Done</span>
                                @else
                                <a href="{!! URL::to($projectlist->seourl.'/todolist') !!}" title="to-dos" class="text-primary"
                                    data-toggle="tooltip" data-placement="bottom" title="{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}"><i
                                        class="fas fa-chart-pie"></i></a>
                                <span class="projectBoxIconsBoxText">{!! $projectlist->totalopentasks !!}/{!!
                                    $projectlist->totaltasks !!}</span>
                                @endif
                            </div>
                        </div>
                    </li>
                    @else
                    <li class="list-group-item" id="liarchiveproject-{!! $projectlist->projectid !!}">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="todoListDate"><a href="{!! URL::to($projectlist->seourl) !!}">{!!
                                        $projectlist->projectname !!}</a></div>
                            </div>
                        </div>
                        <div class="listViewIcons">
                            <div class="projectBoxIconsBox">
                                <a style="cursor:pointer;" id="projectunarchived-{!! $projectlist->projectid.'|'.implode("
                                    , ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom"
                                    title="Un-Archive"><i class="fas fa-archive"></i></a>
                                <span class="projectBoxIconsBoxText">Un-Archive</span>
                            </div>
                            @if(in_array(2,$companyInfo->user_type))
                            <div class="projectBoxIconsBox">
                                <a style="cursor:pointer;" id="projectdelete-{!! $projectlist->projectid.'|'.implode("
                                    , ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom"
                                    title="Delete"><i class="far fa-trash-alt"></i></a>
                                <span class="projectBoxIconsBoxText">Delete</span>
                            </div>
                            @endif
                            <div class="projectBoxIconsBox">
                                <a href="{!! URL::to($projectlist->seourl.'/time-entry-report') !!}" class="text-primary"
                                    data-toggle="tooltip" data-placement="bottom" title="{!! ($projectlist->totaltime!=NULL ? substr($projectlist->totaltime,0,5) : '00:00') !!}
                                            Hrs"><i
                                        class="far fa-clock"></i></a>
                                <span class="projectBoxIconsBoxText">{!! ($projectlist->totaltime!=NULL ?
                                    substr($projectlist->totaltime,0,5) : '00:00') !!}
                                    Hrs</span>
                            </div>
                            <div class="projectBoxIconsBox">
                                @if($projectlist->totalopentasks == 0 && $projectlist->totaltasks > 0)
                                <a href="{!! URL::to($projectlist->seourl.'/completed-todo') !!}" title="to-dos" class="text-primary"
                                    data-toggle="tooltip" data-placement="bottom" title="All Done"><i class="fas fa-chart-pie"></i></a>
                                <span class="projectBoxIconsBoxText">All Done</span>
                                @else
                                <a href="{!! URL::to($projectlist->seourl.'/todolist') !!}" title="to-dos" class="text-primary"
                                    data-toggle="tooltip" data-placement="bottom" title="{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}"><i
                                        class="fas fa-chart-pie"></i></a>
                                <span class="projectBoxIconsBoxText">{!! $projectlist->totalopentasks !!}/{!!
                                    $projectlist->totaltasks !!}</span>
                                @endif
                            </div>
                        </div>
                    </li>
                    @endif
                    @if(($projectlist->firstalpha == '' && $projectlist->prevFirstAlpha != '') ||
                    ($projectlist->firstalpha != $projectlist->nextAlpha) )
                </ul>
            </div>
            @endif
            <script type="text/javascript">
                lastalpha = "{{$projectlist->firstalpha}}";
            </script>
            @endforeach
            @endif
        </div>
    </div>
    {{-- <div class="ajax-loading text-center col-md-12"><img src="{{ asset('public/img/loading.gif') }}" /></div> --}}
</div>
@stop()
@section('scripts')
{!! Html::script('js/archivedprojectlist.js') !!}

<script type="text/javascript">
    

</script>
@stop
