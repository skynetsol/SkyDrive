@extends('layouts.authprojectwleft')
@section('pageTitle')
Complated to-do
@stop
@section('content')

<h3 class="m-5">Completed to-dos</h3>
<div class="row">
    <div class="col-md-12">
        <div class="completedToDos clearfix">
        <div class="table-responsive">
            <table class="table com-todo">
            <tbody>
                @if(count($completedtodos) > 0) 
                @foreach($completedtodos as $completedtodo)
                @if($completedtodo->prevCompletedDate == '')
                <tr>
                    <td class="comdate">
                    <h5>{!! date("F d",strtotime($completedtodo->completed_at)) !!}</h5>    
                    <p>{!! date("l",strtotime($completedtodo->completed_at)) !!}</p>
                    </td>
                    <td class="comdate">
                    <h5 class="mt-0"><a href="{!! URL::to($completedtodo->labelseourl)!!}">{!! $completedtodo->labelname !!}</a></h5>
                    <div class="completed" id="completed-{{ $completedtodo->taskid}}"><p>
                        @if($project->archived == 0)
                        <input type="checkbox" checked name="taskcomplete" id="taskcomplete-{{ $completedtodo->taskid }}" class="css-checkbox" />
                        @endif
                        <label for="taskcomplete-{{ $completedtodo->taskid }}" class="css-label"></label>
                        <a href="{!! URL::to($completedtodo->seourl) !!}">{!! $completedtodo->taskname !!}</a>
                        <span class="badge badge-secondary">{{ 'Completed By: '.$completedtodo->name }}</span>
                    </div>
                @else 
                    @if($completedtodo->prevTodolistName != $completedtodo->labelname) 
                    <h5 class="mt-0"><a href="{!! URL::to($completedtodo->labelseourl)!!}">{!! $completedtodo->labelname !!}</a> </h5> 
                    <div class="completed" id="completed-{{ $completedtodo->taskid}}"><p>
                        @if($project->archived == 0)
                        <input type="checkbox" checked name="taskcomplete" id="taskcomplete-{{ $completedtodo->taskid }}" class="css-checkbox" />
                        @endif
                        <label for="taskcomplete-{{ $completedtodo->taskid }}" class="css-label"></label>
                        <a href="{!! URL::to($completedtodo->seourl) !!}">{!! $completedtodo->taskname !!}</a>
                        <span class="badge badge-secondary">{{ 'Completed By: '.$completedtodo->name }}</span>
                    </div>
                    @else
                    <div class="completed" id="completed-{{ $completedtodo->taskid}}"><p>
                        @if($project->archived == 0)
                        <input type="checkbox" checked name="taskcomplete" id="taskcomplete-{{ $completedtodo->taskid }}" class="css-checkbox" />
                        @endif
                        <label for="taskcomplete-{{ $completedtodo->taskid }}" class="css-label"></label>
                        <a href="{!! URL::to($completedtodo->seourl) !!}">{!! $completedtodo->taskname !!}</a>
                        <span class="badge badge-secondary">{{ 'Completed By: '.$completedtodo->name }}</span>
                    </div>
                    @endif 
                    @if($completedtodo->prevCompletedDate == date("Y-m-d",strtotime($completedtodo->completed_at)) && $completedtodo->prevCompletedDate == '')
                        </td>
                        </tr>
                    @endif
                    @endif
                @endforeach
                @endif
            </tbody>
            </table>
        </div>
        </div>
    </div>
    </div>
@stop()
@section('scripts')
<script>
uid = "{{Auth::user()->id}}";
$(function()
{
    $('input[id^="taskcomplete-"]').click(function()
    {
        var taskid = $(this).prop('id').replace('taskcomplete-','');
        var status = '';
        var msg = "Are you sure you want to re-open this to-do?";
        if(confirm(msg))
        {
            status = ($('input#taskcomplete-'+taskid).prop('checked') == true ? '1' : '0');
            var arg='taskid='+taskid+'&status='+status;
            $.ajax({
                    url: sitepath+"/task/reopen",
                    type: "POST",
                    data: arg,
                    timeout: 20000,
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    cache: false,
                    success: function(html)
                    {
                        var nhtml = html.sms;
                        if(parseInt(nhtml) == 1)
                        {
                            $('div#completed-'+taskid).hide();
                        }
                        return false;
                    }
                });
        }
        else
        {
            $('input#taskcomplete-'+taskid).prop('checked',true);
        }
    });
	
});
</script>
@stop
