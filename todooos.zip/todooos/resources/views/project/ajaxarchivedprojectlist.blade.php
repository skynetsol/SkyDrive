  @if(count($projects) > 0)
    @foreach($projects as $projectlist) 
        @if($projectlist->prevFirstAlpha == '' && $lastalpha != $projectlist->firstalpha)
        <div class="projectListViewBox">
            <h2 class="text-primary m-1">{!! $projectlist->firstalpha !!}</h2>
            <ul class="list-group projectListView">
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="todoListDate"><a href="{!! URL::to($projectlist->seourl) !!}">{!! $projectlist->projectname !!}</a></div>
                        </div>
                    </div>
                    <div class="listViewIcons">
                        <div class="projectBoxIconsBox">
                            <a style="cursor:pointer;" id="projectarchived-{!! $projectlist->projectid.'|'.implode(" ,
                                    ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom" id="tooltipp9" title="Archive"><i
                                    class="fas fa-archive"></i></a>
                            <span class="projectBoxIconsBoxText">Archive</span>
                        </div>
                        @if(in_array(2,$companyInfo->user_type))
                        <div class="projectBoxIconsBox">
                            <a style="cursor:pointer;" id="projectdelete-{!! $projectlist->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom" title="Delete"><i
                                    class="far fa-trash-alt"></i></a>
                            <span class="projectBoxIconsBoxText">Delete</span>
                        </div>
                        @endif
                        <div class="projectBoxIconsBox">
                            <a href="{!! URL::to($projectlist->seourl.'/time-entry-report') !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                title="Time"><i class="far fa-clock"></i></a>
                            <span class="projectBoxIconsBoxText">{!! ($projectlist->totaltime!=NULL ? substr($projectlist->totaltime,0,5) : '00:00') !!}
                                    Hrs</span>
                        </div>
                        <div class="projectBoxIconsBox">
                            @if($projectlist->totalopentasks == 0 && $projectlist->totaltasks > 0)
                            <a href="{!! URL::to($projectlist->seourl.'/completed-todo') !!}" title="to-dos" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                title="All Done"><i class="fas fa-chart-pie"></i></a>
                            <span class="projectBoxIconsBoxText">All Done</span>
                            @else
                            <a href="{!! URL::to($projectlist->seourl.'/todolist') !!}" title="to-dos" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                    title="{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}"><i class="fas fa-chart-pie"></i></a>
                                <span class="projectBoxIconsBoxText">{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}</span>
                            @endif
                        </div>
                    </div>
                </li>
                @elseif($lastalpha == $projectlist->firstalpha)
                <div class="projectListViewBox">
                    <ul class="list-group projectListView">
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="todoListDate"><a href="{!! URL::to($projectlist->seourl) !!}">{!! $projectlist->projectname !!}</a></div>
                                </div>
                            </div>
                            <div class="listViewIcons">
                                <div class="projectBoxIconsBox">
                                    <a style="cursor:pointer;" id="projectarchived-{!! $projectlist->projectid.'|'.implode(" ,
                                            ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom" id="tooltipp9" title="Un-Archive"><i
                                            class="fas fa-archive"></i></a>
                                    <span class="projectBoxIconsBoxText">Un-Archive</span>
                                </div>
                                @if(in_array(2,$companyInfo->user_type))
                                <div class="projectBoxIconsBox">
                                    <a style="cursor:pointer;" id="projectdelete-{!! $projectlist->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom" title="Delete"><i
                                            class="far fa-trash-alt"></i></a>
                                    <span class="projectBoxIconsBoxText">Delete</span>
                                </div>
                                @endif
                                <div class="projectBoxIconsBox">
                                    <a href="{!! URL::to($projectlist->seourl.'/time-entry-report') !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                        title="Time"><i class="far fa-clock"></i></a>
                                    <span class="projectBoxIconsBoxText">{!! ($projectlist->totaltime!=NULL ? substr($projectlist->totaltime,0,5) : '00:00') !!}
                                            Hrs</span>
                                </div>
                                <div class="projectBoxIconsBox">
                                    @if($projectlist->totalopentasks == 0 && $projectlist->totaltasks > 0)
                                    <a href="{!! URL::to($projectlist->seourl.'/completed-todo') !!}" title="to-dos" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                        title="All Done"><i class="fas fa-chart-pie"></i></a>
                                    <span class="projectBoxIconsBoxText">All Done</span>
                                    @else
                                    <a href="{!! URL::to($projectlist->seourl.'/todolist') !!}" title="to-dos" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                            title="{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}"><i class="fas fa-chart-pie"></i></a>
                                        <span class="projectBoxIconsBoxText">{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}</span>
                                    @endif
                                </div>
                            </div>
                        </li>
                @else  
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="todoListDate"><a href="{!! URL::to($projectlist->seourl) !!}">{!! $projectlist->projectname !!}</a></div>
                        </div>
                    </div>
                    <div class="listViewIcons">
                        <div class="projectBoxIconsBox">
                            <a style="cursor:pointer;" id="projectarchived-{!! $projectlist->projectid.'|'.implode(" ,
                                    ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom" title="Un-Archive"><i
                                    class="fas fa-archive"></i></a>
                            <span class="projectBoxIconsBoxText">Un-Archive</span>
                        </div>
                        @if(in_array(2,$companyInfo->user_type))
                        <div class="projectBoxIconsBox">
                            <a style="cursor:pointer;" id="projectdelete-{!! $projectlist->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom" id="tooltipp15" title="Delete"><i
                                    class="far fa-trash-alt"></i></a>
                            <span class="projectBoxIconsBoxText">Delete</span>
                        </div>
                        @endif
                        <div class="projectBoxIconsBox">
                            <a href="{!! URL::to($projectlist->seourl.'/time-entry-report') !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                title="Time"><i class="far fa-clock"></i></a>
                            <span class="projectBoxIconsBoxText">{!! ($projectlist->totaltime!=NULL ? substr($projectlist->totaltime,0,5) : '00:00') !!}
                                    Hrs</span>
                        </div>
                        <div class="projectBoxIconsBox">
                            @if($projectlist->totalopentasks == 0 && $projectlist->totaltasks > 0)
                            <a href="{!! URL::to($projectlist->seourl.'/completed-todo') !!}" title="to-dos" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                title="All Done"><i class="fas fa-chart-pie"></i></a>
                            <span class="projectBoxIconsBoxText">All Done</span>
                            @else
                            <a href="{!! URL::to($projectlist->seourl.'/todolist') !!}" title="to-dos" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                    title="{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}"><i class="fas fa-chart-pie"></i></a>
                                <span class="projectBoxIconsBoxText">{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}</span>
                            @endif
                        </div>
                    </div>
                </li>
                @endif 
                @if(($projectlist->firstalpha == '' && $projectlist->prevFirstAlpha != '') || ($projectlist->firstalpha != $projectlist->nextAlpha) || ($projectlist->firstalpha == $lastalpha)) 
            </ul>
        </div>
        @endif
        <script type="text/javascript">
            lastalpha = "{{$projectlist->firstalpha}}";
        </script>
    @endforeach 
@endif