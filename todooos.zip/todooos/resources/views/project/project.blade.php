@extends('layouts.authprojectwleft')
@section('pageTitle')
Project details
@stop
@section('styles')
{!! Html::style('public/css/bootstrap-datetimepicker.css') !!}
@stop
@section('content')
<div class="m-5">
    <h3>Latest Project Update</h3>
    @if(count($project5updates) > 0)
    <ul class="list-group">
        @foreach($project5updates as $project5update)
        <li class="list-group-item">
            <div class="todoListDate">{{ date("d F, Y",strtotime($project5update->created_at))}}</div>
            <div class="todoListText"> {!! $project5update->username!!} commented on <a href="{{ URL::to($project5update->seourl) }}"
                    class="text-primary">{{ $project5update->taskname}}</a></div>
        </li>
        @endforeach
    </ul>
    <a href="{{ URL::to($project->seourl.'/all-updates') }}" class="text-primary">See all updates</a>
    @endif
</div>

<div class="dropdown-divider m-5"></div>
@if($discussions > 0)
<div class="m-5">
    <h3 class="m-3">Discussions <a href="{{ URL::to($project->seourl.'/discussion/add-discussion') }}" class="btn btn-sm btn-primary">Add
            New</a></h3>
    <div>
        @foreach($discussions as $discussion)
        @if($discussion->description!='')
        <div class="discussionBox">
            <a href="{{ URL::to($discussion->seourl) }}">
                <div class="discussionBoxProfile">
                    @if( $discussion->profilepic !='' &&
                    file_exists('public/img/profile_img/thum/'.$discussion->profilepic))
                    <div class="discussionBoxProfileImg">
                        <img src="{{ URL::asset('img/profile_img/thum/'.$discussion->profilepic) }}" alt="">
                    </div>
                    @else
                    <div class="discussionBoxProfileImg">
                        <img src="{{ URL::asset('img/profileImg.jpg') }}" alt="">
                    </div>
                    @endif
                    <div class="discussionBoxProfileName">
                        <h5>{{ $discussion->username}}</h5>
                        <p>{{ $discussion->email}}</p>
                    </div>
                </div>
                <div class="discussionBoxText">{{ $discussion->taskname}} {!! ($discussion->description!='' ? ' -
                    '.$discussion->description: '') !!}</div>
                <div class="discussionBoxComment">{{ $discussion->totalcomment }}</div>
            </a>
        </div>
        @endif
        @endforeach
    </div>
</div>
@endif

<div class="dropdown-divider m-5"></div>
<div id="ajaxtodolistfilter">
    <div class="m-5">
        <h3 class="m-3">To-do list <a class="btn btn-sm btn-primary addToDoList noLinkButton">Add New</a></h3>
        <div class="roundBox" style="display:none;">
            <form method="post" action="" id="frmlabel">
                @csrf
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>To-do list name:</label>
                            <input type="text" id="labelname" name="labelname" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <input type="submit" id="submitlabel" name="submitlabel" class="btn btn-primary" value="Add to-do list">
                        <input type="button" id="cancellabel" class="btn btn-danger" value="Cancel">
                        <input type="hidden" name="created_bylabel" id="created_bylabel" value="{!! Auth::user()->id !!}">
                        <input type="hidden" name="labelid" id="labelid" value="">
                        <input type="hidden" name="projectid" id="projectid" value="{{ $project->projectid }}">
                        @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type))
                        &nbsp;
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="clientaccess" name="clientaccess" value="1">
                            <label class="form-check-label text-danger" for="clientaccess"><strong>Client can't see this
                                    to-do list </strong></label>
                        </div>
                        @endif
                    </div>
                </div>
            </form>
            <div id="msgdivlabel" class=""></div>
        </div>
        <div id="ajaxtodolist">
            <div id="ajaxtodoadd"></div>
            @if(isset($labeltasks) && count($labeltasks) > 0) 
                @foreach($labeltasks as $label)
                <div class="m-3" id="ajaxtodolistadd-{{ $label->labelid }}">
                    <h5 class="relative"><a href="{{ URL::to($label->seourl) }}">{{ $label->labelname }}</a>
                        @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) ||
                        in_array("3",$companyInfo->user_type) || in_array("4",$companyInfo->user_type))
                        <div class="todoEdit">
                            <a class="text-primary" style="cursor:pointer;" id="deletelabel-{!! $label->labelid !!}"><i class="far fa-trash-alt"></i></a>
                            <a class="text-primary" style="cursor:pointer;" id="editlabel-{!! $label->labelid !!}"><i class="far fa-edit"></i></a>
                        </div>
                        @endif
                    </h5>
                    <div id="ajaxlabel-{!! $label->labelid !!}"></div>
                    <div id="ajaxtasklist-{!! $label->labelid !!}">
                        @include('task.tasklistinc')
                        <div id="ajaxtodoadd-{!! $label->labelid !!}"></div>
                    </div>
                </div>
                @endforeach 
            @endif
        </div>
        @if($totalcompletedtodo > 0 )
        <div>
            <h5> <a class="text-primary" href="{{ URL::to($project->seourl.'/completed-todo') }}">{!! $totalcompletedtodo
                    !!} Completed to-dos </a> across {!! $totalacrosslabel->total !!} to-do lists</h5>
            @if(count($completedtodolists) > 0)
            <h5>Completed lists:
                @foreach($completedtodolists as $completedtodolist)
                @if($completedtodolist->first == 1)
                <a class="text-primary" href="{!! URL::to($completedtodolist->seourl)!!}">{!!$completedtodolist->labelname!!}</a>
                @else,
                <a class="text-primary" href="{!! URL::to($completedtodolist->seourl)!!}">
                    {!!$completedtodolist->labelname!!}</a>
                @endif
                @endforeach
            </h5>
            @endif
        </div>
        @endif
    </div>
</div>
<!-- Notes listing Start -->
<div>
    <div class="dropdown-divider m-5"></div>
    <div class="m-5">
        <h3 class="m-3">Notes <a href="{{ URL::to($project->seourl.'/add-note') }}" class="btn btn-sm btn-primary">Add
                New</a></h3>
        <div class="row">
            <?php $cnt = 0; ?> @foreach($notes as $note) @if($cnt< 6 ) <div class="col-sm-6 col-md-4 col-lg-4 col-xl-3">
                @if(Auth::user()->id == $note->created_by && $note->protect == 1)
                <a href="{!! (Auth::user()->id == $note->created_by ? URL::to($note->seourl) : '')  !!}">
                    <div class="noteBox">
                        <div class="noteImg"><img src="{{ URL::asset( $note->protect == 1 ? 'img/note-lock2.png' : 'img/note.png') }}"
                                alt=""></div>
                        <div class="noteText">
                            <h4>{!! ($note->protect == 1 ? '' : $note->notename) !!}</h4>
                            <p>{!! ($note->protect == 1 ? '' : $note->description) !!}</p>
                        </div>
                    </div>
                </a>
                @elseif(Auth::user()->id == $note->created_by && $note->protect == 0)
                <a href="{!! URL::to($note->seourl) !!}">
                    <div class="noteBox">
                        <div class="noteImg"><img src="{{ URL::asset( $note->protect == 1 ? 'img/note-lock2.png' : 'img/note.png') }}"
                                alt=""></div>
                        <div class="noteText">
                            <h4>{!! ($note->protect == 1 ? '' : $note->notename) !!}</h4>
                            <p>{!! ($note->protect == 1 ? '' : $note->description) !!}</p>
                        </div>
                    </div>
                </a>
                @elseif(Auth::user()->id != $note->created_by && $note->protect == 0)
                <a href="{!! URL::to($note->seourl) !!}">
                    <div class="noteBox">
                        <div class="noteImg"><img src="{{ URL::asset( $note->protect == 1 ? 'img/note-lock2.png' : 'img/note.png') }}"
                                alt=""></div>
                        <div class="noteText">
                            <h4>{!! ($note->protect == 1 ? '' : $note->notename) !!}</h4>
                            <p>{!! ($note->protect == 1 ? '' : $note->description) !!}</p>
                        </div>
                    </div>
                </a>
                @elseif(Auth::user()->id != $note->created_by && $note->protect == 1)
                @if(in_array(Auth::user()->id, $note->shareids))
                <a href="{!! URL::to($note->seourl) !!}">
                    <div class="noteBox">
                        <div class="noteImg"><img src="{{ URL::asset( $note->protect == 1 ? 'img/note-lock2.png' : 'img/note.png') }}"
                                alt=""></div>
                        <div class="noteText">
                            <h4>{!! ($note->protect == 1 ? '' : $note->notename) !!}</h4>
                            <p>{!! ($note->protect == 1 ? '' : $note->description) !!}</p>
                        </div>
                    </div>
                </a>
                @else
                <div class="noteBox">
                    <a style="cursor:pointer !important;" id="sendrequest-{!! $note->noteid !!}">
                        <div class="noteImg"><img src="{{ URL::asset( $note->protect == 1 ? 'img/note-lock.png' : 'img/note.png') }}"
                                alt=""></div>
                    </a>
                    <div class="noteLockCaption"><a href="#" class="btn btn-danger">click here to send access request</a></div>
                </div>
                @endif
                @endif
        </div>
        @endif
        <?php $cnt++;?> @endforeach
    </div>
    <div class="text-center">
        @if(count($notes) > 6)
        <a href="{{ URL::to($project->seourl.'/notes') }}" class="btn btn-primary">{!! count($notes) - 6 !!} More Notes</a>
        @endif
    </div>
</div>
<!-- Notes listing End -->

<!-- Files Listing Start -->
<div class="dropdown-divider m-5"></div>
<h3 class="m-3">Files <a href="{{ URL::to($project->seourl.'/discussion/add-discussion') }}" class="btn btn-sm btn-primary">Add
        New</a></h3>
<div class="row">
    @if(count($projectfiles) > 0) @foreach($projectfiles as $projectfile)
    <div class="col-sm-6 col-md-4 col-lg-4 col-xl-3">
        @if($projectfile->filetypes == 'image')
        <div class="card fileType text-center">
            @if($projectfile->filenewname!='' &&
            file_exists('public/img/comment_files/'.$projectfile->foldername.'/list/'.$projectfile->filenewname))
            <div class="fileTypeImg"><a title="{{ $projectfile->fname}}" href="{!! URL::to('/download/'.$projectfile->foldername.'/'.base64_encode($projectfile->filenewname)) !!}">
                    <img src="{{ URL::asset('img/comment_files/'.$projectfile->foldername.'/list/'.$projectfile->filenewname) }}"
                        alt=""></a></div>
            @else
            <div class="fileTypeImg">
                @if($projectfile->fileextension!='' &&
                file_exists('public/img/iconimg/'.$projectfile->fileextension.'.png'))
                <img src="{{ URL::asset('img/iconimg/'.$projectfile->fileextension.'.png') }}" alt=""> @else
                <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="">
                @endif
            </div>
            @endif
            <div class="card-body">
                <h5 class="card-title" title="{{ $projectfile->fname}}">{{ $projectfile->filename}}</h5>
                <h6>
                    {{ $projectfile->filesize}}
                    </h5>
                    <p class="card-text">By {{ $projectfile->created_by}} At {{
                        date("d-m-Y",strtotime($projectfile->created_at))}}</p>
                    <span class="badge badge-primary">{!!$projectfile->totalcomment!!} coments</span> <span class="badge badge-secondary"><a
                            href="#">Label</a></span>
            </div>
        </div>
        @elseif($projectfile->filetypes == 'other')
        <div class="card fileType text-center">
            @if($projectfile->filenewname!='' &&
            file_exists('public/img/comment_files/'.$projectfile->foldername.'/'.$projectfile->filenewname))
            <div class="fileTypeImg"><a title="{{ $projectfile->fname}}" href="{!! URL::to('/download/'.$projectfile->foldername.'/'.base64_encode($projectfile->filenewname)) !!}">
                    @if($projectfile->fileextension!='' &&
                    file_exists('public/img/iconimg/'.$projectfile->fileextension.'.png'))
                    <img src="{{ URL::asset('img/iconimg/'.$projectfile->fileextension.'.png') }}" alt="">
                    @else
                    <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="">
                    @endif
                </a></div>
            @else
            <div class="fileTypeImg">
                @if($projectfile->fileextension!='' &&
                file_exists('public/img/iconimg/'.$projectfile->fileextension.'.png'))
                <img src="{{ URL::asset('img/iconimg/'.$projectfile->fileextension.'.png') }}" alt=""> @else
                <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="">
                @endif
            </div>
            @endif
            <div class="card-body">
                <h5 class="card-title" title="{{ $projectfile->fname}}">{{ $projectfile->filename}}</h5>
                <h6>
                    {{ $projectfile->filesize}}
                    </h5>
                    <p class="card-text">By {{ $projectfile->created_by}} At {{
                        date("d-m-Y",strtotime($projectfile->created_at))}}</p>
                    <span class="badge badge-primary">{!!$projectfile->totalcomment!!} coments</span> <span class="badge badge-secondary"><a
                            href="#">Label</a></span>
            </div>
        </div>
        @endif
    </div>
    @endforeach @endif
</div>
<div class="text-center">
    @if(isset($totalfiles) && $totalfiles > 12)
    <a href="{{ URL::to($project->seourl.'/files') }}" class="btn btn-primary">{!! $totalfiles - 12 !!} More Files</a>
    @endif
    @if(count($projectfiles) > 1)
    <a href="{!! URL::to('/project/download/'.$project->projectid) !!}" class="btn btn-primary">Download All</a>
    @endif
</div>
<!-- Notes listing End -->
<br>
<!-- Project History Start -->
<div class="dropdown-divider m-5"></div>
<div class="m-5">
    <h5 class="m-3"><a id="projecthistory" style="cursor:pointer;" class="text-primary">By-the-minute history for this project... </a></h5>
    <div class="history" style="display:none;"></div>
</div>
<!-- Project History End -->
</div>
@stop()
@section('scripts')
<script>
    uid = "{{Auth::user()->id}}";
    pid = "{{$project->projectid}}";
</script>
{!! Html::script('js/moment.js') !!}
{!! Html::script('js/bootstrap-datetimepicker.js') !!}
{!! Html::script('js/project.js') !!}
{!! Html::script('js/mastertodo.js') !!}
@stop
