@extends('layouts.authother')
@section('pageTitle')
Projects
@stop
@section('styles')
@stop
@section('content')
<div class="d-flex flex-column flex-sm-row m-3">
    <div>
        <h3>All ({!! (isset($totalproject) ? $totalproject : 0 )!!}) Projects {{($listingtype == 2 ? 'A-Z' : '') }}</h3>
    </div>
    <div class="blankSpace"></div>
    <div id="filter">
        <div class="projectsFilter">
            <select class="js-example-basic-single" name="Filter By Manager" id="managerid" name="managerid">
                <option value="0" selected>Filter By Manager</option>
                @if(isset($managers) && count($managers) > 0) @foreach($managers as $manager)
                <option value="{{ $manager->id }}">{{ $manager->firstname.' '.$manager->lastname }}</option>
                @endforeach @endif
            </select>
        </div>
        <div class="projectsFilter">
            <select class="js-example-basic-single" name="Filter By Status" id="projectstatus" name="projectstatus">
                <option value="10" selected>Filter By Status</option>
                <option value="0">Project presentation</option>
                <option value="1">Project accepted</option>
                <option value="2">Project launched</option>
                <option value="3">Project completed</option>
                <option value="4">Project maintenance</option>
            </select>
        </div>
        @if(count($companyInfo->user_type) > 0) 
            @if(in_array(1,$companyInfo->user_type) || in_array(2,$companyInfo->user_type))
                <div class="projectsFilter">
                    <select class="js-example-basic-single" name="Filter By Clients" id="clientid" name="clientid">
                        <option value="0" selected>Filter By Client</option>
                        @if(isset($clients) && count($clients) > 0) @foreach($clients as $client)
                        <option value="{{ $client->id }}">{{ $client->firstname.' '.$client->lastname }}</option>
                        @endforeach @endif
                    </select>
                </div>
            @endif 
        @endif
        <div class="projectsArchive"><a href="{!! URL::to('/archived-projects') !!}" data-toggle="tooltip" data-placement="bottom"
                title="Archived projects {!! isset($totarchivedproject) ? $totarchivedproject: ''!!}"><i class="fas fa-archive"></i></a></div>
    </div>
</div>
<div class="projectArea clearfix">
    <div class="projectleft">
        <div class="projectsViewIcons">
            <a style="cursor: pointer;" id="listingtype-1" class="text-primary {{($listingtype == 1 ? '' : 'text-info') }}" data-toggle="tooltip" data-placement="bottom" id="tooltipp11" title="Grid View"><i
                    class="fas fa-th-large"></i></a>
            <a style="cursor: pointer;" id="listingtype-2" class="text-primary {{($listingtype == 2 ? '' : 'text-info') }}" data-toggle="tooltip" data-placement="bottom" id="tooltipp12" title="List View"><i
                    class="fas fa-list"></i></a>
            @if(count($companyInfo->user_type) > 0) @if(in_array(1,$companyInfo->user_type) || in_array(2,$companyInfo->user_type) || Auth::user()->createproject == 1)        
            <a href="{!! URL::to('/add-project') !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" id="tooltipp13"
                title="Add Projects"><i class="fas fa-plus-circle"></i></a>
            @endif @endif
                
        </div>
    </div>
    <div class="projectRight">
        @if($listingtype == 1)
        <div class="row" id="ajaxprojectlist">
            @if(isset($projects))
            @foreach($projects as $project)
            <div class="col-md-6 col-lg-4 col-xl-4" id="divproject-{{ $project->projectid }}">
                <div class="projectBox">
                    <div class="addFavIcon">
                        @if($project->favourite == 0)
                        <a style="cursor:pointer;" id="favourite-{!! $project->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" title="Add Favorites"><i class="far fa-star"></i></a>
                        @else
                        <a style="cursor:pointer;" id="unfavourite-{!! $project->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" title="Romove Favorites"><i class="fas fa-star"></i></a>
                        @endif
                    </div>
                    <h3><a href="{!! $project->seourl !!}" title="{!! $project->projectname !!}">{!! $project->projectname !!}</a></h3>
                    <p>Client: {{ $project->inviteclients }} {{ ($project->invitemanagers != '' ? '| Manager: '.$project->invitemanagers: '' ) }}</p>
                    <h5>Status: {!! $project->projectstatus !!}</h5>
                    <p>Created at: {!! date("d F,Y",strtotime($project->created_at)) !!}</p>
                    <ul>
                        @foreach($project->inviteusers as $inviteuser) 
                            @if($inviteuser->profilepic != '' && file_exists('public/images/profile_img/thum/'.$inviteuser->profilepic))
                            <li><a href="{!! (Auth::user()->id == $inviteuser->id ? URL::to('me') : URL::to('user/'.base64_encode($inviteuser->id))) !!}">
                                <img title="{!! $inviteuser->name!!}" src="{{ URL::asset('public/images/profile_img/thum/'.$inviteuser->profilepic) }}" alt="{!! $inviteuser->name!!}"></a></li>
                            @else
                            <li><a href="{!! (Auth::user()->id == $inviteuser->id ? URL::to('me') : URL::to('user/'.base64_encode($inviteuser->id))) !!}"><img src="img/profile-placeholder.png')}}" alt=""><span class="userName">{!! $inviteuser->logoname !!}</span></a></li>
                            @endif
                        @endforeach
                        @for($i = 1; $i <= 9 - count($project->inviteusers); $i++ )
                        <li><img src="{{ URL::asset('img/profileImg.jpg')}}" alt="blank"></li>
                        @endfor
                        <li class="plusIcon"><a href="{!! URL::to($project->seourl.'/invite') !!}"><img src="{{ URL::asset('img/plus.png')}}" alt=""></a></li>
                    </ul>
                    <div class="projectBoxIcons">
                        <div class="projectBoxIconsBox">
                            <a style="cursor:pointer;" id="projectarchived-{!! $project->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" title="Archive" data-toggle="tooltip" data-placement="bottom"><i
                                    class="fas fa-archive"></i></a>
                            <span class="projectBoxIconsBoxText">Archive</span>
                        </div>
                        @if(in_array(2,$companyInfo->user_type))
                        <div class="projectBoxIconsBox">
                            <a style="cursor:pointer;" id="projectdelete-{!! $project->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" title="Delete" data-toggle="tooltip" data-placement="bottom"><i
                                    class="far fa-trash-alt"></i></a>
                            <span class="projectBoxIconsBoxText">Delete</span>
                        </div>
                        @endif
                        <span class="blankSpace"></span>
                        <div class="projectBoxIconsBox">
                            <a href="#" data-toggle="tooltip" data-placement="bottom" id="tooltipp15" title="Medium"><i
                                    class="fas fa-exclamation-circle"></i></a>
                            <span class="projectBoxIconsBoxText">Medium</span>
                        </div>
                        <span class="blankSpace"></span>
                        <div class="projectBoxIconsBox">
                            <a href="{!! URL::to($project->seourl.'/time-entry-report') !!}" title="Time" class="text-primary" data-toggle="tooltip" data-placement="bottom"><i class="far fa-clock"></i></a>
                            <span class="projectBoxIconsBoxText">{!! ($project->totaltime!=NULL ? substr($project->totaltime,0,5) : '00:00') !!} Hrs</span>
                        </div>
                        <div class="projectBoxIconsBox">
                            @if($project->totalopentasks == 0 && $project->totaltasks > 0)
                            <a href="{!! URL::to($project->seourl.'/completed-todo') !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" id="tooltipp10"
                                title="{!! $project->totalopentasks !!}/{!! $project->totaltasks !!}"><i class="fas fa-chart-pie"></i></a>
                            <span class="projectBoxIconsBoxText">All Done</span>
                            @else
                            <a href="{!! URL::to($project->seourl.'/todolist') !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" id="tooltipp10"
                                title="{!! $project->totalopentasks !!}/{!! $project->totaltasks !!}"><i class="fas fa-chart-pie"></i></a>
                            <span class="projectBoxIconsBoxText">{!! $project->totalopentasks !!}/{!! $project->totaltasks !!}</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <script type="text/javascript">
                lastalpha = "{{$project->firstalpha}}";
            </script> 
            @endforeach @endif
        </div>
        @else
        <div id="ajaxprojectlist">
            @if(count($projects) > 0)
                @foreach($projects as $projectlist) 
                    @if($projectlist->prevFirstAlpha == '')
                    <div class="projectListViewBox">
                        <h2 class="text-primary m-1">{!! $projectlist->firstalpha !!}</h2>
                        <ul class="list-group projectListView">
                            <li class="list-group-item">
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="todoListDate"><a href="{!! URL::to($projectlist->seourl) !!}" title="{!! $projectlist->projectname !!}">{!! $projectlist->projectname !!}</a></div>
                                        <div class="todoListStatus">Status: <strong>{!! $projectlist->projectstatus !!}</strong></div>
                                        <div class="todoListText">Client: {{ $projectlist->inviteclients }} | {{ ($projectlist->invitemanagers != '' ? 'Manager: '.$projectlist->invitemanagers.' | ': '' ) }} Created at: {!! date("d F, Y",strtotime($projectlist->created_at))
                                                !!}</div>
                                    </div>
                                </div>
                                <div class="listViewIcons">
                                    <div class="projectBoxIconsBox">
                                        @if($projectlist->favourite == 0)
                                            <a style="cursor:pointer;" id="favourite-{!! $projectlist->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" title="Add Favorites"><i class="far fa-star"></i></a>
                                        @else
                                            <a style="cursor:pointer;" id="unfavourite-{!! $projectlist->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" id="tooltipp8" title="Remove Favorites"><i class="fas fa-star"></i></a>
                                        @endif
                                    </div>
                                    <div class="projectBoxIconsBox">
                                        <a style="cursor:pointer;" id="projectarchived-{!! $projectlist->projectid.'|'.implode(" ,
                                                ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom" id="tooltipp9" title="Archive"><i
                                                class="fas fa-archive"></i></a>
                                        <span class="projectBoxIconsBoxText">Archive</span>
                                    </div>
                                    @if(in_array(2,$companyInfo->user_type))
                                    <div class="projectBoxIconsBox">
                                        <a style="cursor:pointer;" id="projectdelete-{!! $projectlist->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom" id="tooltipp15" title="Delete"><i
                                                class="far fa-trash-alt"></i></a>
                                        <span class="projectBoxIconsBoxText">Delete</span>
                                    </div>
                                    @endif
                                    <div class="projectBoxIconsBox">
                                        <a href="{!! URL::to($projectlist->seourl.'/time-entry-report') !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                            title="Time"><i class="far fa-clock"></i></a>
                                        <span class="projectBoxIconsBoxText">{!! ($projectlist->totaltime!=NULL ? substr($projectlist->totaltime,0,5) : '00:00') !!}
                                                Hrs</span>
                                    </div>
                                    <div class="projectBoxIconsBox">
                                        @if($projectlist->totalopentasks == 0 && $projectlist->totaltasks > 0)
                                        <a href="{!! URL::to($projectlist->seourl.'/completed-todo') !!}" title="to-dos" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                            title="All Done"><i class="fas fa-chart-pie"></i></a>
                                        <span class="projectBoxIconsBoxText">All Done</span>
                                        @else
                                        <a href="{!! URL::to($projectlist->seourl.'/todolist') !!}" title="to-dos" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                                title="{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}"><i class="fas fa-chart-pie"></i></a>
                                            <span class="projectBoxIconsBoxText">{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}</span>
                                        @endif
                                    </div>
                                </div>
                            </li>
                            @else  
                            <li class="list-group-item">
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="todoListDate"><a href="{!! URL::to($projectlist->seourl) !!}">{!! $projectlist->projectname !!}</a></div>
                                        <div class="todoListStatus">Status: <strong>{!! $projectlist->projectstatus !!}</strong></div>
                                        <div class="todoListText">Client: {{ $projectlist->inviteclients }} | {{ ($projectlist->invitemanagers != '' ? 'Manager: '.$projectlist->invitemanagers.' | ': '' ) }} Created at: {!! date("d F, Y",strtotime($projectlist->created_at))
                                                !!}</div>
                                    </div>
                                </div>
                                <div class="listViewIcons">
                                    <div class="projectBoxIconsBox">
                                        @if($projectlist->favourite == 0)
                                            <a style="cursor:pointer;" id="favourite-{!! $projectlist->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" title="Add Favorites"><i class="far fa-star"></i></a>
                                        @else
                                            <a style="cursor:pointer;" id="unfavourite-{!! $projectlist->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" id="tooltipp8" title="Remove Favorites"><i class="fas fa-star"></i></a>
                                        @endif
                                    </div>
                                    <div class="projectBoxIconsBox">
                                        <a style="cursor:pointer;" id="projectarchived-{!! $projectlist->projectid.'|'.implode(" ,
                                                ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom" id="tooltipp9" title="Archive"><i
                                                class="fas fa-archive"></i></a>
                                        <span class="projectBoxIconsBoxText">Archive</span>
                                    </div>
                                    @if(in_array(2,$companyInfo->user_type))
                                    <div class="projectBoxIconsBox">
                                        <a style="cursor:pointer;" id="projectdelete-{!! $projectlist->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" data-toggle="tooltip" data-placement="bottom" id="tooltipp15" title="Delete"><i
                                                class="far fa-trash-alt"></i></a>
                                        <span class="projectBoxIconsBoxText">Delete</span>
                                    </div>
                                    @endif
                                    <div class="projectBoxIconsBox">
                                        <a href="{!! URL::to($projectlist->seourl.'/time-entry-report') !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                            title="Time"><i class="far fa-clock"></i></a>
                                        <span class="projectBoxIconsBoxText">{!! ($projectlist->totaltime!=NULL ? substr($projectlist->totaltime,0,5) : '00:00') !!}
                                                Hrs</span>
                                    </div>
                                    <div class="projectBoxIconsBox">
                                        @if($projectlist->totalopentasks == 0 && $projectlist->totaltasks > 0)
                                        <a href="{!! URL::to($projectlist->seourl.'/completed-todo') !!}" title="to-dos" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                            title="All Done"><i class="fas fa-chart-pie"></i></a>
                                        <span class="projectBoxIconsBoxText">All Done</span>
                                        @else
                                        <a href="{!! URL::to($projectlist->seourl.'/todolist') !!}" title="to-dos" class="text-primary" data-toggle="tooltip" data-placement="bottom"
                                                title="{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}"><i class="fas fa-chart-pie"></i></a>
                                            <span class="projectBoxIconsBoxText">{!! $projectlist->totalopentasks !!}/{!! $projectlist->totaltasks !!}</span>
                                        @endif
                                    </div>
                                </div>
                            </li>
                            @endif 
                            @if(($projectlist->firstalpha == '' && $projectlist->prevFirstAlpha != '') || ($projectlist->firstalpha != $projectlist->nextAlpha) ) 
                        </ul>
                    </div>
                    @endif
                    <script type="text/javascript">
                        lastalpha = "{{$projectlist->firstalpha}}";
                    </script> 
                @endforeach 
            @endif
        </div>
        @endif 
    </div>
    {{-- <div class="ajax-loading text-center col-md-12"><img src="{{ asset('public/img/loading.gif') }}" /></div> --}}
</div>
@stop()
@section('scripts')
<script>
    uid = "{{Auth::user()->id}}"
</script>
{!! Html::script('js/projectlist.js') !!}   
@stop
