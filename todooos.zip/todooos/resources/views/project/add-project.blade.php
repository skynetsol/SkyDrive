@extends('layouts.authproject')
@section('pageTitle')
Add project
@stop
@section('styles')
@stop
@section('content')
    
<form method="post" action="" id="frmproject">
 @csrf
<div class="inviteTab">
    <div class="m-5">
        <div class="form-group"><input type="text" id="pprojectname" name="pprojectname" class="form-control" placeholder="Type your project name."></div>
        <div class="form-group">
            <textarea rows="4" id="projectdescription" name="projectdescription" class="form-control" placeholder="Type your project description here."></textarea>
        </div>
    </div>
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
            aria-selected="true">Our Team</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile"
            aria-selected="false">The Client</a>
        </li>
        {{-- <li class="nav-item">
            <a class="nav-link" id="estimate-tab" data-toggle="tab" href="#estimate" role="tab" aria-controls="estimate"
            aria-selected="false">Estimate</a>
        </li> --}}
    </ul>
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
            <div class="row">
                <div class="col-md-6 inviteBorder">
                    <div class="m-5">
                        <div class="form-group">
                            <h5>Type names or emails to invite people to your team:</h5>
                            <select class="js-example-basic-single-email form-control" name="email[]" id="email" multiple>
                                @if($users) > 0 )
                                @foreach($users as $user)
                                <option value="{{ $user->email }}">{{ $user->firstname." ".$user->lastname }}</option>
                                @endforeach
                                @endif
                            </select>
                        </div>
                        <div class="form-group">
                            <h5>Add a welcome message for your team:</h5>
                            <textarea rows="4" class="form-control" id="mailtext" name="mailtext" placeholder="Hi, there. We'll be using todooos to share ideas, gather feedback, and track progress during this project."></textarea>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 inviteBorder2">
                    <p>Anyone on your team will see everything posted to this project. Every message, todo-list, file,event, and text document.</p>
                    <!-- <div class="media meProfile inviteMedia"> <img class="meProfileImg" src="img/profileImg.jpg"
                            alt="">
                        <div class="media-body">
                            <h5 class="mt-0">Arindam Chaudhuri</h5>
                            <p>info@skynetsol.com</p>
                        </div>
                    </div>
                    <div class="media meProfile inviteMedia"> <img class="meProfileImg" src="img/profileImg.jpg"
                            alt="">
                        <div class="media-body">
                            <h5 class="mt-0">Satinath Mondal</h5>
                            <p>satinath@gmail.com</p>
                        </div>
                    </div>
                    <div class="media meProfile inviteMedia"> <img class="meProfileImg" src="img/profileImg.jpg"
                            alt="">
                        <div class="media-body">
                            <h5 class="mt-0">Jayanta Mondal</h5>
                            <p>jayanta@skynetonline.info</p>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
            <div class="row" id="withclientlist" style="display:none;">
                <div class="col-md-6 inviteBorder">
                    <div class="m-5">
                        <div class="form-group">
                            <h5>Type names or emails to invite people from your clients:</h5>
                            <select class="js-example-basic-single-cemail form-control"  name="cemail[]" id="cemail" multiple>
                                @if(count($users) > 0 ) 
                                @foreach($users as $user) 
                                    <option value="{{ $user->email }}">{{ $user->firstname." ".$user->lastname }}</option>
                                @endforeach 
                                @endif
                            </select>
                        </div>
                        <div class="form-group">
                            <h5>Add a welcome message for your clients:</h5>
                            <textarea rows="4" class="form-control" id="cmailtext" name="cmailtext" placeholder="Hi, there. We'll be using todooos to share ideas, gather feedback, and track progress during this project."></textarea>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 inviteBorder2">
                    <p>Anyone from your clients will see certain messages, to-dos, files, events, and text documents that you allow them to see.</p>
                    <!-- <div class="media meProfile inviteMedia"> <img class="meProfileImg" src="img/profileImg.jpg" alt="">
                        <div class="media-body">
                            <h5 class="mt-0">Cory Maier</h5>
                            <p>cory@jasonhunterdesign.com</p>
                        </div>
                    </div>
                    <div class="media meProfile inviteMedia"> <img class="meProfileImg" src="img/profileImg.jpg"
                            alt="">
                        <div class="media-body">
                            <h5 class="mt-0">Jason Bass</h5>
                            <p>jason@jasonhunterdesign.com</p>
                        </div>
                    </div> -->
                </div>
            </div>
            <div class="m-5" id="withoutclientlist">
                <div class="row">
                  <div class="col-md-6">
                    <div class="m-5">
                      <h3>Working with a client on this project?</h3>
                      <p>Todooos lets you hide certain messages, to-dos, files, events, and text documents from people
                        invited as clients. This is great for sharing unfinished work with your team before getting
                        client feedback.</p>
      
                      <p>You can turn this on now to start choosing what clients can see, even if you’re not ready to
                        invite any clients yet.</p>
                      <a style="cursor:pointer;" class="btn btn-primary noLinkButton" id="showTrigger">Yes, turn on client access for this project</a>
      
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="circleImg"><img src="{{ URL::asset('public/img/circleimg.jpg')}}" alt=""></div>
                  </div>
                </div>
            </div>
        </div>
        <!-- <div class="tab-pane fade" id="estimate" role="tabpanel" aria-labelledby="estimate-tab">
            <div class="row">
                <div class="col-md-6 inviteBorder">
                    <div class="m-5">
                        <h3>Rates</h3>
                        <div class="form-group m-4">
                            <h5>Client</h5>
                            <select class="js-example-basic-single" name="People Name" multiple="multiple">
                                <option>People Name</option>
                                <option>People Name</option>
                                <option>People Name</option>
                                <option>People Name</option>
                            </select>
                        </div>
                        <div class="form-group m-4">
                            <h5>Billing Method</h5>
                            <select class="js-example-basic-single2" name="Billing Method">
                                <option>Flat Project Amount</option>
                                <option>Hourly Project Rate</option>
                                <option>Hourly Task Rate</option>
                                <option>Hourly Staff Rate</option>
                            </select>
                        </div>
                        <div class="form-group m-4">
                            <h5>Project Rate <i class="fas fa-info-circle" data-toggle="tooltip" data-placement="bottom"
                                    id="tooltipp2" title="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the"></i></h5>
                            <div class="input-group">
                                <input type="text" class="form-control" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2">Per hour</span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group m-4">
                            <h5>Time Estimate <i class="fas fa-info-circle" data-toggle="tooltip" data-placement="bottom"
                                    id="tooltipp2" title="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the"></i></h5>
                            <div class="input-group">
                                <input type="text" class="form-control" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2">Hours</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 inviteBorder2">
                    <h3>Todo list</h3>
                    <div class="m-4">
                        <div class="list2">
                            <ul>
                                <li><a href="#" class="text-danger"><i class="fas fa-minus-circle"></i></a> Todo
                                    name <span class="text-muted">billable</span></li>
                                <li><a href="#" class="text-danger"><i class="fas fa-minus-circle"></i></a> Todo
                                    name <span class="text-muted">billable</span></li>
                                <li><a href="#" class="text-danger"><i class="fas fa-minus-circle"></i></a> Todo
                                    name <span class="text-muted">billable</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="form-group m-4">
                        <div class="d-flex row flex-row bd-highlight mb-3">
                            <div class="col-md-7">
                                <select class="js-example-basic-single2" name="Select a task">
                                    <option>Select a task</option>
                                    <option>Option</option>
                                    <option>Option</option>
                                    <option>Option</option>
                                    <option>Option</option>
                                </select>
                            </div>
                            <div class="col-md-1 align-self-center text-center">
                                <h4 class="m-0">or</h4>
                            </div>
                            <div class="col-md-4 align-self-center">
                                <p class="m-0"><a href="#" class="text-danger"><i class="fas fa-minus-circle"></i>
                                        Remove all
                                        tasks</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="form-group">
            <input type="hidden" name="companyid" id="companyid" value="{!! $companyInfo->companyid !!}">
            <input type="hidden" name="created_byproject" id="created_byproject" value="{!! Auth::user()->id !!}">
            <input type="submit" class="btn btn-primary" value="Submit" id="submitproject">
            <input type="hidden" value="C" id="invitetype" name="invitetype">
            <input type="hidden" value="{!! Auth::user()->id !!}" id="created_by" name="created_by">
            <input type="hidden" name="timezone" id="timezone" value="">
        </div>
        <div id="msgdivproject" class=""></div>
    </div>
</div>
</form>
@stop()
@section('scripts')
{!! Html::script('js/jstz.js') !!}
<script>
    var tz = jstz.determine();
    var clientlistview = 0;
    uid = "{{Auth::user()->id}}";
    $(".js-example-basic-single-email").select2({
        placeholder: "The person you select will be notified by email",
        tags: true,
        tokenSeparators: [',']
    });

    $("#cemail").select2({
        placeholder: "The person you select will be notified by email",
        tags: true,
        tokenSeparators: [',']
    });
</script>
{!! Html::script('js/addproject.js') !!}
@stop
