@extends('layouts.error')
@section('pageTitle')
Error Expired
@stop   
@section('content')
    <h3>Expired</h3>
    <h2 class="m-1 text-muted">Sorry but access denied</h2>
    <p>Your company have been expired, Upgrade to a paid account.</p>
    <p><a href="{{ url('/buyandupgrade') }}"  class="text-primary"><i class="fas fa-undo-alt"></i> Upgrade to a paid account</a> <span class="errorDevider">|</span> <a href="{{ url('/profile') }}" class="text-primary"><i class="fas fa-home"></i> Go to the profile page</a></p>
@stop() 