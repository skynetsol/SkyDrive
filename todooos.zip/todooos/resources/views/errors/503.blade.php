@extends('layouts.error')
@section('pageTitle')
Error 503
@stop
@section('content')
    <h1>503</h1>
    <h2 class="m-1 text-muted">Sorry but access denied</h2>
    <p>The content may have been removed, or is temporarily unavailable.</p>
    <p><a href="javascript:void(0);" onClick="history.go(-1)" class="text-primary"><i class="fas fa-undo-alt"></i> Go back to the previous page</a> <span class="errorDevider">|</span> <a href="{{ url('/') }}" class="text-primary"><i class="fas fa-home"></i> Go to the home page</a></p>
@stop() 