@extends('layouts.error')
@section('pageTitle')
Error Expired
@stop
@section('content')
    <h3>Expired</h3>
    <h2 class="m-1 text-muted">Sorry but access denied</h2>
    <p>This Company has been expired, Please contact with Company Owner.</p>
    <p><a href="{{ url('/profile') }}" class="text-primary"><i class="fas fa-home"></i> Go to the profile page</a></p>
@stop() 
