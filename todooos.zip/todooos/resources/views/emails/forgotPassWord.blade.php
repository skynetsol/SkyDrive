<div style="font-family:Tahoma, Geneva, sans-serif; color:#4e4e4e; font:16px; padding-top:10px;">
  <table width="100%" style="max-width:600px;" border="0" align="center" cellpadding="0" cellspacing="0">
<!--header start-->
    <tr>
      <td style="text-align:left; padding-bottom:80px; padding-top:30px;"><img src="{{ URL::asset('public/img/login-logo.png') }}" alt="Logo"/></td>
    </tr>
<!--header end--> 
    
<!--body start-->
    <tr>
      <td><h2 style="margin:0px;  padding:0 0 30px 0; font-size:30px; font-weight:normal;">Hello {{ ucfirst($mailvar['firstname']) }},</h2>
        <p style="padding:0; margin:0 0 30px 0; line-height:24px; color:#4e4e4e;">Looks like you've forgotten your password. Happens to the best of us. We can help you reset it — just click below!</p></td>
    </tr>
    <tr>
      <td style="text-align:center; padding-bottom:20px;"><a href="{{ URL::to('resetpassword/' . $mailvar['keycode']) }}" style="font-size:16px; display:inline-block; padding:20px 30px; background-color:#004fff; color:#fff; text-decoration:none; font-weight:bold;">Click here</a></td>
    </tr>
    <tr>
      <td style="text-align:center; padding-bottom:10px; color:#000; font-weight:bold; font-size:16px;">OR</td>
    </tr>
    <tr>
      <td style="text-align:center;"><a href="#" style="color:#004fff; text-decoration:none;">Copy the url to your browser and press enter: {{ URL::to('resetpassword/' . $mailvar['keycode']) }} </a></td>
    </tr>
<!--body end--> 
    
<!--footer start-->
    <tr>
      <td height="50">&nbsp;</td>
    </tr>
    <tr>
      <td style="border-top:dashed 1px #cecece; border-bottom:dashed 1px #cecece; padding-top:15px; padding-bottom:15px;"><span style="color:#8b8b8b; display:block; text-align:center; font-size:13px; line-height:20px;">todooos is a Project management tool to help manage project efficiently, engage and collaborate on projects related collateral.</span></td>
    </tr>
    <tr>
      <td style=" padding-top:15px;"><p style="margin:0px; padding:0 0 10px 0; font-size:12px; text-align:center; line-height:20px; color:#7f8180;padding-bottom:20px;">do you Need help? or have any questions then email us <a href="mailto:support@todooos.com" style="text-decoration:none; color:#004fff;">support@todooos.com</a><br>
          learn more about todooos <a href="{{ url('/') }}" target="_blank" style="text-decoration:none; color:#004fff;">www.todooos.com</a></p></td>
    </tr>
<!--footer end-->
  </table>
</div>