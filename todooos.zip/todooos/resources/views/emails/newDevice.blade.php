<div style="font-family:Tahoma, Geneva, sans-serif; color:#4e4e4e; font:16px; padding-top:10px;">
  <table width="100%" style="max-width:600px;" border="0" align="center" cellpadding="0" cellspacing="0">
<!--header start-->
    <tr>
      <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
              <td style="text-align:left; padding-bottom:80px; padding-top:30px;"><img src="{{ URL::asset('public/img/login-logo.png') }}" alt="Logo" /></td>
              <td style="text-align:right; padding-bottom:80px; padding-top:30px;">{{ $mailvar['name'] }} &nbsp;&nbsp;<img style="border-radius:50%; margin-left:15px; max-height:50px; max-width:50px; vertical-align:middle;" src="{{ URL::asset('public/images/profile_img/thum/'.$mailvar['profilePic']) }}" alt="{{$mailvar['name']}}" /></td>
          </tr>
        </table>
      </td>
    </tr>
<!--header end--> 
    
<!--body start-->
    <tr>
      <td><h2 style="text-align:center; margin:0px;padding:0 0 30px 0;font-size:30px;font-weight:normal;">New device signed in to</h2>
        <p style="text-align:center; padding:0; margin:0 0 30px 0; line-height:24px; color:#4e4e4e;">{{ $mailvar['email'] }}</p></td>
    </tr>
    <tr>
      <td height="50">&nbsp;</td>
    </tr>
    <tr>
      <td style=" text-align:center; padding-bottom:30px;"><p style="padding:0; margin:0 0 30px 0; color:#4e4e4e; line-height:24px;">Your Todooos Account was just signed in to from a new {{ $mailvar['devicetype'] }} device. You are getting this email to make sure it was you.</p></td>
    </tr>
    <tr>
      <td style="text-align:center; padding-bottom:20px;"><a href="{{ URL::to($mailvar['checkActivity']) }}" style="font-size:16px; display:inline-block; padding:20px 30px; background-color:#004fff; color:#fff; text-decoration:none; font-weight:bold;">CHECK ACTIVITY</a></td>
    </tr>
    
<!--body end--> 
    
<!--footer start-->
    <tr>
      <td height="50">&nbsp;</td>
    </tr>
    <tr>
      <td style="border-top:dashed 1px #cecece; border-bottom:dashed 1px #cecece; padding-top:15px; padding-bottom:15px;"><span style="color:#8b8b8b; display:block; text-align:center; font-size:13px; line-height:20px;">todooos is a Project management tool to help manage project efficiently, engage and collaborate on projects related collateral.</span></td>
    </tr>
    <tr>
      <td style=" padding-top:15px;"><p style="margin:0px; padding:0 0 10px 0; font-size:12px; text-align:center; line-height:20px; color:#7f8180;padding-bottom:20px;">do you Need help? or have any questions then email us <a href="mailto:support@todooos.com" style="text-decoration:none; color:#004fff;">support@todooos.com</a><br>
          learn more about todooos <a href="{{ url('/') }}" target="_blank" style="text-decoration:none; color:#004fff;">www.todooos.com</a></p></td>
    </tr>
<!--footer end-->
  </table>
</div>