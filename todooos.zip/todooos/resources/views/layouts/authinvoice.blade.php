<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Todooos - @yield('pageTitle')</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="icon" type="image/png" href="{{ asset('public/img/favicon.ico') }}">
    {!! Html::style('public/css/bootstrap.css') !!}
    {!! Html::style('public/css/fontawesome-all.css') !!}
    {!! Html::style('public/css/formValidation.css') !!}
    {!! Html::style('public/css/fonts.css') !!}
    {!! Html::style('public/css/select2.css') !!}
    {!! Html::style('public/css/jquery.mCustomScrollbar.css') !!}
    {!! Html::style('public/css/jquery.dataTables.min.css') !!}
    {!! Html::style('public/css/responsive.dataTables.min.css') !!}
    {!! Html::style('public/css/style.css') !!}
    {!! Html::style('public/css/own.css') !!}
    @yield('styles')

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

    @include('includes.authheader')
    
    <div class="authother">
        <section class="jumbotron">
            <div class="container-fluid">
                @yield('contentheader')
            </div>
        </section>  
        @include('includes.authinvsubheader')   
        <section class="bg-white p-4">
            <div class="container-fluid">
                @yield('content')
            </div>
        </section>
    </div>
    
    @include('includes.authfooter')
    @include('includes.authrightpanel')
    <script type="text/javascript">
        var sitepath = "{{ URL::to('/') }}";
        var uid = "{{Auth::user()->id}}";
    </script>
    {!! Html::script('js/jquery.min.js') !!}
    {!! Html::script('js/popper.js') !!}
    {!! Html::script('js/bootstrap.js') !!}
    {!! Html::script('js/formValidation.js') !!}
    {!! Html::script('js/bootstrapfrm.js') !!}
    {!! Html::script('js/custom.js') !!}
    {!! Html::script('js/select2.full.js') !!}
    {!! Html::script('js/jquery.mCustomScrollbar.concat.min.js') !!}
    {!! Html::script('js/jquery.dataTables.min.js') !!}
    {!! Html::script('js/dataTables.responsive.min.js') !!} 
    {!! Html::script('js/dataTables.tableTools.js') !!} 
    {!! Html::script('js/jstz.js') !!}
    {!! Html::script('js/rightpanel.js') !!}
    <script>
        $(document).ready(function () {
            $('.js-example-basic-single').select2();
            $('#toolme, #tooleveryone, #toolprojects, #toolsearch, #totalcommentview, #tooltipp6, #tooltipp7').tooltip('enable');
        });
    </script>
    <script>
        (function ($) {
            $(window).on("load", function () {
                $("#content-2").mCustomScrollbar({
                    autoHideScrollbar: true,
                    scrollInertia: 500,
                    mouseWheel: {
                        scrollAmount: 300
                    },
                    theme: "rounded"
                });

            });
        })(jQuery);
    </script>
    @yield('scripts')
</body>
</html>
