<section class="subHeader">
    <div class="container-fluid">
        <div class="d-flex flex-column flex-md-row">
        <div class="align-self-md-center">
            <ul class="nav justify-content-center">
                <li><a href="{{ URL::to('/pending-invoicelist') }}">Pending Invoices</a></li>
                <li><a href="{{ URL::to('/invoicelist') }}">Invoices</a></li>
                <li><a href="#">Recuring</a></li>
                <li><a href="{{ URL::to('/received-invoicelist') }}">Received</a></li>
                <li><a href="#">Payments</a></li>
                <li><a href="#">Credits</a></li>
                <li><a href="#">Items</a></li>    
            </ul>
        </div>
        </div>
    </div>
</section>