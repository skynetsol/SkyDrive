<section class="jumbotron">
    <div class="container-fluid">
        <div class="d-flex flex-sm-row flex-column">
            <div class="flex-fill align-self-sm-center">
                {{-- For other user --}}
                @if(isset($user->profilepic) && $user->profilepic != '')
                    <div class="media meProfile">
                        @if($user->profilepic != '' && File::exists('public/img/profile_img/thum/'.$user->profilepic)) 
                        <img class="meProfileImg" src="{{ URL::asset('img/profile_img/thum').'/'.$user->profilepic }}" alt="{!! $user->firstname!!}"> 
                        @else 
                        <div class="profileNoImg">{!! substr($user->firstname,0,1)."".substr($user->lastname,0,1)!!}</div>
                        @endif
                        <div class="media-body">
                            <h5 class="mt-0">{!! ucfirst($user->firstname)." ".ucfirst($user->lastname)!!}</h5>
                            <p>{!! $user->email!!}</p>
                        </div>
                    </div>
                @else
                {{-- For Auth user --}}
                <div class="media meProfile">
                    @if(Auth::user()->profilepic != '' && File::exists('public/img/profile_img/thum/'.Auth::user()->profilepic)) 
                    <img class="meProfileImg" src="{{ URL::asset('img/profile_img/thum').'/'.Auth::user()->profilepic }}" alt="{!! Auth::user()->firstname!!}"> 
                    @else 
                    <div class="profileNoImg">{!! substr(Auth::user()->firstname,0,1)."".substr(Auth::user()->lastname,0,1)!!}</div>
                    @endif
                    <div class="media-body">
                        <h5 class="mt-0">{!! ucfirst(Auth::user()->firstname)." ".ucfirst(Auth::user()->lastname)!!}</h5>
                        <p>{!! Auth::user()->email!!}</p>
                    </div>
                </div>
                @endif
            </div>
            <div class="flex-fill align-self-md-center text-right">
                @if(isset($user->profilepic) && $user->profilepic != '')
                    @if(count($companyInfo->user_type) > 0)
                        @if(in_array(1,$companyInfo->user_type) || in_array(2,$companyInfo->user_type))
                            <div class="profileRight">
                                <ul>
                                    <li> 
                                        <a href="{{ URL::to('/usersuperpowers') }}">
                                            <h5>Manage {!! $user->firstname!!}'s Access</h5>
                                            <p>Manage {!! $user->firstname!!}'s projects and power </p>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        @endif
                    @endif
                @else
                    <div class="profileRight">
                        <ul>
                            <li> <a href="{{ URL::to('/profile') }}">
                                    <h5>Update your personal information</h5>
                                    <p>Name, photo, time zone, password… </p>
                                </a> </li>
                            <li> <a href="{{ URL::to('/mysettings') }}">
                                    <h5>Your todooos settings</h5>
                                    <p>Email address, notifications, calendar… </p>
                                </a> </li>
                        </ul>
                    </div>
                @endif
            </div>
        </div>
    </div>
</section>