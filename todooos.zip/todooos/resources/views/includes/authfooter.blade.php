<footer>
    <div class="container-fluid">
        <div class="row">
        <div class="col-sm-6 text-center text-sm-left">
            <ul>
            <li><a href="#">Privacy/Legal</a></li>
            </ul>
        </div>
        <div class="col-sm-6 text-center text-sm-right">
            <p>© {{date('Y')}} <a href="#" class="text-primary">todooos</a></p>
        </div>
        </div>
    </div>
</footer>