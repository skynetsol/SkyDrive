<section class="subHeader">
    <div class="container-fluid">
        <div class="d-flex flex-column flex-md-row">
            <div class="align-self-md-center">
                <ul class="nav justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link projectMenuBtn" style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom"
                            id="tooltipp1" title="New"><i class="fas fa-bars"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ URL::to('project/'.$project->seoname.'/discussion') }}">{!!$totaldiscussion!!} Discussions</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ URL::to($project->seourl.'/todolist') }}">{{$totaltask}} To-dos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ URL::to($project->seourl.'/files') }}">{{$totalfiles}} Files</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ URL::to($project->seourl.'/notes') }}">{{$totalnotes}} Notes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="events.html">Events</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ URL::to($project->seourl.'/time-entry-report') }}">Time Entry @if ($project->created_by == Auth::user()->id || $companyInfo->created_by == Auth::user()->id)
                                <input {{ ($project->timeentry == 1 ? 'checked' : '') }} type="checkbox" id="timeentry-{!! $project->projectid!!}" name="timeentry" >@endif <span class="text-primary">{!! $totaltimeentry !!}</span></a>
                    </li>
                </ul>
            </div>
            @if($page =='add')
            <div class="noteHead align-self-center">
                <span class="noteTitle">
                        <span id="spaninput"><input type="text" class="form-control noteTitleField" id="newnotename" name="newnotename" value="{{isset($note->notename) ? $note->notename : 'Untitle'}}"></span>
                        <a href="#" class="noteRename" data-toggle="tooltip" data-placement="bottom" id="rename" title="Rename"><i class="fas fa-edit"></i></a>
                </span>
                <span class="meProfileIcon">
                    <a style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" id="savenote" title="Save"><i class="far fa-save"></i></a>
                </span>
            </div>
            @elseif($page =='edit')
            <div class="noteHead align-self-center">
                <span class="noteTitle">
                    <span id="spaninput"><input type="text" class="form-control noteTitleField" id="newnotename" name="newnotename" value="{{$note->notename}}"></span>
                    <a href="#" class="noteRename" data-toggle="tooltip" data-placement="bottom" id="rename" title="Rename"><i class="fas fa-edit"></i></a>
                </span>
                <span class="meProfileIcon">
                    <a style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" id="savenote" title="Update"><i class="far fa-save"></i></a>
                    <a href="#" data-toggle="tooltip" data-placement="bottom" id="newnote" title="New Note"><i class="far fa-file"></i></a>
                    @if(isset($note->noteid) && Auth::user()->id == $note->created_by)
                        <a id="notecopy-{!! isset($note->noteid)? $note->noteid : '' !!}" style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" id="makecopynote" title="Make a copy"><i class="far fa-copy"></i></a>
                        <a href="#" data-toggle="tooltip" data-placement="bottom" id="movetonote" title="Move to"><i class="fas fa-arrows-alt"></i></a>
                        <a id="notedelete-{!! isset($note->noteid)? $note->noteid : '' !!}" style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" id="trashnote" title="Trash"><i class="far fa-trash-alt"></i></a>
                        @if(isset($note->noteid) && $note->protect == 1)
                        <a href="{{ URL::to((isset($note->noteid) ? $note->seourl:'').'/share') }}" data-toggle="tooltip" data-placement="bottom" id="sharenote" title="Email Collaborators"><i class="far fa-envelope"></i></a>
                        @endif
                        @if(isset($note->protect) && $note->protect == 1 )
                            <a id="unprotect-{!! isset($note->noteid)? $note->noteid : '' !!}" style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" id="unlocknote" title="Lock"><i class="fas fa-lock"></i></a>
                        @else
                            <a id="protect-{!! isset($note->noteid)? $note->noteid : '' !!}" style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" id="locknote" title="Lock"><i class="fas fa-unlock"></i></a>
                        @endif
                    @endif
                </span>
            </div>
            @endif
        </div>
    </div>
</section>
