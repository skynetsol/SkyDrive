<section class="headerArea">
    <nav class="navbar navbar-expand-lg navbar-light"> <a class="navbar-brand" href="{{url('/me')}}"><img src="{{ URL::asset('public/img/logo.png')}}" alt=""></a>
        <span class="blankSpace"></span>
        <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="{{url('/me')}}" data-toggle="tooltip" data-placement="bottom" id="toolme"
            title="Me"><i class="fas fa-user"></i></a> </li>
        <li class="nav-item"> <a class="nav-link" href="{{url('/everyone')}}" data-toggle="tooltip" data-placement="bottom" id="tooleveryone"
            title="Everyone"><i class="fas fa-users"></i></a> </li>
        <li class="nav-item"> <a class="nav-link" href="{{url('/projects')}}" data-toggle="tooltip" data-placement="bottom" id="toolprojects"
            title="{!! (isset($totalproject) && $totalproject > 1 ? $totalproject.' Projects' : '1 Project' )!!} "><i class="far fa-file"></i></i><span class="badge">{!! (isset($totalproject) ? $totalproject : 0 )!!}</span></a> </li>
        <li class="nav-item"> <a class="nav-link" href="#" data-toggle="tooltip" data-placement="bottom" id="toolsearch"
            title="Search"><i class="fas fa-search"></i></a> </li>
        <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-cog"></i></a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                @if(Auth::user()->id == 1 || Auth::user()->id == 2)
                <a class="dropdown-item" href="{{url('/paypal-settings')}}">Paypal Settings</a> 
                @endif
                <a class="dropdown-item" href="{{url('/mysettings')}}">Todooos Settings</a> 
                <a class="dropdown-item" href="{{url('/manage-account')}}">Manage Account</a> 
                <a class="dropdown-item" href="{{url('/choose-company')}}">Choose Company</a> 
                <a class="dropdown-item" href="{{url('/needtotakecare')}}">Need to take care</a>
                <a class="dropdown-item" href="{{url('/daily-recap')}}">Daily recap</a> 
                <a class="dropdown-item" href="{{ URL::to('/profile') }}">My profile</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="{{url('/logout')}}"><strong>Log out</strong></a>
            </div>
        </li>
        <li class="nav-item">
            @if (isset($companyInfo->package->days) && $companyInfo->package->days == 'exp')
                <a class="nav-link" data-toggle="tooltip" data-placement="bottom" id="totalcommentview" title="Notifications"><i class="far fa-bell"></i>
                    @if(isset($totalcommentviews) && $totalcommentviews != '0')
                    <span class="badge">{!! $totalcommentviews !!}</span>
                    @endif
                </a>
            @else
            <a class="nav-link sidebarIcon" data-toggle="tooltip" data-placement="bottom" id="totalcommentview" title="Notifications"><i class="far fa-bell"></i>
                @if(isset($totalcommentviews) && $totalcommentviews != '0')
                <span class="badge">{!! $totalcommentviews !!}</span>
                @endif
            </a>
            @endif 
        </li>
        </ul>
    </nav>
</section>