<div class="projectSidebar {{(Auth::user()->leftpaneltype == 1 ? 'projectSidebarAdd' : '')}}" id="divleftpanel">
    <span class="projectSidebarClose"><i class="far fa-times-circle"></i></span>
    <div id="content-1" class="content">
        @if(isset($projects))
            @if(Auth::user()->listingtype == 1)
                @foreach($projects as $project)
                    <div class="projectBox" id="divprojectleftpanel-{!! $project->projectid !!}" >
                        <h3><a href="{!! URL::to($project->seourl) !!}" title="{!! $project->projectname !!}">{!! $project->projectname !!}</a></h3>
                        <p>Client: {{ $project->inviteclients }} {{ ($project->invitemanagers != '' ? '| Manager: '.$project->invitemanagers: '' ) }}</p>
                        <h5>Status: {!! $project->projectstatus !!}</h5>
                        <p>Created at: {!! date("d F,Y",strtotime($project->created_at)) !!}</p>
                        <div class="projectBoxIcons">
                            @if($project->favourite == 0)
                                <a style="cursor:pointer;" class="text-primary" data-toggle="tooltip" data-placement="bottom" id="favourite-{!! $project->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" title="Add Favorites"><i class="far fa-star"></i></a>
                            @else
                                <a style="cursor:pointer;" class="text-primary" data-toggle="tooltip" data-placement="bottom" id="unfavourite-{!! $project->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" title="Remove Favorites"><i class="fas fa-star"></i></a>
                            @endif
                            <a style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" id="lpprojectarchive-{!! $project->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" title="Archive"><i class="fas fa-archive"></i></a>
                            <a style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" id="lpprojectdelete-{!! $project->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" title="Delete"><i class="fas fa-trash-alt"></i></a>
                            <a style="cursor:pointer;" class="text-primary" data-toggle="tooltip" data-placement="bottom" id="todotime" title="{!! ($project->totaltime!=NULL ? substr($project->totaltime,0,5) : '00:00') !!} Hrs"><i class="far fa-clock"></i></a>
                            <a style="cursor:pointer;" class="text-primary" data-toggle="tooltip" data-placement="bottom" id="todocomplete" title="{!! $project->totalopentasks !!}/{!! $project->totaltasks !!}"><i class="fas fa-chart-pie"></i></a>
                        </div>
                    </div>
                @endforeach 
            @else
                @foreach($projects as $project) 
                    <div class="projectBoxListingArea">
                        <div class="projectBox projectBoxListing" id="divprojectleftpanel-{!! $project->projectid !!}" >
                            <h5><a href="{!! URL::to($project->seourl) !!}" title="{!! $project->projectname !!}">{!! $project->projectname !!}</a></h5>
                            <p class="m-0">Status: {!! $project->projectstatus !!}</p>
                        </div>
                    </div>
                @endforeach    
            @endif
        @endif
    </div>
</div>