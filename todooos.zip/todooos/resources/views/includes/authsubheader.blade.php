<section class="jumbotron">
    <div class="container-fluid">
        <div class="d-flex flex-sm-row flex-column">
            <div class="flex-fill align-self-sm-center">
                <div class="media meProfile meProfile2">
                    <div id="media-body" class="media-body">
                        <h5 class="mt-0"><a href="{{ URL::to('project/'.$project->seoname) }}">{{$project->projectname}}</a> <span class="meProfileIcon">
                            <span class="popoverBoxLefttHold">
                            <a id="dispprojectname" style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom" id="tooltipp1" title="Rename"><i class="fas fa-edit"></i></a>
                                <div class="popoverBox" id="projectrenamepopup" style="display:none;"> 
                                    <div class="arrow-up"></div>
                                    <div class="popoverBoxClose" id="projectrenameclosepop"><i class="far fa-times-circle"></i></div>
                                    <br>
                                    <form method="post" action="" id="frmeditpname">
                                        @csrf
                                        <div>
                                            <div class="form-group">
                                                <input type="text" id="editprojectname" placeholder="Project name" name="editprojectname" class="form-control" value="{{$project->projectname}}">
                                            </div>
                                            <div class="form-group">
                                                <textarea id="editprojectdesc" placeholder="Project description" name="editprojectdesc" class="form-control">{!! $project->projectdescription !!}</textarea>
                                            </div>
                                        </div>
                                        <div class='dropdown-divider'></div>
                                        <div class='row'>
                                            <div class='col-sm-12'> 
                                                <button type="submit" name="submiteditpname" id="submiteditpname"  class="btn btn-primary">Save</button> 
                                                <input type="hidden" name="editprojectid" id="editprojectid" value="{{ $project->projectid }}">
                                                <a style="cursor: pointer;" class="text-primary" id="closeprojectrename">Never mind</a>
                                                <span class="loader" id="loader-{{ $project->projectid }}"></span>
                                            </div>
                                        </div>
                                    </form>
                                    <div id="msgprojrename" class=""></div>
                                </div></span>
                                @if($project->favourite == 0)
                                <a style="cursor:pointer;" id="favourite-{!! $project->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" title="Add Favorites"><i class="far fa-star"></i></a>
                                @else
                                <a style="cursor:pointer;" id="unfavourite-{!! $project->projectid.'|'.implode(" , ",$companyInfo->user_type) !!}" class="text-primary" data-toggle="tooltip" data-placement="bottom" title="Romove Favorites"><i class="fas fa-star"></i></a>
                                @endif
                            </span></h5>
                    </div>
                </div>
            </div>
            <div class="flex-fill align-self-md-center text-right hideSm">
                <div class="profileRight">
                    <ul>
                        <li> <a href="{{ URL::to('project/'.$project->seoname.'/invite') }}">
                                <h5>Invite more people</h5>
                                <p>{{ (count($inviteusers)>0 ? count($inviteusers) : 'No')}} people on this project </p>
                            </a> </li>
                        <li> <a href="{{ URL::to($project->seourl.'/all-updates') }}">
                                <h5>Catch Up</h5>
                                <p>On recent changes</p>
                            </a> </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>