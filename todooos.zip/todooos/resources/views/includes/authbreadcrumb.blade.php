<section class="subHeader hideSm">
    <div class="container-fluid">
        <div class="d-flex flex-column flex-md-row">
            <div class="align-self-md-center">
                <ul class="nav justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link projectMenuBtn" style="cursor:pointer;" data-toggle="tooltip" data-placement="bottom"
                            id="tooltipp1" title="New"><i class="fas fa-bars"></i></a>
                    </li>
                    <li class="nav-item">
                        @if($totaldiscussion == 0)
                            <a class="nav-link">{!! ($totaldiscussion == 0 || $totaldiscussion == 1 ? $totaldiscussion ." Discussion" : $totaldiscussion ." Discussions" ) !!} </a>
                        @else
                            <a class="nav-link" href="{{ URL::to('project/'.$project->seoname.'/discussion') }}">{!! ($totaldiscussion == 0 || $totaldiscussion == 1 ? $totaldiscussion ." Discussion" : $totaldiscussion ." Discussions" ) !!} </a>
                        @endif
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ URL::to($project->seourl.'/todolist') }}">{{ ($totaltask == 0 || $totaltask == 1 ? $totaltask ." To-do" : $totaltask ." To-dos" )}} </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ URL::to($project->seourl.'/files') }}">{{ ($totalfiles == 0 || $totalfiles == 1 ? $totalfiles ." File" : $totalfiles ." Files" )}}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ URL::to($project->seourl.'/notes') }}">{{ ($totalnotes == 0 || $totalnotes == 1 ? $totalnotes ." Note" : $totalnotes ." Notes" )}} </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="events.html">Events</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ URL::to($project->seourl.'/time-entry-report') }}">Time Entry 
                            @if ($project->created_by == Auth::user()->id || $companyInfo->created_by == Auth::user()->id)
                                <input {{ ($project->timeentry == 1 ? 'checked' : '') }} type="checkbox" id="timeentry-{!! $project->projectid!!}" name="timeentry">
                            @endif 
                            <span class="text-primary">{!! (isset($project->projectstatus) && $totaltimeentry!= '' && $totaltimeentry!='00:00' ? $totaltimeentry." Hrs." : ($totaltimeentry=='01:00' ? $totaltimeentry." Hr." :'' )) !!}</span>
                        </a>
                    </li>
                </ul>
            </div>
            <span class="blankSpace"></span>
            @if(isset($project->archived) && $project->archived == 0)
            <div class="align-self-md-center">
                <div class="projectStatusInput position-relative">
                    <select class="js-example-basic-single" placeholder="Filter By Status" id="projectstatus" name="projectstatus">
                        <option value="0" selected>Filter By Status</option>
                        @if(isset($companyInfo->projectstatus) && count($companyInfo->projectstatus) > 0) 
                        @foreach($companyInfo->projectstatus as $projectstatus)
                            <option value="{{ $projectstatus->projectstatusid }}" {{ ( isset($project->projectstatus) && $project->projectstatus == $projectstatus->projectstatusid ? 'selected' : '') }}>{{ $projectstatus->statusname }}</option>
                        @endforeach @endif
                    </select>
                    <div class="popoverBox" id="projectstatuspopup" style="display:none;"> 
                        <div class="arrow-up"></div>
                        <div class="popoverBoxClose" id="projectsclosepop"><i class="far fa-times-circle"></i></div>
                        <div>
                            <div class="form-group">
                                <label><strong>Comment:</strong></label>
                                <textarea id="projectcomment" class="form-control" name="projectcomment" cols="" rows="3" ></textarea>
                            </div>
                        </div>
                        <div class='dropdown-divider'></div>
                        <div class='row'>
                            <div class='col-sm-12'> 
                                <button type="button" name="submitprojectstatus" id="submitprojectstatus"  class="btn btn-primary">Submit</button> 
                                <a style="cursor: pointer;" class="text-primary" id="closeprojectstatuspopup">Never mind</a>
                                <span class="loader" id="loader-{{ $project->projectid }}"></span>
                            </div>
                        </div>
                        <div id="msgprojstatus" class=""></div>
                    </div>
                </div>
            </div>
            @endif
        </div>
        
    </div>
</section>       