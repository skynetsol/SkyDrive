<div class="loginBoxFooter">
    <div class="row">
        <div class="col-md-6 text-center text-md-left">
            <p>Need additional help? <a href="mailto:support@todooos.com" class="text-primary">contact todooos support</a></p>
        </div>
        <div class="col-md-6 text-center text-md-right">
            <p>© {!! date("Y")!!} todooos <a href="{{ url('/') }}" class="text-primary">Legal</a></p>
        </div>
    </div>
</div>