<!--Notification Sidebar-->
<div class="sideBarArea" id="divrightpanel"> <a style="cursor:pointer;" class="sideBarBoxAreaClose"><i class="fas fa-caret-right"></i></a>
    <div class="sideBarAreaHead">Notifiactions 
        @if(isset($totalcommentviews) && $totalcommentviews != '0')
        <span class="badge badge-secondary" id="totalcommentviewnotice">{!! $totalcommentviews !!}</span>
        @endif
    </div>
    <div id="content-2" class="content">
        @if(isset($commentviews) && count($commentviews) > 0)
        @php
        $cnt=0
        @endphp
        @foreach($commentviews as $commentview)
            @if($commentview->prevCommentDate == '')  
            <div class="sideBarBoxHold" id="sideBarBoxHold-{!! $commentview->commentviewid !!}"> <a style="cursor:pointer;" id="sideBarBoxHoldClose-{!! base64_encode($commentview->commentviewid."|".$commentview->created_at)!!}" class="sideBarBoxHoldClose"><i class="fas fa-times"></i></a>
                <h4>{!! $commentview->daystring!!}</h4>
                <div class="sideBarBox" id="sideBarBox-{!! $commentview->commentviewid!!}">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <span class="sideBarName"><a href="{{ url($commentview->projectseourl)}}">{!! $commentview->projectname!!}</a></span>
                            <span class="sideBarDate">{!! date("d F,Y", strtotime($commentview->created_at))!!}</span>
                            <span class="sideBarBoxClose"><a style="cursor:pointer;" id="sideBarBoxClose-{!! $commentview->commentid."|".$commentview->commentviewid !!}"><i class="fas fa-times"></i></a></span></div>
                        <div class="panel-body"> 
                            <a href="{!! url($commentview->commentseourl) !!}">
                                <h5>{!! $commentview->taskname!!}</h5>
                                <div class="sideBarBoxFigure"> 
                                    @if($commentview->profilepic != '')
                                        <img src="{{ URL::asset('img/profile_img/thum/'.$commentview->profilepic) }}" alt="{{ $commentview->created_by}}">
                                    @else
                                        <img src="{{ URL::asset('img/profile-img.jpg') }}" alt="{{ $commentview->created_by}}">
                                    @endif
                                </div>
                                <p>{!! $commentview->description!!}</p>
                                @if($commentview->rrfstatus == '1')
                                    Requested you to respond
                                @endif
                            </a> 
                        </div>
                    </div>
                </div>
            @else
                <div class="sideBarBox" id="sideBarBox-{!! $commentview->commentviewid!!}">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <span class="sideBarName"><a href="{{ url($commentview->projectseourl)}}">{!! $commentview->projectname!!}</a></span>
                            <span class="sideBarDate">{!! date("d F,Y", strtotime($commentview->created_at))!!}</span>
                            <span class="sideBarBoxClose"><a style="cursor:pointer;" id="sideBarBoxClose-{!! $commentview->commentid."|".$commentview->commentviewid !!}"><i class="fas fa-times"></i></a></span></div>
                        <div class="panel-body"> 
                            <a href="{!! url($commentview->commentseourl) !!}">
                                <h5>{!! $commentview->taskname!!}</h5>
                                <div class="sideBarBoxFigure"> 
                                    @if($commentview->profilepic != '')
                                        <img src="{{ URL::asset('img/profile_img/thum/'.$commentview->profilepic) }}" alt="{{ $commentview->created_by}}">
                                    @else
                                        <img src="{{ URL::asset('img/profile-img.jpg') }}" alt="{{ $commentview->created_by}}">
                                    @endif
                                </div>
                                <p>{!! $commentview->description!!}</p>
                                @if($commentview->rrfstatus == '1')
                                    Requested you to respond
                                @endif
                            </a> 
                        </div>
                    </div>
                </div>
            @endif    
            @if( $commentview->total == 1 || $cnt == $commentview->total)
            </div>
            @php
            $cnt=0
            @endphp
            @endif 
        @endforeach
      @else
        <div class="sideBarAreaHead">No notification found</div>    
      @endif  
      {{-- <div class="notificationSub">
       <div class="notificationSubHeading">Martha Please take care of this 10 Todo</div>
       <ul>
        <li><a href="#">Every one</a></li>
        <li><a href="#">My setting page</a></li>
        <li><a href="#">Manage user access page progress</a></li>
        <li><a href="#">Add/remove adminstrators</a></li>
        <li><a href="#">Move someone between companies / organizations</a></li>
        <li><a href="#">Change someones name, email, or jobtitle</a></li>
        <li><a href="#">Change what someone can access</a></li>
       </ul>
      </div> --}}  
    </div>
  </div>
  <!--Notification Sidebar End--> 
