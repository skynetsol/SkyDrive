@extends('layouts.authprojectwleft')
@section('pageTitle')
add discussion
@stop
@section('styles') 
{!! Html::style('public/css/blueimp-gallery.min.css')!!}
{!! Html::style('public/css/jquery.fileupload.css')!!}
{!! Html::style('public/css/jquery.fileupload-ui.css')!!}
@stop
@section('content')
<div id="todopost">
    <form  method="post" class="fileupload" action="" id="frmcomment" enctype="multipart/form-data">
      @csrf 
      <div id="addcomment" class="media commentsBox">
        @if(Auth::user()->profilepic != '')
          <img class="mr-3" src="{{ URL::asset('img/profile_img/thum/'.Auth::user()->profilepic) }}" alt="{{Auth::user()->firstname}}">
        @else
          <img class="mr-3" src="{{ URL::asset('img/profile-img.jpg') }}" alt="{{Auth::user()->firstname}}">
        @endif
        <div class="media-body">
            <div class="form-group">
                <input type="text" id="taskname" name="taskname"  placeholder="Type the subject of message..." class="form-control" autofocus>
            </div>
            <div class="commentDetailsBox">
              <div class="commentEditor">
                <div class="form-group">
                    <textarea id="description" name="description" class="form-control"></textarea>
                </div>
              </div>
              <div class="commentDetailsUpload">
                  <div id="dropzone-0" class="dropzone fade well">
                    <div class="clearfix">
                      <span class="filetext"> To attach files drag & drop here or </span>
                      <span class="filetext">
                          <a class="text-primary">
                              <u>select files from your computer…</u>
                              <input id="FileName" type="file" name="files[]" multiple>
                          </a>
                      </span>
                    </div>
                    <table role="presentation" class="table table-striped">
                        <tbody class="files"></tbody>
                    </table>
                  </div>
              </div>
              <div class="commentDetailsBottom">
                <div class="d-flex flex-column flex-md-row bd-highlight align-items-end">
                  <div class="flex-fill">
                    <div class="row">
                      <div class="col-md-8 sideborder m-3">
                          <div class="emelcomment-text"> Email this comment to people on the project: </div>
                        <div class="commentHide">
                          <div class="m-2">
                            <p class="m-3">
                              <a id="selectall" style="cursor:pointer;" class="text-primary">Select All</a>
                              |
                              <a id="selectnone" style="cursor:pointer;" class="text-primary">Select None</a>
                            </p>
                          </div>
                          <div class="m-2">
                            <div class="row">
                              @foreach($inviteusers as $inviteuser)
                              <div class="col-md-6 m-2">
                                <div class="customCheck">
                                    <div class="customCheckBox">
                                        <input type="checkbox" name="inviteuserid[]" id="inviteuserid-{!! $inviteuser->inviteuserid!!}" value="{!! $inviteuser->inviteuserid!!}">
                                        <span class="checkTick"></span>
                                    </div>
                                    <label for="inviteuserid-{!! $inviteuser->inviteuserid!!}" class="form-check-label text-secondary">{!! $inviteuser->username!!}</label>
                                </div>
                              </div>
                              @endforeach
                            </div>
                          </div>
                          <div class="form-group">
                            <select class="js-example-basic-single-rrfuserid form-control"  name="rrfuserid[]" id="rrfuserid" multiple>
                              <option></option>
                              @if(isset($inviteusers) && count($inviteusers) > 0) @foreach($inviteusers as $inviteuser)
                                <option value="{!! $inviteuser->inviteuserid!!}">{!! $inviteuser->username!!}</option>
                                @endforeach @endif
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <p>&nbsp;</p>
                      </div>
                      <div class="col-md-12">
                          <p id="aloopuser" style="display:none;"><a style="cursor: pointer;" class="text-primary">Loop-in someone who isn't on the project</a> to share this by email only <a class="text-primary">(what is this?)</a>
                            <div id="divloopemail" style="display:none;">  
                              <div class="form-group">
                                <select class="js-example-basic-single-loopemails form-control"  name="loopemails[]" id="loopemails" multiple>
                                    <option value="">The person you select will be notified by email</option>
                                    @if(isset($users) && count($users) > 0 ) 
                                      @foreach($users as $user) 
                                        @if(isset($comment->loopuseremails) && $comment->loopuseremails!='')
                                          <option value="{{ $user->email }}" {{ ( in_array($user->email,explode(",",$comment->loopuseremails))
                                            ? 'selected' : '') }}>{{ $user->firstname."
                                            ".$user->lastname }}</option>
                                        @else
                                          <option value="{{ $user->email }}">{{ $user->firstname." ".$user->lastname }}</option>
                                        @endif 
                                      @endforeach 
                                    @endif
                                </select>
                              </div> 
                            </div> 
                          </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <br>
            <button type="submit" id="submitcomment" class="btn btn-primary">Add comment</button>
            <button type="button" class="btn btn-danger cancel-comment" onClick="javascript:history.go(-1);">Cancel</button>
            <input type="hidden" name="commentFiles" id="commentFiles" value="" />
            <input type="hidden" name="created_bycomment" id="created_bycomment" value="{!! Auth::user()->id !!}">
            <input type="hidden" name="companyid" id="companyid" value="{!! $companyInfo->companyid !!}">
            <input type="hidden" name="projectid" id="projectid" value="{!! $project->projectid !!}">
            <div id="msgdivcomment" class=""></div>
        </div>
      </div>
    </form>
</div>  
@stop()
@section('scripts')
<script>
    var tz = jstz.determine();
    uid = "{{Auth::user()->id}}";
    var id = "{{$project->projectid}}";
    var psn = "{{$project->seoname}}";
    var url = "{{ URL::to($project->seourl)}}";
</script>

{{-- {!! Html::script('public/ckeditor/ckeditor.js') !!} --}}
{!! Html::script('/vendor/unisharp/laravel-ckeditor/ckeditor.js') !!}
{!! Html::script('public/js/jquery.mask.js') !!}
{!! Html::script('js/discussion.js') !!}

<script id="template-upload" type="text/x-tmpl">
  var fileextension =''; var filetp = ''; var iconfilename = ''; var filename = ''; {% for (var i=0, file; file=o.files[i];
  i++) { if($('#commentFiles').val()=='') { $('#commentFiles').val(file.name); } else { $('#commentFiles').val(file.name+','+$('#commentFiles').val());
  } filename = file.name; fileextension = filename.split('.'); iconfilename = fileextension[1].toLowerCase()+'.png';
  checkiconfile(iconfilename); %}
  <tr class="template-upload fade">
      <td>
          <span class="preview"></span>
      </td>
      <td>
          <p class="name">{%=file.name%}</p>
          <strong class="error text-danger"></strong>
      </td>
      <td>
          <p class="size">Processing...</p>
          <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
              <div class="progress-bar progress-bar-success" style="width:0%;"></div>
          </div>
      </td>
      <td>
          {% if (!i && !o.options.autoUpload) { %}
          <button class="btn btn-primary start" disabled>
              <i class="glyphicon glyphicon-upload"></i>
              <span>Start</span>
          </button>
          {% } %} {% if (!i) { %}
          <button class="btn btn-warning cancel">
              <i class="glyphicon glyphicon-ban-circle"></i>
              <span>Cancel</span>
          </button>
          {% } %}
      </td>
  </tr>
  {% } %}
</script>
<script id="template-download" type="text/x-tmpl">
  var fileextension =''; var filetp = ''; var iconfilename = ''; var filename = ''; {% for (var i=0, file; file=o.files[i];
  i++) { filename = file.name; fileextension = filename.split('.'); iconfilename = fileextension[1].toLowerCase()+'.png';
  if($('#commentFiles').val()!='') { %}
  <tr class="template-download fade">
      <td>
          <span class="preview">
              {% if (file.thumbnailUrl) { %}
              <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}" data-gallery>
                  <img src="{%=file.thumbnailUrl%}">
              </a>
              {% }else{ %} {% if ( found == true){ found = false; %}
              <img width="80" src="{%=sitepath %}/img/iconimg/{%=iconfilename %}"> {% }else{ %}
              <img width="80" src="{%=sitepath %}/img/iconimg/_blank.png"> {% } %} {% } %}
          </span>
      </td>
      <td>
          <p class="name">
              {% if (file.url) { %}
              <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}" {%=file.thumbnailUrl? 'data-gallery': ''%}>{%=file.name%}</a>
              {% } else { %}
              <span>{%=file.name%}</span>
              {% } %}
          </p>
          {% if (file.error) { %}
          <div>
              <span class="label label-danger">Error</span> {%=file.error%}</div>
          {% } %}
      </td>
      <td>
          <span class="size">{%=o.formatFileSize(file.size)%}</span>
      </td>
      <td>
          {% if (file.deleteUrl) { %}
          <button class="btn btn-danger delete" data-type="{%=file.deleteType%}" data-url="{%=file.deleteUrl%}" {% if (file.deleteWithCredentials)
              { %} data-xhr-fields='{"withCredentials":true}' {% } %}>
              <i class="glyphicon glyphicon-trash"></i>
              <span>Delete</span>
          </button>
          <!--<input type="checkbox" name="delete" value="1" class="toggle">-->
          {% } else { %}
          <button class="btn btn-warning cancel">
              <i class="glyphicon glyphicon-ban-circle"></i>
              <span>Cancel</span>
          </button>
          {% } %}
      </td>
  </tr>
  {% } } %}
</script>

{!! Html::script('js/jquery.ui.widget.js')!!}
{!! Html::script('js/tmpl.min.js')!!}
{!! Html::script('js/load-image.all.min.js')!!}
{!! Html::script('js/canvas-to-blob.min.js')!!}
{!! Html::script('js/jquery.blueimp-gallery.min.js')!!}
{!! Html::script('js/jquery.iframe-transport.js')!!}
{!! Html::script('js/jquery.fileupload.js')!!}
{!! Html::script('js/jquery.fileupload-process.js')!!}
{!! Html::script('js/jquery.fileupload-image.js')!!}
{!! Html::script('js/jquery.fileupload-ui.js')!!}
@stop
