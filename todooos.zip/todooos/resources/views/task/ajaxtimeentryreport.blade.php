@if( isset($labeltaskcomments) && count($labeltaskcomments) > 0 ) 
  <div class="timeBox">
      @foreach($labeltaskcomments as $labeltaskcomment)
        @if($labeltaskcomment->totaltime!='00:00:00')
        <div class="timeBoxTodoList">
          <div class="timeBox1">
            <h5><a href="{!! URL::to($labeltaskcomment->seourl)!!}">{!! $labeltaskcomment->labelname!!}</a></h5>
          </div>
          <div class="timeBox2">&nbsp;</div>
          <div class="timeBox3">{!! ($labeltaskcomment->totaltime!=NULL ? substr($labeltaskcomment->totaltime,0,5) : '00:00') !!} Hrs.</div>
        </div>
        @if(isset($labeltaskcomment->tasks) && count($labeltaskcomment->tasks) > 0 )
          @foreach($labeltaskcomment->tasks as $task)
            @if($task->totaltdltime!='00:00:00')
            <div class="timeBoxTodo">
              <div class="timeBox1">
                <p><a href="{!! URL::to($task->seourl)!!}" class="text-primary"><strong>{!! $task->taskname!!}</strong></a></p>
              </div>
              <div class="timeBox2">{!! ($task->totaltdltime!=NULL ? substr($task->totaltdltime,0,5) : '00:00')!!}  Hrs.</div>
              <div class="timeBox3">&nbsp;</div>
            </div>
            @if(count($task->comments) > 0 )
            <div class="timeBoxComments">
              @foreach($task->comments as $comment)
                @if($task->totaltdltime!='00:00:00')
                <p>{!! date("M d, Y",strtotime($comment->created_at))!!} {!! $comment->username!!} work for {!! ($comment->working_time!=NULL ? substr($comment->working_time,0,5):'00:00')  !!} Hrs. </p>
                @endif
              @endforeach
            </div>
            @endif
            @endif 
            @endforeach
          @endif
        @endif      
      @endforeach
  </div>
  @if(count($labeltaskcomments) > 0 ) 
  <div class="timeBox">
    <div class="timeBoxTodoList">
      <div class="timeBox1">
        <h5>Total</h5>
      </div>
      <div class="timeBox2">{!! $totaltimeentry!!} Hrs.</div>
      <div class="timeBox3">{!! $totaltimeentry!!} Hrs.</div>
    </div>
  </div>
  @endif 
  @else
  <div class="timeBox"><h5>No data available</h5></div>
  @endif
