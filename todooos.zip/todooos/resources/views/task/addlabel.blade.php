<div class="show-addToDoList" style="display:none;">
  <div class="todoListPanel clearfix">
    <form method="post" action="" id="frmlabel">
      <div class="row">
        @csrf
        <div class="col-sm-12">
          <div class="form-group">
            <label>Todo-list name:</label>
            <input type="text" id="labelname" name="labelname" class="form-control">
          </div>
        </div>
      </div>
      <div class="form-group">
        <button type="submit" id="submitlabel" name="submitlabel" class="btn btn-primary">Add todo-list</button>
        <input type="hidden" name="created_bylabel" id="created_bylabel" value="{!! Auth::user()->id !!}">
        <input type="hidden" name="labelid" id="labelid" value="">
        <input type="hidden" name="projectid" id="projectid" value="{{ $project->projectid }}">
        <a class="btn btn-primary cancel-todolist">Cancel</a>
        @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type))
        <label class="checkbox-inline checkBoxNew">
          <input type="checkbox" id="clientaccess" name="clientaccess"  value="1"> Client can't see this todo-list
        </label>
        @endif 
      </div>
    </form>
    <div id="msgdivlabel" class=""></div>
  </div>
</div>