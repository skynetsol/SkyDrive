{{-- <link href="{!! URL::asset('support/css/select2.css')!!}" rel="stylesheet">
<script src="{!! URL::asset('support/js/select2.full.js')!!}"></script>
<script src="{!! URL::asset('support/js/script.js')!!}"></script>
<script type="text/javascript">
var seoName = "{{ $project->seoname }}";
var projectid = "{{ $project->projectid }}";
var labelid ='';
$(function()
{
	$('a[id^="todolist-"]').click(function()
		{
			labelid = $(this).prop('id').replace('todolist-','');
			$('.show-editToDoList').hide();
			$('div#edittodolist-'+labelid).show();
		});
		
		$('a[id^="canceltodolist-"]').click(function()
		{
			labelid = $(this).prop('id').replace('canceltodolist-','');
			$('.show-editToDoList').hide();
			$('div#edittodolist-'+labelid).hide();
		});
	
		$('a[id^="todo-"]').click(function()
		{
			var taskid = $(this).prop('id').replace('todo-','');
			$('.show-editToDo').hide();
			$('div#edittodo-'+taskid).show();
		});
		
		$('a[id^="todomaster-"]').click(function()
		{
			var taskid = $(this).prop('id').replace('todomaster-','');
			$('.show-editToDo').hide();
			$("div#edittodomaster-"+taskid).show();			
		});
		
		$('a[id^="cancel-masteredit-"]').click(function()
		{
			var taskid = $(this).prop('id').replace('cancel-masteredit-','');
			$('.show-editToDo').hide();
			$('div#edittodomaster-'+taskid).hide();
		});
		
		$('a[id^="canceltodo-"]').click(function()
		{
			var taskid = $(this).prop('id').replace('canceltodo-','');
			$('.show-editToDo').hide();
			$('div#edittodo-'+taskid).hide();
		});
		
	$('a[id^="addtime-"]').click(function()
	{
		var taskid = $(this).prop('id').replace('addtime-','');
		var status = '';
		var arg='taskid='+taskid;
		$.ajax({
				url: sitepath+"/task/addtimeentry",
				type: "POST",
				data: arg,
				timeout: 20000,
				cache: false,
				success: function(html)
				{
						var nhtml = html.sms;
						var newhtml = nhtml.split('|');
						if(newhtml[0]!=0)
						{
							var h1 = document.getElementsByTagName('h1')[0];
							h1.textContent = '00:00:00';
							$('#todoname').text(newhtml[3]);
							$('#todoname').attr('href',sitepath+'/'+newhtml[4]);
							$(".stopwatch-box").css("display", "block");
						}
						else if(newhtml[0]==0)
						{
							alert("Stop watch already running/pause for another to-do, Please stop that first to start another.");
						}
						return false;
				}
			});
	});
	
});

function gettasklist(projectid, labelid)
{
	var arg='';
	loadingcontent = '<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i><span class="sr-only">Loading...</span>';
	$("#ajaxtodoadd-"+labelid).html(loadingcontent);
	$("#ajaxtodoadd-"+labelid).show();
	$.ajax({
					url: sitepath+"/ajaxlabelwpdproject/"+projectid+"/"+labelid,
					type: "POST",
					data: arg,
					timeout: 20000,
					cache: false,
					success: function(html)
					{
						$("div#ajaxtodoadd-"+labelid).html(html);	
					}
				});
}
</script>
<script src="{!! URL::asset('support/js/mastertodo.js')!!}"></script>
@if(count($label) > 0)
<div class="todo-list">
  <div class="headline">
    <div class="col-sm-12">
      <h5 class="listname">
      @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || in_array("4",$companyInfo->user_type))
      <span class="editdelete"><a style="cursor:pointer;" id="deletelabel-{!! $label->labelid !!}"><i class="fa fa-trash-o" aria-hidden="true"></i></a> <a style="cursor:pointer;" id="todolist-{!! $label->labelid !!}">Edit</a> </span>
      @endif
      <a href="{{ URL::to($label->seourl) }}">{{ $label->labelname }}</a>
      @if($label->clientaccess == 1)
      	<span class="todo-listText">Client can't see this todo-list </span>
      @endif
      </h5>
      @include('task.editlabel')
    </div>
  </div>
  <div class="col-sm-12">
    <div class="checkbox-items"> 
      @if(isset($labeltasks) && count($labeltasks) > 0 )
        @foreach($labeltasks as $labeltask)
        @if($labeltask->mastertask != 1 )
        <div class="checkbox-row listname" id="removediv-{!! $labeltask->taskid !!}">
          @if($project->archived == 0)
            @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || in_array("4",$companyInfo->user_type))
            <span class="editdelete" id="editdeletetodo"><a style="cursor:pointer;" id="deletetodo-{!! $labeltask->taskid.'|'.$labeltask->labelid !!}"><i class="fa fa-trash-o" aria-hidden="true"></i></a> <a style="cursor:pointer;" id="todo-{!! $labeltask->taskid !!}">Edit</a> </span> 
            @endif
          <input type="checkbox" name="taskcomplete" id="taskcomplete-{{ $labeltask->taskid.'_'.$labeltask->labelid }}" class="css-checkbox" />
          <label for="taskcomplete-{{ $labeltask->taskid.'_'.$labeltask->labelid }}" class="css-label"></label>
          @endif
        @elseif($labeltask->mastertask == 1 )
          @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || ($labeltask->created_by == Auth::user()->id))
         <div class="checkbox-row listname"> 
          <span class="editdelete"><a style="cursor:pointer;" id="deletetodomaster-{!! $labeltask->taskid.'|'.$labeltask->labelid !!}"><i class="fa fa-trash-o" aria-hidden="true"></i></a> <a style="cursor:pointer;" id="todomaster-{!! $labeltask->taskid !!}">Edit</a> </span>
         <label for="taskcomplete-{{ $labeltask->taskid.'_'.$labeltask->labelid }}" class="css-label recurring">
         <i class="fa fa-clock-o" aria-hidden="true" style="font-size: 22px;"></i>
         </label> 
         @endif
        @endif
        @if($labeltask->mastertask != 1 ) 
        <label>
        <a href="{{ URL::to($labeltask->seourl) }}">{{ $labeltask->taskname }}</a> <span class="coments">{{ $labeltask->totalcomment }} comments</span>
        <div class="smBtn"> 
          @if($project->archived == 0) 
          <span class="coments-user unassignedBtn" id="uname-{{ $labeltask->taskid }}">{{ $labeltask->usernames }} {!! ($labeltask->taskenddate != NULL ? date("d F Y",strtotime($labeltask->taskenddate)) : '' ) !!}</span> <span class="timeBox"><a style="cursor:pointer;" id="addtime-{{ $labeltask->taskid }}"><i class="fa fa-clock-o" aria-hidden="true"></i>{!! ($labeltask->total_time != '' ? 'Time: '.$labeltask->total_time : 'Add Time' ) !!}</a></span>
          	@if($labeltask->clientaccess == 1)
            	<span class="todo-listText">Client can't see this todo </span>
            @endif 
          @else 
          <span class="coments-user unassignedBtn">{{ $labeltask->usernames }} {!! ($labeltask->taskenddate != NULL ? date("d M Y",strtotime($labeltask->taskenddate)) : '' ) !!}</span> <span class="timeBox"><a style="cursor:pointer;" id="addtime-{{ $labeltask->taskid }}"><i class="fa fa-clock-o" aria-hidden="true"></i>{!! ($labeltask->total_time != '' ? 'Time: '.$labeltask->total_time : 'Add Time' ) !!}</a></span>
          	@if($labeltask->clientaccess == 1)
            	<span class="todo-listText">Client can't see this todo </span>
            @endif 
          @endif
          @include('task.taskassign')
          <div id="msgdivassign-{{ $labeltask->taskid }}" class=""></div>
         </div>
         </label> 
         </div>
        @elseif($labeltask->mastertask == 1 )
          @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || ($labeltask->created_by == Auth::user()->id))
          <a>{{ $labeltask->taskname }}</a> <span class="coments"><i class="fa fa-clock-o" aria-hidden="true"></i> {{ $labeltask->summerytext }}</span>	
          @if($labeltask->assignusernames != ' ') 
          <span class="coments-user unassignedBtn">{{ $labeltask->assignusernames }} </span>
          @endif  
         </label> 
         </div>
         @endif 
        @endif
      <div class="show-editToDo" id="edittodo-{!! $labeltask->taskid !!}" style="display:none;">
        <div class="todoListPanel clearfix">
          <form method="post" action="" id="frmtaskedit-{!! $labeltask->taskid !!}">
            <div class="row">
              <div class="col-sm-12">
                <div class="form-group">
                  <label>Todo name:</label>
                  <input type="text" id="taskname-{!! $labeltask->taskid !!}" name="taskname" class="form-control" value="{{ $labeltask->taskname }}">
                </div>
              </div>
            </div>
            @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type))
            <div class="row">
              <div class="col-sm-12">
                <div class="form-group">
                  <label class="checkbox-inline checkBoxfortodo">
                    <input type="checkbox" id="clientaccess" name="clientaccess"  value="1" {{ ($labeltask->clientaccess==1 ? 'checked="checkded"' : '') }}> Client can't see this todo
                  </label>
                </div>
              </div>
            </div>
            @endif
            <div class="form-group">
              <button type="submit" id="edittask-{!! $labeltask->taskid !!}" name="edittask-{!! $labeltask->taskid !!}" class="btn btn-primary">Edit todo</button>
              <input type="hidden" name="created_bytask" id="created_bytask" value="{!! Auth::user()->id !!}">
              <input type="hidden" name="projectid" id="projectid-{{ $labeltask->taskid }}" value="{{ $project->projectid }}">
              <input type="hidden" name="taskid" id="taskid-{{ $labeltask->taskid }}" value="{{ $labeltask->taskid }}">
              <input type="hidden" name="labelid" id="labelid-{{ $labeltask->taskid }}" value="{{ $labeltask->labelid }}">
              <a class="btn btn-primary" id="canceltodo-{!! $labeltask->taskid !!}">Cancel</a> </div>
          </form>
          <div id="msgdivtask-{!! $labeltask->taskid !!}" class=""></div>
        </div>
      </div>
      @include('task.editmastertodo')
      @endforeach
      @endif
      @if($project->archived == 0) 
      <a style="cursor:pointer;" id="add-to-todo-{{ $label->labelid }}" class="add-to-todo"> Add a to-do </a>
      @endif 
    </div>
    <div class="col-sm-12">
      @include('task.addmastertodo')
    </div>
  </div>
</div>
@endif
<script>
$(".js-example-basic-multiple").select2({
	placeholder: "The person you select will be notified by email"
})

var id ='';
$('span[id^="uname-"]').click(function() 
{
	id = $(this).prop('id').replace('uname-','');
	$(".popBox").hide();
  $("#popbox-"+id).show();
}); 
$('html').click(function (e) {
		
    if (e.target.id == "uname-"+id) {
			//alert(e.target.id+'---'+"uname-"+id);
       $("#popbox-"+id).css('display','true');
    } else {
			//$("#popbox-"+id).css('display','none');
    }
});
</script> --}}

<h5 class="relative"><a href="{{ URL::to($label->seourl) }}">{{ $label->labelname }}</a>
  @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || in_array("3",$companyInfo->user_type) || in_array("4",$companyInfo->user_type))
      <div class="todoEdit">
          <a class="text-primary" style="cursor:pointer;" id="deletelabel-{!! $label->labelid !!}"><i class="far fa-trash-alt"></i></a>
          <a class="text-primary" style="cursor:pointer;" id="editlabel-{!! $label->labelid !!}"><i class="far fa-edit"></i></a>
      </div>
  @endif
</h5>
<div id="ajaxlabel-{!! $label->labelid !!}"></div>
<ul class="list-group">
  @if(count($labeltasks) > 0) 
      @foreach($labeltasks as $labeltask) 
          @if($labeltask->mastertask != 1 )
              <li class="list-group-item" id="removediv-{!! $labeltask->taskid !!}">
                  <div class="customCheckBox">
                      <input type="checkbox" name="taskcomplete" id="taskcomplete-{{ $labeltask->taskid.'_'.$labeltask->labelid }}"><span class="checkTick"></span>
                  </div>
                  <div class="todoListText"><a href="{{ URL::to($labeltask->seourl) }}">{{ $labeltask->taskname }}</a></div>
                  <div class="list-group-item-badges"> <span class="badge badge-primary">{{ ($labeltask->totalcomment > 1 ? $labeltask->totalcomment.' comments' : $labeltask->totalcomment.' comment' ) }}</span>
                      <span class="badge badge-secondary"><a style="cursor:pointer;" id="uname-{{ $labeltask->taskid }}">{{ $labeltask->usernames }} {!! ($labeltask->taskenddate != NULL ? date("d F Y",strtotime($labeltask->taskenddate))
                              : '' ) !!}</a></span> 
                      <span class="badge badge-secondary"><a style="cursor:pointer;" id="addtime-{{ $labeltask->taskid }}">{!! ($labeltask->total_time != '' ? 'Time: '.$labeltask->total_time : 'Add Time' ) !!}</a></span>
                  </div>
                  @if( $project->archived == 0 && ( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || in_array("3",$companyInfo->user_type) || in_array("4",$companyInfo->user_type) ) )
                  <div class="todoEdit">
                      <a style="cursor:pointer;" id="deletetodo-{!! $labeltask->taskid.'|'.$labeltask->labelid !!}"><i class="far fa-trash-alt"></i></a>
                      <a style="cursor:pointer;" id="todo-{!! $labeltask->taskid !!}"><i class="far fa-edit"></i></a>
                  </div>
                  @endif
              </li>
          @endif
      @endforeach
  @endif
  @if($project->archived == 0)
      <li class="list-group-item"><a style="cursor:pointer;" id="add-to-todo-{{ $label->labelid }}" class="text-primary">Add a To-do</a></li>
  @endif
</ul>