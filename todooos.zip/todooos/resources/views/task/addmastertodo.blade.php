<div class="roundBox" id="show-addDiscus-{{ $label->labelid }}">
    <form method="post" action="" id="frmtask-{{ $label->labelid }}">
        @csrf
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label>To-do Name:</label>
                    <input type="text" id="taskname-{{ $label->labelid }}" name="taskname" class="form-control">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Assigned to:</label>
                    <select class="js-example-basic-single-{{ $label->labelid }}" id="email-{{ $label->labelid }}" name="email[]" multiple="multiple">
                        <@if(count($inviteusers)> 0)
                            @foreach($inviteusers as $inviteuser)
                            <option value="{{ $inviteuser->email }}">{{ $inviteuser->firstname." ".$inviteuser->lastname }}</option>
                            @endforeach
                            @endif
                    </select>
                </div>
            </div>
            <div class="col-sm-6" id="repeateoff-{{ $label->labelid }}">
                <div class="form-group">
                    <label>Due On:</label>   
                    <div class="input-group date" id='datetimepicker-{{ $label->labelid }}'>
                        <input type='text' id="taskenddate-{{ $label->labelid }}" name="taskenddate" class="form-control" />
                        <div class="input-group-append">
                            {{-- <button class="btn btn-primary"><span class="far fa-calendar-alt"></span></button> --}}
                            <a class="btn btn-primary noLinkButton"><span class="far fa-calendar-alt"></span></a>
                        </div>
                    </div>
                </div>
            </div>
            
            @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type))
            <div class="col-sm-12">
                <div class="form-group">
                    <input class="form-contro" type="checkbox" id="clientaccess" name="clientaccess" value="1">
                    <label class="form-check-label text-danger" for="clientaccess"><strong>Client can't see this to-do </strong></label>
                </div>
            </div>
            @endif
            <div class="col-sm-12">
                <input type="submit" id="submittask-{{ $label->labelid }}" class="btn btn-primary" value="Add To-do">
                <input type="hidden" name="created_bytask" id="created_bytask-{{ $label->labelid }}" value="{!! Auth::user()->id !!}">
                <input type="hidden" name="projectid" id="projectid-{{ $label->labelid }}" value="{{ $project->projectid }}">
                <input type="hidden" name="labelid" id="labelid-{{ $label->labelid }}" value="{{ $label->labelid }}">
                <input type="hidden" name="dayids" id="dayids-{{ $label->labelid }}" value="{!! date('w')!!}">
                <input type="hidden" name="summerytext" id="summerytext-{{ $label->labelid }}" value="">
                <input type="button" id="cancel-todo-{{ $label->labelid }}" class="btn btn-danger" value="Cancel">
                @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || in_array("3",$companyInfo->user_type))
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="repeate-{{ $label->labelid }}" name="mastertask" value="1">
                    <label class="form-check-label" for="repeate-{{ $label->labelid }}"><strong>Repeat</strong> 
                        <span id="editsummerytext-{{ $label->labelid }}"></span>
                        <!--pop start-->
                <div class="popoverBox" id="repeatpop-{{ $label->labelid }}" style="display:none;">
                        <div class="arrow-up"></div>
                        <div class="popoverBoxClose" id="closepop-{{ $label->labelid }}"><i class="far fa-times-circle"></i></div>
                        <h3 class="popoverBoxHeader">Repeat</h3>
                            <div class='row align-items-center'>
                                <div class='col-sm-12'> 
                                    <div id="popmsgdiv-{{ $label->labelid }}" class=""></div>
                                </div>
                            </div>
                            <div class='row  align-items-center'>
                                <div class='col-sm-4'><label><strong>Repeats:</strong></label></div>
                                <div class='col-sm-4'>
                                    <div class='form-group'>
                                        <select class="js-example-basic-single-rt-{{ $label->labelid }}" id="selectrepeat-{{ $label->labelid }}" name="repeatetype">
                                            <option value="D" selected>Daily</option>
                                            <option value="W">Weekly</option>
                                            <option value="F">Byweekly</option>
                                            <option value="M">Monthly</option>
                                            <option value="Y">Yearly</option>
                                        </select>
                                    </div>
                                </div>
                                <div class='col-sm-4'>
                                    <div class='form-group'>
                                        <div class='input-group' id='executetimedatetimepicker-{{ $label->labelid }}'> 
                                            <input type='text' class="form-control" id="executetime-{{ $label->labelid }}" name="executetime" value="9:30 AM">
                                            <div class='input-group-append'> 
                                                <span class='input-group-text' id='basic-addon2'>At</span> 
                                            </div>
                                        </div>
                                    </div>
                                    <script type="text/javascript">
                                    var date = new Date();
                                    var currentMonth = date.getMonth();
                                    var currentDate = date.getDate();
                                    var currentYear = date.getFullYear(); 
                                    var currentHour = date.getHours();
                                    var currentMinute = date.getMinutes() + 5;
                                    $(function() 
                                    {
                                        $('#executetime-{{ $label->labelid }}').datetimepicker({
                                            format: 'LT',
                                            stepping: 1,
                                            minDate: new Date(currentYear, currentMonth, currentDate, currentHour, currentMinute + 5)
                                        });
                                    });
                                    </script>
                                </div>
                            </div>
                            <div class='dropdown-divider'></div>
                            <div class='row align-items-center'>
                                <div class='col-sm-4'><label><strong>Due within:</strong></label>
                                </div>
                                <div class='col-sm-4'>
                                    <div class='form-group'>
                                        <div class='input-group'> 
                                            <input type='text' id="dueondays-{{ $label->labelid }}" name="dueondays"  class='form-control' value="5">
                                            <div class='input-group-append'> <span class='input-group-text'
                                                    id='basic-addon2'>Days</span> </div>
                                        </div>
                                    </div>
                                </div>
                                <div class='col-sm-4'>
                                    <div class='form-group'>
                                        <div class='input-group' id='newdatetimepicker-{{ $label->labelid }}'> 
                                            <input type='text' id="dueontime-{{ $label->labelid }}" name="dueontime" class="form-control" value="5:30 PM">
                                            <div class='input-group-append'> <span class='input-group-text'
                                                    id='basic-addon2'>At</span> </div>
                                        </div>
                                    </div>
                                    <script type="text/javascript">
                                    $(function() 
                                    {
                                        $('#dueontime-{{ $label->labelid }}').datetimepicker({
                                        format: 'LT',
                                        stepping: 1
                                        });
                                    });
                                    </script>
                                </div>
                            </div>
                            <div class='dropdown-divider'></div>
                            <div class='row align-items-center' id="daily-{{ $label->labelid }}">
                                <div class='col-sm-4'><label><strong>Repeats every:</strong></label>
                                </div>
                                <div class='col-sm-5'>
                                    <div class='form-group'>
                                        <select class="js-example-basic-single-red-{{ $label->labelid }}" id="noofdays-{{ $label->labelid }}" name="noofdays">
                                            <?php
                                            for($i = 1; $i<=30; $i++)
                                            {
                                            ?>
                                            <option value="<?php echo $i?>"><?php echo $i?></option>
                                            <?php
                                            }
                                            ?>  
                                        </select>
                                    </div>
                                    <script type="text/javascript">
                                        $(function() {
                                            $(".js-example-basic-single-red-{{ $label->labelid }}").select2();
                                        });
                                    </script>    
                                </div>
                                <div class='col-sm-3'><label><strong>days</strong></label></div>
                            </div>
                            <div id="weekly-{{ $label->labelid }}" style="display:none;">
                                <div class='row align-items-center'>
                                    <div class='col-sm-4'><label><strong>Repeats every:</strong></label>
                                    </div>
                                    <div class='col-sm-5'>
                                        <div class='form-group'>
                                            <select class="js-example-basic-single-rew-{{ $label->labelid }}" id="noofweeks-{{ $label->labelid }}" name="noofweeks">
                                                <?php
                                                for($i = 1; $i<=30; $i++)
                                                {
                                                ?>
                                                <option value="<?php echo $i?>"><?php echo $i?></option>
                                                <?php
                                                }
                                                ?>  
                                            </select>
                                        </div>
                                        <script type="text/javascript">
                                            $(function() {
                                                $(".js-example-basic-single-rew-{{ $label->labelid }}").select2();
                                            });
                                        </script>    
                                    </div>
                                    <div class='col-sm-3'><label><strong>weeks</strong></label></div>
                                </div>
                                <div class='row align-items-center'>
                                    <div class='col-sm-3'><label><strong>Repeat on:</strong></label>
                                    </div>
                                    <div class='col-sm-9'>
                                        <div class="form-check form-check-inline">
                                        <label class="checkbox-inline">
                                        <input type="checkbox" id="repeateon-0|{{ $label->labelid }}" name="repeateon[]" {!! strtolower(date("D"))=='sun' ? 'checked="checked"' : '' !!}  value="0">
                                        S </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <label class="checkbox-inline">
                                        <input type="checkbox" id="repeateon-1|{{ $label->labelid }}" name="repeateon[]" {!! strtolower(date("D"))=='mon' ? 'checked="checked"' : '' !!} value="1">
                                        M </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <label class="checkbox-inline">
                                        <input type="checkbox" id="repeateon-2|{{ $label->labelid }}" name="repeateon[]" {!! strtolower(date("D"))=='tue' ? 'checked="checked"' : '' !!} value="2">
                                        T </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <label class="checkbox-inline">
                                        <input type="checkbox" id="repeateon-3|{{ $label->labelid }}" name="repeateon[]" {!! strtolower(date("D"))=='wed' ? 'checked="checked"' : '' !!} value="3">
                                        W </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <label class="checkbox-inline">
                                        <input type="checkbox" id="repeateon-4|{{ $label->labelid }}" name="repeateon[]" {!! strtolower(date("D"))=='thu' ? 'checked="checked"' : '' !!} value="4">
                                        T </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <label class="checkbox-inline">
                                        <input type="checkbox" id="repeateon-5|{{ $label->labelid }}" name="repeateon[]" {!! strtolower(date("D"))=='fri' ? 'checked="checked"' : '' !!} value="5">
                                        F </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <label class="checkbox-inline">
                                        <input type="checkbox" id="repeateon-6|{{ $label->labelid }}" name="repeateon[]" {!! strtolower(date("D"))=='sat' ? 'checked="checked"' : '' !!} value="6">
                                        S </label> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class='row align-items-center' id="byweekly-{{ $label->labelid }}" style="display:none;">
                                <div class='col-sm-4'><label><strong>Repeats every:</strong></label>
                                </div>
                                <div class='col-sm-5'>
                                    <div class='form-group'>
                                        <select class="js-example-basic-single-reb-{{ $label->labelid }}" id="nooffortnights-{{ $label->labelid }}" name="nooffortnights">
                                            <?php
                                            for($i = 1; $i<=30; $i++)
                                            {
                                            ?>
                                            <option value="<?php echo $i?>"><?php echo $i?></option>
                                            <?php
                                            }
                                            ?>   
                                        </select>
                                    </div>
                                    <script type="text/javascript">
                                        $(function() {
                                            $(".js-example-basic-single-reb-{{ $label->labelid }}").select2();
                                        });
                                    </script>    
                                </div>
                                <div class='col-sm-3'><label><strong>byweeks</strong></label></div>
                            </div>
                            <div id="monthly-{{ $label->labelid }}" style="display:none;">
                                <div class='row align-items-center'>
                                    <div class='col-sm-4'><label><strong>Repeats every:</strong></label>
                                    </div>
                                    <div class='col-sm-5'>
                                        <div class='form-group'>
                                            <select class="js-example-basic-single-rem-{{ $label->labelid }}" id="noofmonths-{{ $label->labelid }}" name="noofmonths">
                                                <?php
                                                for($i = 1; $i<=12; $i++)
                                                {
                                                ?>
                                                <option value="<?php echo $i?>"><?php echo $i?></option>
                                                <?php
                                                }
                                                ?>   
                                            </select>
                                        </div>
                                        <script type="text/javascript">
                                            $(function() {
                                                $(".js-example-basic-single-rem-{{ $label->labelid }}").select2();
                                            });
                                        </script>    
                                    </div>
                                    <div class='col-sm-3'><label><strong>months</strong></label></div>
                                </div>
                                <div class='row align-items-center'>
                                    <div class='col-sm-4'><label><strong>Repeat by:</strong></label>
                                    </div>
                                    <div class='col-sm-8'>
                                        <div class='form-check'> 
                                            <input class='form-check-input' type='radio' name="dayofthe" id="dayofthemonth-{{ $label->labelid }}" value="month" checked> 
                                            <label class='form-check-label' for="dayofthemonth-{{ $label->labelid }}"> day of the month </label> 
    
                                            <input class='form-check-input' type='radio' name="dayofthe" id="dayoftheweek-{{ $label->labelid }}" value="week"> 
                                            <label class='form-check-label' for="dayoftheweek-{{ $label->labelid }}"> day of the week </label> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class='row align-items-center' id="yearly-{{ $label->labelid }}" style="display:none;">
                                <div class='col-sm-4'><label><strong>Repeats every:</strong></label>
                                </div>
                                <div class='col-sm-5'>
                                    <div class='form-group'>
                                        <select class="js-example-basic-single-rey-{{ $label->labelid }}" id="noofyears-{{ $label->labelid }}" name="noofyears">
                                            <?php
                                            for($i = 1; $i<=30; $i++)
                                            {
                                            ?>
                                            <option value="<?php echo $i?>"><?php echo $i?></option>
                                            <?php
                                            }
                                            ?>   
                                        </select>
                                    </div>
                                    <script type="text/javascript">
                                        $(function() {
                                            $(".js-example-basic-single-rey-{{ $label->labelid }}").select2();
                                        });
                                    </script>    
                                </div>
                                <div class='col-sm-3'><label><strong>years</strong></label></div>
                            </div>
                            <div class='row align-items-center'>
                                <div class='col-sm-4'><label><strong>Starts on:</strong></label>
                                </div>
                                <div class='col-sm-8'>
                                    <div class='form-group'>
                                        <div class='input-group'id='startondatetimepicker-{{ $label->labelid }}'> 
                                            <input type='text' name="starton" id="starton-{{ $label->labelid }}" value="{!! date("M d,Y")!!}" class='form-control'>
                                            <div class='input-group-append'> <span class='input-group-text'
                                                    id='basic-addon2'>Date</span> </div>
                                        </div>
                                    </div>
                                    <script type="text/javascript">
                                        var cdate = new Date();
                                        var currentMonth = cdate.getMonth();
                                        var currentDate = cdate.getDate();
                                        var currentYear = cdate.getFullYear();
                                        var currentHour = cdate.getHours();
                                        var currentMinute = cdate.getMinutes();
                                        $(function() 
                                        {
                                          $('input#starton-{{ $label->labelid }}').datetimepicker({
                                            format : 'LL',
                                            extraFormats: [ 'DD/MM/YY' ],
                                            minDate: new Date(currentYear, currentMonth, currentDate)
                                          });
                                        });
                                      </script>
                                </div>
                            </div>
                            <div class='dropdown-divider'></div>
                            <div class='row align-items-center'>
                                <div class='col-sm-12'><label><strong>End:</strong></label> </div>
                                <div class='col-sm-12' id="radiodiv-{{ $label->labelid }}">
                                    <div class='row'>
                                        <div class='col-sm-3'>
                                            <div class='form-check'> 
                                                <input class='form-check-input' type='radio' name="endafteron" id="endafteron-{{ $label->labelid }}" value="N" checked> 
                                                <label class='form-check-label' for="endafteron-{{ $label->labelid }}"> Never </label> 
                                            </div>
                                        </div>
                                        <div class='col-sm-9 m-1'></div>
                                    </div>
                                    <div class='row'>
                                        <div class='col-sm-3'>
                                            <div class='form-check'> 
                                                    <input class='form-check-input' type='radio' name="endafteron" id="endafteron-{{ $label->labelid }}" value="A"> 
                                                    <label class='form-check-label' for="endafteron-{{ $label->labelid }}"> After </label> 
                                            </div>
                                        </div>
                                        <div class='col-sm-9 m-1'>
                                            <div class='input-group'> 
                                                <input type='text' class='form-control numberwz' name="endafter" id="endafter-{!! $label->labelid!!}" value="5"> 
                                                <div class='input-group-append'> <span class='input-group-text' id='basic-addon2'>Occurrences</span> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class='row'>
                                        <div class='col-sm-3'>
                                            <div class='form-check'> 
                                                <input class='form-check-input' type='radio' name="endafteron" id="endafteron-{{ $label->labelid }}" value="O"> 
                                                <label class='form-check-label' for="endafteron-{{ $label->labelid }}"> On </label> </div>
                                        </div>
                                        <div class='col-sm-9'>
                                            <div class='input-group' id='endondatetimepicker-{{ $label->labelid }}'> 
                                                <input type='text' class='form-control' name="endon" id="endon-{{ $label->labelid }}" value="{!! date("M d,Y",strtotime('2 days',time()))!!}">
                                                <div class='input-group-append'> <span class='input-group-text' id='basic-addon2'>Date</span> </div>
                                            </div>
                                            <script type="text/javascript">
                                                var date = new Date();
                                                var currentMonth = date.getMonth();
                                                var currentDate = date.getDate();
                                                var currentYear = date.getFullYear();
                                                $(function() 
                                                {
                                                  $('input#endon-{{ $label->labelid }}').datetimepicker({
                                                    format : 'LL',
                                                    extraFormats: [ 'DD/MM/YY' ],
                                                    minDate: new Date(currentYear, currentMonth, currentDate)
                                                  });
                                                });
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class='dropdown-divider'></div>
                            <div class='row'>
                                <div class='col-sm-12 m-4'><label><strong>Summary:</strong><span id="summerytext"> Daily</span></label></div>
                            </div>
                            <div class='row'>
                                <div class='col-sm-12'> 
                                    <input type="button" name="donepop" id="donepop-{{ $label->labelid }}" class='btn btn-primary' value='Done'> 
                                    <input type="reset" name="cancelpop" id="cancelpop-{{ $label->labelid }}" class='btn btn-danger' value='Cancel'> 
                                </div>
                            </div>
                    </div>
                    <!--pop end--> 
                    </label>
                </div>
                @endif
            </div>
        </div>
    </form>
</div>
