<option value="" selected>Choose a todolist…</option>
@if(isset($labels) && count($labels) > 0) 
    @foreach($labels as $labeldb)
    <option value="{{ $labeldb->labelid }}">{{ $labeldb->labelname }}</option>
    @endforeach 
@endif