    
    <div class="arrow-up"></div>
    <div class="popoverBoxClose" id="popoverBoxClose-{{ $task->taskid }}"><i class="far fa-times-circle"></i></div>
    <h3 class="popoverBoxHeader">Assign</h3>
      <form method="post" action="" id="frmassign-{{ $task->taskid }}">   
        @csrf 
        <div>
            <div class="form-group">
              <label><strong>Assign this to-do to:</strong></label>
              <select class="js-example-basic-single-new-{!! $task->taskid !!}" id="emailpop-{{ $task->taskid }}" name="emailpop[]" multiple="multiple">
                  @if(count($inviteusers) > 0)
                    @foreach($inviteusers as $inviteuser)
                      <option value="{{ $inviteuser->email }}" {{ ( in_array($inviteuser->email,$task->assignusers)? 'selected' : '') }}>{{ $inviteuser->firstname." ".$inviteuser->lastname }}</option>
                    @endforeach 
                  @endif
              </select>
            </div>
        </div>
        <div class='dropdown-divider'></div>
        <div class="m-3">
            <label><strong>Set the due date:</strong></label>
            <input type="text" readonly id="assigndate-{{ $task->taskid }}" value="{{ ($task->taskenddate != NULL ? date('M d, Y',strtotime($task->taskenddate)) : '' ) }}" name="assigndate" class="form-control">
        </div>
        <div>
            <div id='datetimepickerpop-{{ $task->taskid }}'></div>
        </div>
        <div class='dropdown-divider'></div>
        <label class="text-center d-block m-4"><a style="cursor:pointer;text-decoration: underline;" id="no-due-date-{{ $task->taskid }}"><strong>No due date</strong></a></label>
        <div class='row'>
            <div class='col-sm-12'> 
              <input type="submit" id="submitassign-{{ $task->taskid }}" class='btn btn-primary' value="Assign"> 
              <input type="hidden" name="created_byassign" id="created_byassign-{{ $task->taskid }}" value="{!! Auth::user()->id !!}">
              <input type="hidden" name="taskid" id="taskassignid-{{ $task->taskid }}" value="{{ $task->taskid }}">
              <input type="hidden" name="projectid" id="projectassignid-{{ $task->taskid }}" value="{{ $project->projectid }}">
              <input type="hidden" name="labelid" id="labelassignid-{{ $task->taskid }}" value="{{ $task->labelid }}">
              <input type="hidden" name="taskenddate" id="labeltaskenddate-{{ $task->taskid }}" value="{{ $task->taskenddate }}">
              <input type="hidden" name="assignusers" id="labelassignusers-{{ $task->taskid }}" value="{{ implode(",",$task->assignusers) }}">
              <input type="button" id= "cancel-assign-{{ $task->taskid }}" class='btn btn-danger' value='Cancel'>
              <span class="loader" id="loader-{{ $task->taskid }}"></span>
            </div>
        </div>
    </form>