
  @if(count($discussions) > 0) 
  @foreach($discussions as $discussion)
  <div class="discussionBox"><a href="{{ URL::to($discussion->seourl) }}">
    <div class="discussionBoxProfile">
      @if( $discussion->profilepic !='' && file_exists('public/img/profile_img/thum/'.$discussion->profilepic))  
          <div class="discussionBoxProfileImg"><img src="{{ URL::asset('img/profile_img/thum/'.$discussion->profilepic) }}" alt="{{ $discussion->username}}"></div>
      @else
          <div class="discussionBoxProfileImg"><img src="img/profileImg.jpg" alt=""></div>
      @endif
      <div class="discussionBoxProfileName">
        <h5>{{ $discussion->username}}</h5>
        <p>{{ $discussion->email}}</p>
      </div>
    </div>
    <div class="discussionBoxText">{!! $discussion->description !!}</div>
      <div class="discussionBoxProfileName">
          <h5>{{ date("d M, Y",strtotime($discussion->created_at))}}</h5>
      </div>  
    <div class="discussionBoxComment">{{ $discussion->totalcomment }}</div>
  </a>
  </div>
  @endforeach
  @endif
