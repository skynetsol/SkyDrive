<script>
    $(function () {
        var commentid = "{!! $comment->commentid !!}";
        $('#fileupload-{!! $comment->commentid !!}')
            .formValidation({
                framework: 'bootstrap',
                excluded: [':disabled'],
                icon: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    description: {
                        validators: {
                            notEmpty: {
                                message: 'The comment is required and cannot be empty'
                            }
                        }
                    },
                    working_time: {
                        validators: {
                            notEmpty: {
                                message: 'The time entry is required'
                            },
                            regexp: {
                                regexp: /^(00|01|02|03|04|05|06|07|08|09|10|11|12|[1-9]):[0-5][0-9]$/,
                                message: 'The time entry is not valid time.'
                            }
                        }
                    }
                }
            })
            .on('success.form.fv', function (e) {
                e.preventDefault();
                var arg = $('#fileupload-{!! $comment->commentid !!}').serialize();
                $.ajax({
                    url: sitepath + "/comment/update/"+commentid,
                    type: "POST",
                    data: arg,
                    timeout: 20000,
                    cache: false,
                    success: function (html) {
                        //alert(html.sms);
                        var nhtml = html.sms;
                        if (parseInt(nhtml) >= 1) {
                            var arg = 'commentid=' + commentid;
                            $.ajax({
                                url: sitepath + "/comment/" + commentid,
                                type: "POST",
                                data: arg,
                                timeout: 20000,
                                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                                cache: false,
                                success: function (html) {
                                    $('div#ajaxeditcomment-'+commentid).slideUp(300);
                                    $('div#deletecom-'+commentid).html(html).slideDown(300);
                                }
                            });
                        } else {
                            $('div#msgdivcomment-' + commentid).prop('class','errormsg');
                            $('div#msgdivcomment-' + commentid).html('Comment update failed. Sorry for the inconvenience');
                        }
                        $('div#msgdivcomment-' + commentid).fadeIn(100);
                        var et = setTimeout('$("div#msgdivcomment-'+commentid+'").fadeOut(100)',5000);
                        return false;
                    }
                });
            });
    });
</script>
<form method="post" action="" id="fileupload-{!! $comment->commentid !!}" class="fileupload" enctype="multipart/form-data" data-upload-template-id="template-upload-{!! $comment->commentid !!}" data-download-template-id="template-download-{!! $comment->commentid !!}">
@csrf 
<div id="ajaxcomment-{!! $comment->commentid !!}" class="media commentsBox">
    @if($comment->profilepic != '')
      <img class="mr-3" src="{{ URL::asset('img/profile_img/thum/'.$comment->profilepic) }}" alt="{{ $comment->created_by}}">
    @else
      <img class="mr-3" src="{{ URL::asset('public/img/profileImg.jpg')}}" alt="{{ $comment->created_by}}">
    @endif
  <div class="media-body">
      <div class="commentDetailsBox">
        <div class="commentEditor">
          <div class="form-group">
              <textarea id="description-{!! $comment->commentid !!}" name="description" class="form-control">{!! $comment->description !!}</textarea>
              <script>
                  var commentid = "{!! $comment->commentid !!}";
                  CKEDITOR.replace('description-' + commentid, {
                      resize_maxWidth: '100%',
                      resize_enabled: 'false',
                      toolbar: 'MyToolbar',
                      startupFocus: true,
                      extraPlugins: 'autogrow',
                      removePlugins: 'resize',
                      height: 150,
                      autoGrow_minHeight: 150
                  }).on('change', function () {
                      // Revalidate the bio field
                      for (instance in CKEDITOR.instances) {
                          CKEDITOR.instances[instance].updateElement();
                      }
                      if ($('#description-' + commentid).val() == '') {
                          $('#fileupload-' + commentid).formValidation('revalidateField', 'description');
                      } else {
                          $('#fileupload-' + commentid).formValidation('revalidateField', 'description');
                      }
                  });
              </script>
              <script id="template-upload-{!! $comment->commentid !!}" type="text/x-tmpl">
                  var fileextension =''; var filetp = ''; var iconfilename = ''; var filename = ''; {% for (var i=0, file; file=o.files[i];
                  i++) { if($('#commentFiles-{!! $comment->commentid !!}').val()=='') { $('#commentFiles-{!!
                  $comment->commentid !!}').val(file.name); } else { $('#commentFiles-{!! $comment->commentid
                  !!}').val(file.name+','+$('#commentFiles-{!! $comment->commentid !!}').val()); } filename
                  = file.name; fileextension = filename.split('.'); iconfilename = fileextension[1].toLowerCase()+'.png';
                  checkiconfile(iconfilename); %}
                  <tr class="template-upload fade">
                      <td>
                          <span class="preview"></span>
                      </td>
                      <td>
                          <p class="name">{%=file.name%}</p>
                          <strong class="error text-danger"></strong>
                      </td>
                      <td>
                          <p class="size">Processing...</p>
                          <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                              <div class="progress-bar progress-bar-success" style="width:0%;"></div>
                          </div>
                      </td>
                      <td>
                          {% if (!i && !o.options.autoUpload) { %}
                          <button class="btn btn-primary start" disabled>
                              <i class="glyphicon glyphicon-upload"></i>
                              <span>Start</span>
                          </button>
                          {% } %} {% if (!i) { %}
                          <button class="btn btn-warning cancel">
                              <i class="glyphicon glyphicon-ban-circle"></i>
                              <span>Cancel</span>
                          </button>
                          {% } %}
                      </td>
                  </tr>
                  {% } %}
              </script>

              <script id="template-download-{!! $comment->commentid !!}" type="text/x-tmpl">
                  var fileextension =''; var filetp = ''; var iconfilename = ''; var filename = ''; {% for (var i=0, file; file=o.files[i];
                  i++) { filename = file.name; fileextension = filename.split('.'); iconfilename = fileextension[1].toLowerCase()+'.png';
                  if($('#commentFiles-{!! $comment->commentid !!}').val()!='') { %}
                  <tr class="template-download fade">
                      <td>
                          <span class="preview">
                              {% if (file.thumbnailUrl) { %}
                              <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}" data-gallery>
                                  <img src="{%=file.thumbnailUrl%}">
                              </a>
                              {% }else{ %} {% if (found == true){ %}
                              <img width="80" src="{%=sitepath %}/support/images/iconimg/{%=iconfilename %}"> {% }else{ %}
                              <img width="80" src="{%=sitepath %}/support/images/iconimg/_blank.png'"> {% } %} {% } %}
                          </span>
                      </td>
                      <td>
                          <p class="name">
                              {% if (file.url) { %}
                              <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}" {%=file.thumbnailUrl? 'data-gallery': ''%}>{%=file.name%}</a>
                              {% } else { %}
                              <span>{%=file.name%}</span>
                              {% } %}
                          </p>
                          {% if (file.error) { %}
                          <div>
                              <span class="label label-danger">Error</span> {%=file.error%}</div>
                          {% } %}
                      </td>
                      <td>
                          <span class="size">{%=o.formatFileSize(file.size)%}</span>
                      </td>
                      <td>
                          {% if (file.deleteUrl) { %}
                          <button class="btn btn-danger delete" data-type="{%=file.deleteType%}" data-url="{%=file.deleteUrl%}" {% if (file.deleteWithCredentials)
                              { %} data-xhr-fields='{"withCredentials":true}' {% } %}>
                              <i class="glyphicon glyphicon-trash"></i>
                              <span>Delete</span>
                          </button>
                          <!--<input type="checkbox" name="delete" value="1" class="toggle">-->
                          {% } else { %}
                          <button class="btn btn-warning cancel">
                              <i class="glyphicon glyphicon-ban-circle"></i>
                              <span>Cancel</span>
                          </button>
                          {% } %}
                      </td>
                  </tr>
                  {% } } %}</script>
          </div>
        </div>
        <div class="commentDetailsUpload">
            <div id="dropzone-0" class="dropzone fade well">
              <div class="clearfix">
                <span class="filetext"> To attach files drag & drop here or </span>
                <span class="filetext">
                    <a class="text-primary">
                        <u>select files from your computer…</u>
                        <input id="FileName" type="file" name="files[]" multiple>
                    </a>
                </span>
              </div>
              <table role="presentation" class="table table-striped">
                  <tbody class="files"></tbody>
              </table>
            </div>
        </div>
        @if( $task->labelid != 0)
        <div class="commentDetailsBottom">
          <div class="d-flex flex-column flex-md-row bd-highlight align-items-end">
            <div class="blankSpace"></div>
            <div class="form-group time-field">
              <div class="timeFieldArea">
                <div class="d-flex flex-row bd-highlight align-items-center  justify-content-end">
                  <div class="timeFieldIcon"><i class="far fa-clock"></i></div>
                      <input type="text" id="working_time" name="working_time" class="form-control timeField" placeholder="00:00" value="{!! $comment->working_time !!}">
                </div>
              </div>
            </div>
          </div>
        </div>
        @endif
      </div>
      <br>
      <button type="submit" id="submitcomment-{!! $comment->commentid !!}" class="btn btn-primary">Save change</button>
      <button type="button" id="cancelcomment-{!! $comment->commentid !!}" class="btn btn-danger">Cancel</button>
      <input type="hidden" name="commentFiless" id="commentFiles-{!! $comment->commentid !!}" value="" />
      <input type="hidden" name="created_bycomment" id="created_bycomment" value="{!! Auth::user()->id !!}">
      <input type="hidden" name="projectid" id="projectid" value="{!! $task->projectid !!}">
      <input type="hidden" name="commentid" id="commentid" value="{!! $comment->commentid !!}">
      <input type="hidden" name="companyid" id="companyid" value="{!! $companyInfo->companyid !!}">
      <input type="hidden" name="fileids" id="fileids-{!! $comment->commentid !!}" value=""> 
      <div id="msgdivcomment-{!! $comment->commentid !!}" class=""></div>
      <br><br>
      @if(count($comment->files) > 0)
        <div class="row">
          @foreach($comment->files as $file) 
          <div class="col-sm-6 col-md-4 col-lg-4 col-xl-3" id="filedelete-{!! $file->fileid!!}">
            <div class="card fileType text-center">
              @if($file->filetypes == 'image') 
                @if($file->filenewname!='' && file_exists('public/img/comment_files/'.$file->foldername.'/thum/'.$file->filenewname))
                  <div class="fileTypeImg"><a href="{!! URL::to('/download/'.$file->foldername.'/'.base64_encode($file->filenewname)) !!}"><img src="{{ URL::asset('img/comment_files/'.$file->foldername.'/thum/'.$file->filenewname) }}" alt="{{ $file->created_by}}" title="{!! $file->filename !!}"></a></div>
                @else
                  <div class="fileTypeImg">
                    @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                      <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt="" title="{!! $file->filename !!}">
                    @else
                      <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="">
                    @endif
                  </div>
                @endif
              @elseif($file->filetypes == 'other')
                @if($file->filenewname!='' && file_exists('public/img/comment_files/'.$file->foldername.'/'.$file->filenewname))
                <div class="fileTypeImg">
                  <a href="{!! URL::to('/download/'.$file->foldername.'/'.base64_encode($file->filenewname)) !!}">
                    @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                      <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt="" title="{!! $file->filename !!}">
                    @else
                      <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="" title="{!! $file->filename !!}">
                    @endif
                  </a>
                </div>
                @else  
                <div class="fileTypeImg">
                    <a href="{!! URL::to('/download/'.$file->foldername.'/'.base64_encode($file->filenewname)) !!}">
                      @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                        <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt="" title="{!! $file->filename !!}">
                      @else
                        <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="" title="{!! $file->filename !!}">
                      @endif
                    </a>
                </div> 
                @endif
              @else 
              <div class="fileTypeImg">
                  @if($file->fileextension!='' && file_exists('support/images/iconimg/'.$file->fileextension.'.png'))
                  <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt=""> @else
                  <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> @endif
              </div> 
              @endif
              <span class="closeBtn1" id="commentfile-{!! $file->fileid!!}|{!! $comment->commentid !!}"><i class="far fa-times-circle"></i></span> 
              <div class="card-body">
                <h5 class="card-title">{!! $file->filename !!}</h5>
                <h6 class="m-0">{!! $file->filesize !!}</h6>
              </div>
            </div>
          </div>
          @endforeach
        </div>
    @endif   
  </div>
</div>
</form> 
   