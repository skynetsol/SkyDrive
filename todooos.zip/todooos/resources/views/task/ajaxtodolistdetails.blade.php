
<div class="m-5">
    @if(isset($page) && $page != 'tld')
    <h3 class="m-3">To-do list <a class="btn btn-sm btn-primary addToDoList noLinkButton">Add New</a></h3>
    <div class="roundBox" style="display:none;">
        <form method="post" action="" id="frmlabel">
        @csrf    
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label>To-do list name:</label>
                    <input type="text" id="labelname" name="labelname" class="form-control">
                </div>
            </div>
            <div class="col-sm-12">
                <input type="submit" id="submitlabel" name="submitlabel" class="btn btn-primary" value="Add to-do list">
                <input type="button" id="cancellabel" class="btn btn-danger" value="Cancel">
                <input type="hidden" name="created_bylabel" id="created_bylabel" value="{!! Auth::user()->id !!}">
                <input type="hidden" name="labelid" id="labelid" value="">
                <input type="hidden" name="projectid" id="projectid" value="{{ $project->projectid }}">
                @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type))
                &nbsp;
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="clientaccess" name="clientaccess" value="1">
                    <label class="form-check-label text-danger" for="clientaccess"><strong>Client can't see this to-do list </strong></label>
                </div>
                @endif
            </div>
        </div>
        </form>
        <div id="msgdivlabel" class=""></div>
    </div>
    @endif
    <div id="ajaxtodolist">
        <div id="ajaxtodoadd"></div>
        @if(isset($labeltasks) && count($labeltasks) > 0) @foreach($labeltasks as $label)
        <div id="ajaxtodolistadd-{{ $label->labelid }}"> 
            <h5 class="relative"><a href="{{ URL::to($label->seourl) }}">{{ $label->labelname }}</a>
                @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || in_array("3",$companyInfo->user_type) || in_array("4",$companyInfo->user_type))
                    <div class="todoEdit">
                        <a class="text-primary" style="cursor:pointer;" id="deletelabel-{!! $label->labelid !!}"><i class="far fa-trash-alt"></i></a>
                        <a class="text-primary" style="cursor:pointer;" id="editlabel-{!! $label->labelid !!}"><i class="far fa-edit"></i></a>
                    </div>
                @endif
            </h5>
            <div id="ajaxlabel-{!! $label->labelid !!}"></div>
            <ul class="list-group">
                @if(count($label->todos) > 0) 
                    @foreach($label->todos as $labeltask) 
                        @if($labeltask->mastertask != 1 )
                            <li class="list-group-item" id="removediv-{!! $labeltask->taskid !!}">
                                <div class="customCheckBox">
                                    <input type="checkbox" name="taskcomplete" id="taskcomplete-{{ $labeltask->taskid.'_'.$labeltask->labelid }}"><span class="checkTick"></span>
                                </div>
                                <div class="todoListText"><a href="{{ URL::to($labeltask->seourl) }}">{{ $labeltask->taskname }}</a></div>
                                <div class="list-group-item-badges"> <span class="badge badge-primary">{{ ($labeltask->totalcomment > 1 ? $labeltask->totalcomment.' comments' : $labeltask->totalcomment.' comment' ) }}</span>
                                    <span class="badge badge-secondary"><a style="cursor:pointer;" id="uname-{{ $labeltask->taskid }}">{{ $labeltask->usernames }} {!! ($labeltask->taskenddate != NULL ? date("d F Y",strtotime($labeltask->taskenddate))
                                            : '' ) !!}</a></span> 
                                    <span class="badge badge-secondary"><a style="cursor:pointer;" id="addtime-{{ $labeltask->taskid }}">{!! ($labeltask->total_time != '' ? 'Time: '.$labeltask->total_time : 'Add Time' ) !!}</a></span>
                                </div>
                                @if( $project->archived == 0 && ( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || in_array("3",$companyInfo->user_type) || in_array("4",$companyInfo->user_type) ) )
                                <div class="todoEdit">
                                    <a style="cursor:pointer;" id="deletetodo-{!! $labeltask->taskid.'|'.$labeltask->labelid !!}"><i class="far fa-trash-alt"></i></a>
                                    <a style="cursor:pointer;" id="edittodo-{!! $labeltask->taskid !!}"><i class="far fa-edit"></i></a>
                                </div>
                                @endif
                            </li>
                            <div id="ajaxedittodo-{!! $labeltask->taskid !!}"></div>
                        @endif
                    @endforeach
                @endif
                @if($project->archived == 0)
                    <li class="list-group-item"><a style="cursor:pointer;" id="add-to-todo-{{ $label->labelid }}" class="text-primary">Add a To-do</a></li>
                @endif
            </ul>
            <div id="ajaxtodoadd-{!! $label->labelid !!}"></div>
        </div>
        @endforeach @endif 
    </div>
    @if(isset($totalcompletedtodo) && $totalcompletedtodo > 0  && isset($page) && $page != 'tld')
    <div>
        <h5> <a class="text-primary" href="{{ URL::to($project->seourl.'/completed-todo') }}">{!! $totalcompletedtodo !!}  Completed to-dos </a>  across {!! $totalacrosslabel->total !!} to-do lists</h5>
        @if(count($completedtodolists) > 0)
            <h5>Completed lists:  
                    @foreach($completedtodolists as $completedtodolist) 
                    @if($completedtodolist->first == 1)
                        <a class="text-primary" href="{!! URL::to($completedtodolist->seourl)!!}">{!!$completedtodolist->labelname!!}</a>
                    @else,
                        <a class="text-primary" href="{!! URL::to($completedtodolist->seourl)!!}"> {!!$completedtodolist->labelname!!}</a>
                    @endif
                @endforeach 
            </h5>      
        @endif
    </div>
    @endif
    @if(isset($completedtasks) && count($completedtasks) > 0 && isset($page) && $page == 'tld')
    <div>
        <h5> Completed to-dos</h5>
        <ul class="list-group">
        @foreach($completedtasks as $completedtask) 
        <li class="list-group-item">
            <div class="customCheckBox">
                <input type="checkbox" name="taskcomplete" id="taskcomplete-{{ $completedtask->taskid.'_'.$completedtask->labelid }}"><span class="checkTick"></span>
            </div>
            <div class="todoListText"><a href="{{ URL::to($completedtask->seourl) }}">{{ $completedtask->taskname }}</a></div>
            <div class="list-group-item-badges"> <span class="badge badge-primary">{{ ($completedtask->totalcomment > 1 ? $completedtask->totalcomment.' comments' : $completedtask->totalcomment.' comment' ) }}</span>
                <span class="badge badge-secondary">{{'Completed By '. $completedtask->username }} at {!! ($completedtask->taskenddate != NULL ? date("d F Y",strtotime($completedtask->taskenddate)) : '' ) !!}</span> 
            </div>
        </li>    
        @endforeach 
        </ul>
    </div>
    @endif
</div> 
