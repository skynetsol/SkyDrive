<div class="roundBox">
    <form method="post" action="" id="frmlabel-{!! $label->labelid !!}">
    @csrf    
    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <label>To-do list name:</label>
                <input type="text" id="labelname" name="labelname" class="form-control" value="{{ $label->labelname }}">
            </div>
        </div>
        <div class="col-sm-12">
            <input type="submit" id="submitlabel-{!! $label->labelid !!}" name="submitlabel" class="btn btn-primary" value="Edit to-do list">
            <input type="button" id="cancellabel-{{ $label->labelid }}" class="btn btn-danger" value="Cancel">
            <input type="hidden" name="created_bylabel" id="created_bylabel" value="{!! Auth::user()->id !!}">
            <input type="hidden" name="labelid" id="labelid" value="{{ $label->labelid }}">
            <input type="hidden" name="projectid" id="projectid" value="{{ $label->projectid }}">
            @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type))
            &nbsp;
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="clientaccess" name="clientaccess" value="1">
                <label class="form-check-label text-danger" for="clientaccess"><strong>Client can't see this to-do list </strong></label>
            </div>
            @endif
        </div>
    </div>
    </form>
    <div id="msgdivlabel-{!! $label->labelid !!}" class=""></div>
</div>