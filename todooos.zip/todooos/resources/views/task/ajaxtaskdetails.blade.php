@if(count($comments) > 0) @foreach($comments as $comment)
  <div class="media commentsBox" id="deletecom-{{ $comment->commentid }}">
    @if($comment->profilepic != '')
      <img class="mr-3" src="{{ URL::asset('img/profile_img/thum/'.$comment->profilepic) }}" alt="{{ $comment->created_by}}">
    @else
      <img class="mr-3" src="{{ URL::asset('public/img/profileImg.jpg')}}" alt="{{ $comment->created_by}}">
    @endif
    @if($comment->status == 0)
    <div class="media-body">
      @if($comment->deleted_at != NULL)
        <h5 class="text-warning">{{ $comment->deletedtext}}</h5>
        <h6>{!! date("d M, Y",strtotime($comment->deleted_at)) !!}</h6>
      @else
        <h5 class="mt-0">{{ $comment->created_by}}  | {!! ($comment->working_time!=NULL? ' Time: '.$comment->working_time : '')!!}</h5>
        {!! $comment->description !!}
        <h6>{!! $comment->created_at !!}</h6>
        @if($comment->updated_at != NULL && $comment->updated_by != '')
          <h6 class="text-warning">Comment edited by {{ $comment->updated_by}} at {{ date("d M, Y h:i a",strtotime($comment->updated_at))}}</h6>
        @endif
        @if(count($comment->files) > 0) 
        <div class="row">
          @foreach($comment->files as $file) 
          <div class="col-sm-6 col-md-4 col-lg-4 col-xl-3">
            <div class="card fileType text-center">
              @if($file->filetypes == 'image') 
                @if($file->filenewname!='' && Storage::disk('s3')->exists('comment_files/'.$file->foldername.'/thum/'.$file->filenewname))
                  <div class="fileTypeImg"><a href="{!! URL::to('/download/'.$file->foldername.'/'.base64_encode($file->filenewname)) !!}"><img src="{{ Storage::disk('s3')->url('comment_files/'.$file->foldername.'/thum/'.$file->filenewname) }}" alt="{{ $file->created_by}}" title="{!! $file->filename !!}"></a></div>
                @else
                  <div class="fileTypeImg">
                    @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                      <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt="" title="{!! $file->filename !!}">
                    @else
                      <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="">
                    @endif
                  </div>
                @endif
              @elseif($file->filetypes == 'other')
                @if($file->filenewname!='' && Storage::disk('s3')->exists('comment_files/'.$file->foldername.'/'.$file->filenewname))
                <div class="fileTypeImg">
                  <a href="{!! URL::to('/download/'.$file->foldername.'/'.base64_encode($file->filenewname)) !!}">
                    @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                      <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt="" title="{!! $file->filename !!}">
                    @else
                      <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="" title="{!! $file->filename !!}">
                    @endif
                  </a>
                </div>
                @else  
                <div class="fileTypeImg">
                    <a href="{!! URL::to('/download/'.$file->foldername.'/'.base64_encode($file->filenewname)) !!}">
                      @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                        <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt="" title="{!! $file->filename !!}">
                      @else
                        <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="" title="{!! $file->filename !!}">
                      @endif
                    </a>
                </div>  
                @endif 
              @else 
              <div class="fileTypeImg">
                  @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                  <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt=""> @else
                  <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> @endif
              </div>  
              @endif
              <div class="card-body">
                <h5 class="card-title">{!! $file->filename !!}</h5>
                <h6>{!! $file->filesize !!}</h6>
              </div>
            </div>
          </div>
          @endforeach
        </div>
          @if(count($comment->files) > 1)
            <div class="text-center"><a href="{!! URL::to('/commentdownload/'.$comment->commentid) !!}" class="btn btn-primary">Download All</a></div>
          @endif
        @endif
     @endif 
    </div>
    @elseif($comment->status == 1)
    <div class="media-body">
      <h5 class="text-warning">{{ $comment->created_by}} Completed the to-do</h5>
      <h6>{!! date("d M, Y",strtotime($comment->completed_at)) !!}</h6>
    </div>
    @elseif($comment->status == 2)
    <div class="media-body">
      <h5 class="text-warning">{{ $comment->created_by}} Re-open the to-do</h5>
      <h6>{!! date("d M, Y",strtotime($comment->completed_at)) !!}</h6>
    </div>
    @endif
  </div>
  <div id="ajaxeditcomment-{!! $comment->commentid !!}"></div>
  @endforeach 
@endif

