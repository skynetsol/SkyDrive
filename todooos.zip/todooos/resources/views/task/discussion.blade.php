@extends('layouts.authprojectwleft')
@section('pageTitle')
Discussion
@stop
@section('content')

<div class="d-flex flex-column flex-md-row m-3">
    <div>
      <h3>Show Discussions sorted by</h3>
    </div>
    <div class="projectsFilter">
        <select class="js-example-basic-single" id="orderby" name="Newest">
            <option value="desc">Newest</option>
            <option value="asc">Oldest</option>
        </select>
    </div>
    <div class="projectsFilter projectsFilter2">
            <div class="input-group mb-3">
         <input type="text" class="form-control" placeholder="Filter by title" id="searchtext">
         <div class="input-group-append">
           <button class="btn btn-primary" type="button" id="searchbtn" id="button-addon2" title="Search"><i class="fas fa-search"></i></button>
         </div>
       </div>
    </div>

    <div class="blankSpace"></div>

    @if($project->archived == 0)
    <div class="projectsFilter">
      <a href="{{ URL::to($project->seourl.'/discussion/add-discussion') }}" class="btn btn-primary">Post a new message</a>
    </div>
    @endif
  </div>

  <div class="ajax-loading text-center col-md-12" id="divloader"><img src="{{ asset('img/loading.gif') }}" /></div>
  <div class="m-5" id="ajaxdiscussionlist">
    @if(count($discussions) > 0) 
    @foreach($discussions as $discussion)
    <div class="discussionBox"><a href="{{ URL::to($discussion->seourl) }}">
      <div class="discussionBoxProfile">
        @if( $discussion->profilepic !='' && file_exists('public/img/profile_img/thum/'.$discussion->profilepic))  
            <div class="discussionBoxProfileImg"><img src="{{ URL::asset('img/profile_img/thum/'.$discussion->profilepic) }}" alt="{{ $discussion->username}}"></div>
        @else
            <div class="discussionBoxProfileImg"><img src="{{ asset('img/profileImg.jpg') }}" alt=""></div>
        @endif
        <div class="discussionBoxProfileName">
          <h5>{{ $discussion->username}}</h5>
          <p>{{ $discussion->email}}</p>
        </div>
      </div>
      <div class="discussionBoxText">{!! $discussion->description !!}</div>
        <div class="discussionBoxProfileName">
            <h5>{{ date("d M, Y",strtotime($discussion->created_at))}}</h5>
        </div>  
      <div class="discussionBoxComment">{{ $discussion->totalcomment }}</div>
    </a>
    </div>
    @endforeach
    @endif
  </div>
@stop()
@section('scripts')
<script>
    uid = "{{Auth::user()->id}}";
    var id = "{{$project->projectid}}";
    var psn = "{{$project->seoname}}";
</script>
{!! Html::script('js/discussionlist.js') !!}
@stop
