<ul class="list-group">
      <li class="list-group-item">
          <div class="todoListDate">{!! date("F d ",strtotime($task->created_at)) !!} at {!! date("h:i a",strtotime($task->created_at)) !!} </div>
          <div class="todoListText"> {!! $task->created_by !!} added the to-do.</div>
      </li>
      @if(count($commenthistorys) > 0)
        @foreach($commenthistorys as $commenthistory)
          @if($commenthistory->status == '0')
            <li class="list-group-item">
                <div class="todoListDate">{!! date("F d ",strtotime($commenthistory->created_at)) !!} at {!! date("h:i a",strtotime($commenthistory->created_at)) !!} </div>
                <div class="todoListText"> {!! $commenthistory->created_by !!} re-opend the to-do.</div>
            </li>
          @elseif($commenthistory->status == '2' || $commenthistory->status == '1')
            <li class="list-group-item">
                <div class="todoListDate">{!! date("F d ",strtotime($commenthistory->created_at)) !!} at {!! date("h:i a",strtotime($commenthistory->created_at)) !!} </div>
                <div class="todoListText"> {!! $commenthistory->created_by !!} completed the to-do.</div>
            </li>  
          @elseif($commenthistory->status == 'status')
            <li class="list-group-item">
                <div class="todoListDate">{!! date("F d ",strtotime($commenthistory->created_at)) !!} at {!! date("h:i a",strtotime($commenthistory->created_at)) !!} </div>
                <div class="todoListText"> {!! $commenthistory->created_by !!} commented {!! $commenthistory->notifyusername != '' ? '( '.$commenthistory->notifyusername.' were notified )' : '' !!}.</div>
            </li>   
          @elseif($commenthistory->status == 'assign')
            <li class="list-group-item">
                <div class="todoListDate">{!! date("F d ",strtotime($commenthistory->created_at)) !!} at {!! date("h:i a",strtotime($commenthistory->created_at)) !!} </div>
                <div class="todoListText"> {!! $commenthistory->created_by !!} assigned it to {!! $commenthistory->notifyusername != '' ? '( '.$commenthistory->notifyusername.' )' : '' !!}.</div>
            </li>
          @endif
        @endforeach
      @endif
</ul>