<div class="roundBox" id="show-addDiscus-{{ $task->taskid }}">
    <form method="post" action="" id="frmtaskedit-{{ $task->taskid }}">
        @csrf
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label>To-do Name:</label>
                    <input type="text" id="taskname-{{ $task->taskid }}" name="{{ ($task->mastertask == 1 ? 'mastertaskname' : 'taskname') }}" value="{{ $task->taskname }}" class="form-control">
                </div>
            </div>
            @if ($task->mastertask == 1)
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Assigned to:</label>
                    <select class="js-example-basic-single-{{ $task->taskid }}" id="email-{{ $task->taskid }}" name="email[]" multiple="multiple">
                        <@if(count($inviteusers)> 0)
                            @foreach($inviteusers as $inviteuser)
                            <option value="{{ $inviteuser->email }}" {{ ( in_array($inviteuser->email,$task->assignuseremails)? 'selected' : '') }}>{{ $inviteuser->firstname." ".$inviteuser->lastname }}</option>
                            @endforeach
                            @endif
                    </select>
                </div>
            </div>
            @endif
            @if($task->mastertask != 1 && (in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type)))
            <div class="col-sm-12">
                <div class="form-group">
                    <input class="form-contro" type="checkbox" id="clientaccess" name="clientaccess" value="1">
                    <label class="form-check-label text-danger" for="clientaccess"><strong>Client can't see this to-do </strong></label>
                </div>
            </div>
            @endif
            <div class="col-sm-12">
                <input type="submit" id="edittask-{!! $task->taskid !!}" name="edittask-{!! $task->taskid !!}" class="btn btn-primary" value="Edit todo">
                <input type="hidden" name="created_bytask" id="created_bytask" value="{!! Auth::user()->id !!}">
                <input type="hidden" name="projectid" id="projectid-{{ $task->taskid }}" value="{{ $project->projectid }}">
                <input type="hidden" name="taskid" id="taskid-{{ $task->taskid }}" value="{{ $task->taskid }}">
                <input type="hidden" name="labelid" id="labelid-{{ $task->taskid }}" value="{{ $task->labelid }}">
                <input type="hidden" name="dayids" id="dayids-{{ $task->taskid }}" value="{{ $task->repeateon }}">
                <input type="hidden" name="summerytext" id="summerytext-{{ $task->taskid }}" value="{!! $task->summerytext !!}">
                <input type="button" id="cancel-edittodo-{{ $task->taskid }}" class="btn btn-danger" value="Cancel">
                
                @if( $task->mastertask == 1 && (in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || in_array("3",$companyInfo->user_type)) )
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="repeate-{{ $task->taskid }}" name="mastertask" value="1" checked disabled>
                    <label class="form-check-label" for="repeate-{{ $task->taskid }}"><strong>Repeat</strong> <a id="editrepeate-{{ $task->taskid }}" class="text-primary" style="cursor:pointer;"> Edit </a> <span id="editsummerytext-{{ $task->taskid }}"></span></label> 
                </div>
                <!--pop start-->
                <div class="popoverBox" id="repeatpop-{{ $task->taskid }}" style="display:none;">
                    <div class="popoverBoxClose" id="closepop-{{ $task->taskid }}"><i class="far fa-times-circle"></i></div>
                    <h3 class="popoverBoxHeader">Repeat</h3>
                        <div class='row align-items-center'>
                            <div class='col-sm-12'> 
                                <div id="popmsgdiv-{{ $task->taskid }}" class=""></div>
                            </div>
                        </div>
                        <div class='row  align-items-center'>
                            <div class='col-sm-4'><label><strong>Repeats:</strong></label></div>
                            <div class='col-sm-4'>
                                <div class='form-group'>
                                    <select class="js-example-basic-single-rt-{{ $task->taskid }}" id="selectrepeat-{{ $task->taskid }}" name="repeatetype">
                                        <option value="D" {{ ($task->repeatetype == 'D' ? 'selected="selected"' : '') }}>Daily</option>
                                        <option value="W" {{ ($task->repeatetype == 'W' ? 'selected="selected"' : '') }}>Weekly</option>
                                        <option value="F" {{ ($task->repeatetype == 'F' ? 'selected="selected"' : '') }}>Byweekly</option>
                                        <option value="M" {{ ($task->repeatetype == 'M' ? 'selected="selected"' : '') }}>Monthly</option>
                                        <option value="Y" {{ ($task->repeatetype == 'Y' ? 'selected="selected"' : '') }}>Yearly</option>
                                    </select>
                                </div>
                            </div>
                            <div class='col-sm-4'>
                                <div class='form-group'>
                                    <div class='input-group' id='executetimedatetimepicker-{{ $task->taskid }}'> 
                                        <input type='text' class="form-control" id="executetime-{{ $task->taskid }}" name="executetime" value="{!! ($task->executetime!= '' ? $task->executetime : '9:30 AM') !!}">
                                        <div class='input-group-append'> 
                                            <span class='input-group-text' id='basic-addon2'>At</span> 
                                        </div>
                                    </div>
                                </div>
                                <script type="text/javascript">
                                var date = new Date();
                                var currentMonth = date.getMonth();
                                var currentDate = date.getDate();
                                var currentYear = date.getFullYear(); 
                                var currentHour = date.getHours();
							    var currentMinute = date.getMinutes() + 5;
                                $(function() 
                                {
                                    $('#executetime-{{ $task->taskid }}').datetimepicker({
                                        format: 'LT',
                                        stepping: 1,
                                        minDate: new Date(currentYear, currentMonth, currentDate, currentHour, currentMinute + 5)
                                    });
                                });
                                </script>
                            </div>
                        </div>
                        <div class='dropdown-divider'></div>
                        <div class='row align-items-center'>
                            <div class='col-sm-4'><label><strong>Due within:</strong></label>
                            </div>
                            <div class='col-sm-4'>
                                <div class='form-group'>
                                    <div class='input-group'> 
                                        <input type='text' id="dueondays-{{ $task->taskid }}" name="dueondays"  class='form-control' value="{!! ($task->dueondays != '' ? $task->dueondays : '5' )!!}">
                                        <div class='input-group-append'> <span class='input-group-text'
                                                id='basic-addon2'>Days</span> </div>
                                    </div>
                                </div>
                            </div>
                            <div class='col-sm-4'>
                                <div class='form-group'>
                                    <div class='input-group' id='newdatetimepicker-{{ $task->taskid }}'> 
                                        <input type='text' id="dueontime-{{ $task->taskid }}" name="dueontime" class="form-control" value="{!! ($task->dueontime!= '' ? $task->dueontime : '5:30 AM') !!}">
                                        <div class='input-group-append'> <span class='input-group-text'
                                                id='basic-addon2'>At</span> </div>
                                    </div>
                                </div>
                                <script type="text/javascript">
                                $(function() 
                                {
                                    $('#dueontime-{{ $task->taskid }}').datetimepicker({
                                    format: 'LT',
                                    stepping: 1
                                    });
                                });
                                </script>
                            </div>
                        </div>
                        <div class='dropdown-divider'></div>
                        <div class='row align-items-center' id="daily-{{ $task->taskid }}">
                            <div class='col-sm-4'><label><strong>Repeats every:</strong></label>
                            </div>
                            <div class='col-sm-5'>
                                <div class='form-group'>
                                    <select class="js-example-basic-single-red-{{ $task->taskid }}" id="noofdays-{{ $task->taskid }}" name="noofdays">
                                        <?php
                                        for($i = 1; $i<=30; $i++)
                                        {
                                        ?>
                                        <option value="<?php echo $i?>" {!!$task->repeatsevery == $i ? 'selected="selected"' : '' !!}><?php echo $i?></option>
                                        <?php
                                        }
                                        ?>  
                                    </select>
                                </div>
                                <script type="text/javascript">
                                    $(function() {
                                        $(".js-example-basic-single-red-{{ $task->taskid }}").select2();
                                    });
                                </script>    
                            </div>
                            <div class='col-sm-3'><label><strong>days</strong></label></div>
                        </div>
                        <div id="weekly-{{ $task->taskid }}" style="display:none;">
                            <div class='row align-items-center'>
                                <div class='col-sm-4'><label><strong>Repeats every:</strong></label>
                                </div>
                                <div class='col-sm-5'>
                                    <div class='form-group'>
                                        <select class="js-example-basic-single-rew-{{ $task->taskid }}" id="noofweeks-{{ $task->taskid }}" name="noofweeks">
                                            <?php
                                            for($i = 1; $i<=30; $i++)
                                            {
                                            ?>
                                            <option value="<?php echo $i?>" {!!$task->repeatsevery == $i ? 'selected="selected"' : '' !!}><?php echo $i?></option>
                                            <?php
                                            }
                                            ?>  
                                        </select>
                                    </div>
                                    <script type="text/javascript">
                                        $(function() {
                                            $(".js-example-basic-single-rew-{{ $task->taskid }}").select2();
                                        });
                                    </script>    
                                </div>
                                <div class='col-sm-3'><label><strong>weeks</strong></label></div>
                            </div>
                            <div class='row align-items-center'>
                                <div class='col-sm-3'><label><strong>Repeat on:</strong></label>
                                </div>
                                <div class='col-sm-9'>
                                    <div class="form-check form-check-inline">
                                    <label class="checkbox-inline">
                                    <input type="checkbox" id="repeateon-0|{{ $task->taskid }}" name="repeateon[]" {!! (is_array($task->repeateon) ? (in_array(0,$task->repeateon) ? 'checked="checked"' : '') : ($task->repeateon == 0 ? 'checked="checked"' : '')) !!}  value="0">
                                    S </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <label class="checkbox-inline">
                                    <input type="checkbox" id="repeateon-1|{{ $task->taskid }}" name="repeateon[]" {!! (is_array($task->repeateon) ? (in_array(1,$task->repeateon) ? 'checked="checked"' : '') : ($task->repeateon == 1 ? 'checked="checked"' : '')) !!} value="1">
                                    M </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <label class="checkbox-inline">
                                    <input type="checkbox" id="repeateon-2|{{ $task->taskid }}" name="repeateon[]" {!! (is_array($task->repeateon) ? (in_array(2,$task->repeateon) ? 'checked="checked"' : '') : ($task->repeateon == 2 ? 'checked="checked"' : '')) !!} value="2">
                                    T </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <label class="checkbox-inline">
                                    <input type="checkbox" id="repeateon-3|{{ $task->taskid }}" name="repeateon[]" {!! (is_array($task->repeateon) ? (in_array(3,$task->repeateon) ? 'checked="checked"' : '') : ($task->repeateon == 3 ? 'checked="checked"' : '')) !!} value="3">
                                    W </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <label class="checkbox-inline">
                                    <input type="checkbox" id="repeateon-4|{{ $task->taskid }}" name="repeateon[]" {!! (is_array($task->repeateon) ? (in_array(4,$task->repeateon) ? 'checked="checked"' : '') : ($task->repeateon == 4 ? 'checked="checked"' : '')) !!} value="4">
                                    T </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <label class="checkbox-inline">
                                    <input type="checkbox" id="repeateon-5|{{ $task->taskid }}" name="repeateon[]" {!! (is_array($task->repeateon) ? (in_array(5,$task->repeateon) ? 'checked="checked"' : '') : ($task->repeateon == 5 ? 'checked="checked"' : '')) !!} value="5">
                                    F </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                    <label class="checkbox-inline">
                                    <input type="checkbox" id="repeateon-6|{{ $task->taskid }}" name="repeateon[]" {!!  (is_array($task->repeateon) ? (in_array(6,$task->repeateon) ? 'checked="checked"' : '') : ($task->repeateon == 6 ? 'checked="checked"' : ''))   !!} value="6">
                                    S </label> 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='row align-items-center' id="byweekly-{{ $task->taskid }}" style="display:none;">
                            <div class='col-sm-4'><label><strong>Repeats every:</strong></label>
                            </div>
                            <div class='col-sm-5'>
                                <div class='form-group'>
                                    <select class="js-example-basic-single-reb-{{ $task->taskid }}" id="nooffortnights-{{ $task->taskid }}" name="nooffortnights">
                                        <?php
                                        for($i = 1; $i<=30; $i++)
                                        {
                                        ?>
                                        <option value="<?php echo $i?>" {!!$task->repeatsevery == $i ? 'selected="selected"' : '' !!}><?php echo $i?></option>
                                        <?php
                                        }
                                        ?>   
                                    </select>
                                </div>
                                <script type="text/javascript">
                                    $(function() {
                                        $(".js-example-basic-single-reb-{{ $task->taskid }}").select2();
                                    });
                                </script>    
                            </div>
                            <div class='col-sm-3'><label><strong>byweeks</strong></label></div>
                        </div>
                        <div id="monthly-{{ $task->taskid }}" style="display:none;">
                            <div class='row align-items-center'>
                                <div class='col-sm-4'><label><strong>Repeats every:</strong></label>
                                </div>
                                <div class='col-sm-5'>
                                    <div class='form-group'>
                                        <select class="js-example-basic-single-rem-{{ $task->taskid }}" id="noofmonths-{{ $task->taskid }}" name="noofmonths">
                                            <?php
                                            for($i = 1; $i<=12; $i++)
                                            {
                                            ?>
                                            <option value="<?php echo $i?>" {!!$task->repeatsevery == $i ? 'selected="selected"' : '' !!}><?php echo $i?></option>
                                            <?php
                                            }
                                            ?>   
                                        </select>
                                    </div>
                                    <script type="text/javascript">
                                        $(function() {
                                            $(".js-example-basic-single-rem-{{ $task->taskid }}").select2();
                                        });
                                    </script>    
                                </div>
                                <div class='col-sm-3'><label><strong>months</strong></label></div>
                            </div>
                            <div class='row align-items-center'>
                                <div class='col-sm-4'><label><strong>Repeat by:</strong></label>
                                </div>
                                <div class='col-sm-8'>
                                    <div class='form-check'> 
                                        <input class='form-check-input' type='radio' name="dayofthe" id="dayofthemonth-{{ $task->taskid }}" value="month" checked> 
                                        <label class='form-check-label' for="dayofthemonth-{{ $task->taskid }}"> day of the month </label> 

                                        <input class='form-check-input' type='radio' name="dayofthe" id="dayoftheweek-{{ $task->taskid }}" value="week"> 
                                        <label class='form-check-label' for="dayoftheweek-{{ $task->taskid }}"> day of the week </label> 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='row align-items-center' id="yearly-{{ $task->taskid }}" style="display:none;">
                            <div class='col-sm-4'><label><strong>Repeats every:</strong></label>
                            </div>
                            <div class='col-sm-5'>
                                <div class='form-group'>
                                    <select class="js-example-basic-single-rey-{{ $task->taskid }}" id="noofyears-{{ $task->taskid }}" name="noofyears">
                                        <?php
                                        for($i = 1; $i<=30; $i++)
                                        {
                                        ?>
                                        <option value="<?php echo $i?>" {!!$task->repeatsevery == $i ? 'selected="selected"' : '' !!}><?php echo $i?></option>
                                        <?php
                                        }
                                        ?>   
                                    </select>
                                </div>
                                <script type="text/javascript">
                                    $(function() {
                                        $(".js-example-basic-single-rey-{{ $task->taskid }}").select2();
                                    });
                                </script>    
                            </div>
                            <div class='col-sm-3'><label><strong>years</strong></label></div>
                        </div>
                        <div class='row align-items-center'>
                            <div class='col-sm-4'><label><strong>Starts on:</strong></label>
                            </div>
                            <div class='col-sm-8'>
                                <div class='form-group'>
                                    <div class='input-group'id='startondatetimepicker-{{ $task->taskid }}'> 
                                        <input type='text' name="starton" id="starton-{{ $task->taskid }}" value="{!! $task->executeon!!}" class='form-control'>
                                        <div class='input-group-append'> <span class='input-group-text'
                                                id='basic-addon2'>Date</span> </div>
                                    </div>
                                </div>
                                <script type="text/javascript">
                                    var cdate = new Date();
                                    var currentMonth = cdate.getMonth();
                                    var currentDate = cdate.getDate();
                                    var currentYear = cdate.getFullYear();
                                    var currentHour = cdate.getHours();
                                    var currentMinute = cdate.getMinutes();
                                    $(function() 
                                    {
                                      $('input#starton-{{ $task->taskid }}').datetimepicker({
                                        format : 'LL',
                                        extraFormats: [ 'DD/MM/YY' ],
                                        minDate: new Date(currentYear, currentMonth, currentDate)
                                      });
                                    });
                                  </script>
                            </div>
                        </div>
                        <div class='dropdown-divider'></div>
                        <div class='row align-items-center'>
                            <div class='col-sm-12'><label><strong>End:</strong></label> </div>
                            <div class='col-sm-12' id="radiodiv-{{ $task->taskid }}">
                                <div class='row'>
                                    <div class='col-sm-3'>
                                        <div class='form-check'> 
                                            <input class='form-check-input' type='radio' name="endafteron" id="endafteron-{{ $task->taskid }}" value="N" {{ ($task->endafteron =='N' ? 'checked="checked"' : '') }}> 
                                            <label class='form-check-label' for="endafteron-{{ $task->taskid }}"> Never </label> 
                                        </div>
                                    </div>
                                    <div class='col-sm-9 m-1'></div>
                                </div>
                                <div class='row'>
                                    <div class='col-sm-3'>
                                        <div class='form-check'> 
                                                <input class='form-check-input' type='radio' name="endafteron" id="endafteron-{{ $task->taskid }}" value="A" {{ ($task->endafteron =='A' ? 'checked="checked"' : '') }}> 
                                                <label class='form-check-label' for="endafteron-{{ $task->taskid }}"> After </label> 
                                        </div>
                                    </div>
                                    <div class='col-sm-9 m-1'>
                                        <div class='input-group'> 
                                            <input type='text' class='form-control numberwz' name="endafter" id="endafter-{!! $task->taskid!!}" value="{!! ($task->nooftimes != '' ? $task->nooftimes : '5')!!}"> 
                                            <div class='input-group-append'> <span class='input-group-text' id='basic-addon2'>Occurrences</span> </div>
                                        </div>
                                    </div>
                                </div>
                                <div class='row'>
                                    <div class='col-sm-3'>
                                        <div class='form-check'> 
                                            <input class='form-check-input' type='radio' name="endafteron" id="endafteron-{{ $task->taskid }}" value="O" {{ ($task->endafteron =='O' ? 'checked="checked"' : '') }}> 
                                            <label class='form-check-label' for="endafteron-{{ $task->taskid }}"> On </label> </div>
                                    </div>
                                    <div class='col-sm-9'>
                                        <div class='input-group' id='endondatetimepicker-{{ $task->taskid }}'> 
                                            <input type='text' class='form-control' name="endon" id="endon-{{ $task->taskid }}" value="{!! $task->endon!!}">
                                            <div class='input-group-append'> <span class='input-group-text' id='basic-addon2'>Date</span> </div>
                                        </div>
                                        <script type="text/javascript">
                                            var date = new Date();
                                            var currentMonth = date.getMonth();
                                            var currentDate = date.getDate();
                                            var currentYear = date.getFullYear();
                                            $(function() 
                                            {
                                              $('input#endon-{{ $task->taskid }}').datetimepicker({
                                                format : 'LL',
                                                extraFormats: [ 'DD/MM/YY' ],
                                                minDate: new Date(currentYear, currentMonth, currentDate)
                                              });
                                            });
                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='dropdown-divider'></div>
                        <div class='row'>
                            <div class='col-sm-12 m-4'><label><strong>Summary:</strong><span id="summerytext"> {!! $task->summerytext !!}</span></label></div>
                        </div>
                        <div class='row'>
                            <div class='col-sm-12'> 
                                <input type="button" name="donepop" id="donepop-{{ $task->taskid }}" class='btn btn-primary' value='Done'> 
                                <input type="reset" name="cancelpop" id="cancelpop-{{ $task->taskid }}" class='btn btn-danger' value='Cancel'> 
                            </div>
                        </div>
                </div>
                <!--pop end--> 
                @endif
            </div>
        </div>
    </form>
</div>