<h5 class="relative"><a href="{{ URL::to($label->seourl) }}">{{ $label->labelname }}</a>
  @if( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || in_array("3",$companyInfo->user_type) || in_array("4",$companyInfo->user_type))
      <div class="todoEdit">
          <a class="text-primary" style="cursor:pointer;" id="deletelabel-{!! $label->labelid !!}"><i class="far fa-trash-alt"></i></a>
          <a class="text-primary" style="cursor:pointer;" id="editlabel-{!! $label->labelid !!}"><i class="far fa-edit"></i></a>
      </div>
  @endif
</h5>
<div id="ajaxlabel-{!! $label->labelid !!}"></div>
<ul class="list-group">
  @if(count($labeltasks) > 0) 
    @foreach($labeltasks as $labellist)
      @foreach($labellist->todos as $labeltask) 
          @if($labeltask->mastertask != 1 )
              <li class="list-group-item" id="removediv-{!! $labeltask->taskid !!}">
                  <div class="customCheckBox">
                      <input type="checkbox" name="taskcomplete" id="taskcomplete-{{ $labeltask->taskid.'_'.$labeltask->labelid }}"><span class="checkTick"></span>
                  </div>
                  <div class="todoListText"><a href="{{ URL::to($labeltask->seourl) }}">{{ $labeltask->taskname }}</a></div>
                  <div class="list-group-item-badges"> <span class="badge badge-primary">{{ ($labeltask->totalcomment > 1 ? $labeltask->totalcomment.' comments' : $labeltask->totalcomment.' comment' ) }}</span>
                      <span class="badge badge-secondary"><a style="cursor:pointer;" id="uname-{{ $labeltask->taskid }}">{{ $labeltask->usernames }} {!! ($labeltask->taskenddate != NULL ? date("d F Y",strtotime($labeltask->taskenddate))
                              : '' ) !!}</a></span> 
                      <span class="badge badge-secondary"><a style="cursor:pointer;" id="addtime-{{ $labeltask->taskid }}">{!! ($labeltask->total_time != '' ? 'Time: '.$labeltask->total_time : 'Add Time' ) !!}</a></span>
                  </div>
                  @if( $project->archived == 0 && ( in_array("1",$companyInfo->user_type) || in_array("2",$companyInfo->user_type) || in_array("3",$companyInfo->user_type) || in_array("4",$companyInfo->user_type) ) )
                  <div class="todoEdit">
                      <a style="cursor:pointer;" id="deletetodo-{!! $labeltask->taskid.'|'.$labeltask->labelid !!}"><i class="far fa-trash-alt"></i></a>
                      <a style="cursor:pointer;" id="todo-{!! $labeltask->taskid !!}"><i class="far fa-edit"></i></a>
                  </div>
                  @endif
              </li>
          @endif
      @endforeach
    @endforeach    
  @endif
  @if($project->archived == 0)
      <li class="list-group-item"><a style="cursor:pointer;" id="add-to-todo-{{ $label->labelid }}" class="text-primary">Add a To-do</a></li>
  @endif
</ul>
<div id="ajaxtodoadd-{!! $label->labelid !!}">
    @include('task.addmastertodo')
</div>