<?php
namespace App\Models;

use App\Jobs\SendRequestEmail;
use App\Library\Strings;
use Auth;
use DB;
use File;
use Illuminate\Database\Eloquent\Model;
use Session;
use General;
//use \App\library\Simpleimage;

use Timezone;

class Task extends Model
{
    protected $table = 'tasks';
    protected $i = 0;
    protected $newdata = array();

    protected $j = 0;
    protected $newdata1 = array();

    protected $k = 0;
    protected $newdata2 = array();

    protected $l = 0;
    protected $newdata3 = array();

    public function __construct()
    {
        $this->strings = new Strings;
        $this->general = new General;
    }

    public static function setConfigValue()
    {
        $con_rss = DB::select('select * from `config`');
        foreach ($con_rss as $con_rs) {
            if (!defined($con_rs->cfg_key)) {
                define($con_rs->cfg_key, $con_rs->cfg_value);
            }
        }
    }

    public function getTotalTask($projectId = false, $userType = false)
    {
        $queryString = "";
        $totaltask = "";
        $UId = (isset(Auth::user()->id) ? Auth::user()->id : Session::get('invitedNotRegUserId'));
        if (in_array("3", $userType)) {
            $inviteid = DB::table('invites')->where([['userid', $UId], ['projectid', $projectId], ['invitetype', 'C'], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
            if ($inviteid) {
                $queryString = " and clientaccess = 0";
            }
        }
        if (isset($inviteid)) {
            $totaltask = DB::table('tasks')
            ->where([['projectid',$projectId],['labelid','!=',0],['completed',0],['mastertask',0],['deleted_at',null]])
            ->whereRaw($queryString)
            ->count();
        }else{
            $totaltask = DB::table('tasks')
            ->where([['projectid',$projectId],['labelid','!=',0],['completed',0],['mastertask',0],['deleted_at',null]])
            ->count();
        }
        return $totaltask;
    }

    public function getTotalDiscussion($projectId = false)
    {
        $totaldiscussion = DB::table('tasks')
        ->join('comments', 'tasks.taskid', '=', 'comments.taskid')
        ->where([['tasks.projectid', $projectId],['comments.projectid', $projectId], ['comments.description','!=', null], ['comments.labelid', 0], ['tasks.mastertask', 0], ['tasks.completed', 0], ['tasks.deleted_at', null], ['comments.deleted_at', null]])
        ->count();
        return $totaldiscussion;
    }

    public function getTotalTimeEntry($projectId = false)
    {
        $total = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS totalSum FROM todo_comments where projectid = " . $projectId);
        if($total[0]->totalSum != ''){
            $totalTimeArr = explode(":",$total[0]->totalSum);
            $totalTimeStr = $totalTimeArr[0].":".$totalTimeArr[1];
            return $totalTimeStr;
        }
        return $total[0]->totalSum;
    }

    public function getProjectUpdateList($projectId = false, $limitQuery = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $projectInfo = DB::table('projects')->where('projectId', $projectId)->first();
        $inviteUsers = $this->invitedUser($projectId);
        $comments = DB::select("select max(commentid) commentid, taskid, projectid, labelid, max(created_at) created_at, created_by from todo_comments where projectid = " . $projectId . " and description != '' and created_by in (" . $inviteUsers . "," . $projectInfo->created_by . "," . Auth::user()->id . ") and deleted_at is NULL group by taskid order by commentid desc " . $limitQuery);
        if (count($comments) > 0) {
            foreach ($comments as $comment) {
                $commentseoUrl = "";
                $task = DB::table('tasks')->where([['taskid', $comment->taskid], ['deleted_at', null]])->first();
                if (!empty($task)) {
                    $commentCreatedBy = DB::table('comments')->where('commentid', $comment->commentid)->value('created_by');
                    $commentseoUrl = "/project/" . $projectInfo->seoname . "/todo/" . $task->seoname . "#" . $comment->commentid;
                    $taskArray = json_decode(json_encode($task), true);
                    $userInfo = DB::table('users')->where('id', $commentCreatedBy)->first();
                    $userArray = json_decode(json_encode($userInfo), true);
                    $array = array(
                        "commentid" => $comment->commentid,
                        "taskname" => $taskArray['taskname'],
                        "projectid" => $comment->projectid,
                        "labelid" => $comment->labelid,
                        "created_at" => $this->general->converttimezoneFromUTCWTZ($comment->created_at),
                        "seourl" => $commentseoUrl,
                        "username" => $userArray['firstname'] . " " . $userArray['lastname'],
                    );
                    $this->newdata[$this->i] = (object) $array;
                    $this->i++;
                }
            }
        }
        return $this->newdata;
    }

    private function invitedUser($projectId)
    {
        $userArr = DB::table('invites')->where('projectid', $projectId)->pluck('userid')->toArray();
        $userIds = (count($userArr) > 0 ? implode(",", $userArr) : 0);
        return $userIds;
    }

    public function getProjectDiscussions($projectId = false, $searchQuery = false, $orderBy = false, $limitQuery = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $array3 = array();
        $queryString = ($limitQuery == '' ? ' order by created_at '.$orderBy : ' group by taskid order by created_at desc ' .$orderBy.' '. $limitQuery);

        $comments = DB::select("select commentid, taskid, projectid, labelid, description, created_by, created_at from todo_comments where projectid = " . $projectId . " ".$searchQuery." and labelid = 0 and taskid in(select distinct(taskid) from todo_tasks where projectid = " . $projectId . " and mastertask = 0 and completed = 0 and deleted_at is NULL) and description is not NULL and deleted_at is NULL " . $queryString);
        if (count($comments) > 0) {
            foreach ($comments as $comment) {
                $commentseoUrl = "";
                $totalComment = 0;
                $totalComment = DB::table('comments')->where([['taskid', $comment->taskid], ['deleted_at', null]])->count();
                $userInfo = DB::table('users')->where('id', $comment->created_by)->first();
                $userArray = json_decode(json_encode($userInfo), true);
                $taskInfo = DB::table('tasks')->where([['taskid', $comment->taskid], ['deleted_at', null]])->first();
                if (!empty($taskInfo)) {
                    $taskArray = json_decode(json_encode($taskInfo), true);
                    $projectInfo = DB::table('projects')->where('projectid', $taskArray['projectid'])->first();
                    $projectArray = json_decode(json_encode($projectInfo), true);
                    $commentseoUrl = ($comment->labelid != 0 ? "project/" . $projectArray['seoname'] . "/todo/" . $taskArray['seoname'] . "#" . $comment->commentid : "project/" . $projectArray['seoname'] . "/discussion/" . $taskArray['seoname'] . "#" . $comment->commentid);
                    if ($limitQuery == '') {
                        $array = array(
                            "taskid" => $comment->taskid,
                            "taskname" => $taskArray['taskname'],
                            "projectid" => $comment->projectid,
                            "labelid" => $comment->labelid,
                            "created_at" => $this->general->converttimezoneFromUTCWTZ($comment->created_at),
                            "seourl" => $commentseoUrl,
                            "description" => $this->strings->limit_text($this->strings->ConvertHTMLToText($comment->description != '' ? $comment->description : ''), 20), "totalcomment" => ($totalComment == 0 ? '0' : $totalComment),
                            "username" => $userArray['firstname'] . " " . $userArray['lastname'],
                            "email" => $userArray['email'],
                            "profilepic" => $userArray['profilepic'],
                        );
                        $this->newdata[$this->i] = (object) $array;
                        $this->i++;
                    } else {
                        if (!in_array($comment->taskid, $array3)) {
                            $array3[] = $comment->taskid;
                            $array = array(
                                "taskid" => $comment->taskid,
                                "taskname" => $taskArray['taskname'],
                                "projectid" => $comment->projectid,
                                "labelid" => $comment->labelid,
                                "created_at" => $this->general->converttimezoneFromUTCWTZ($comment->created_at),
                                "seourl" => $commentseoUrl,
                                "description" => $this->strings->limit_text($this->strings->ConvertHTMLToText($comment->description != '' ? $comment->description : ''), 20), "totalcomment" => ($totalComment == 0 ? '0' : $totalComment),
                                "username" => $userArray['firstname'] . " " . $userArray['lastname'],
                                "email" => $userArray['email'],
                                "profilepic" => $userArray['profilepic'],
                            );
                            $this->newdata[$this->i] = (object) $array;
                            $this->i++;
                        }
                    }
                }
            }
        }
        return $this->newdata;
    }
    
    private function tasklist($projectId, $labelId, $inviteUsers, $userType)
    {
        $this->j = 0;
        $this->newdata1 = array();
        $array1 = array();
        $queryString = "";
        if (in_array("3", $userType)) {
            $inviteid = DB::table('invites')->where([['userid', Auth::user()->id], ['projectid', $projectId], ['invitetype', 'C'], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
            if ($inviteid) {
                $queryString = " and clientaccess = 0";
            }
        }
        //DB::enableQueryLog();
        if($inviteUsers == ''){
            $strQuery = "";
        }else{
            $strQuery = " and created_by in (" . $inviteUsers . ")";
        }
        $tasks = DB::select("select * from todo_tasks where completed = 0 and projectid = " . $projectId . " and labelid = " . $labelId ." ".$strQuery." and repeatcompleted = 0 and deleted_at is NULL " . $queryString . " order by taskid desc");
        //print_r(DB::getQueryLog());
        if (count($tasks) > 0) {
            foreach ($tasks as $task) {
                $seoUrl = "";
                $projectInfo = DB::table('projects')->where('projectid', $task->projectid)->first();
                $seoUrl = "/project/" . $projectInfo->seoname . "/todo/" . $task->seoname;

                $totalComment = DB::table('comments')->where([['taskid', '=', $task->taskid], ['description', '!=', ''], ['deleted_by', 0]])->count();
                //$taskenddate = $task->taskenddate != NULL ? $task->taskenddate : NULL;
                $array1 = array(
                    "taskid" => $task->taskid,
                    "mastertask" => $task->mastertask,
                    "summerytext" => $task->summerytext,
                    "taskname" => $task->taskname,
                    "projectid" => $task->projectid,
                    "labelid" => $task->labelid,
                    "taskenddate" => ($task->taskenddate != null ? $this->general->converttimezoneFromUTCWTZ($task->taskenddate) : null),
                    "created_at" => $this->general->converttimezoneFromUTCWTZ($task->created_at),
                    "seourl" => $seoUrl,
                    "assignuseremails" => explode(",", $task->assignuseremails),
                    "assignusernames" => $this->getAssignUserNames($task->taskid),
                    "repeatetype" => $task->repeatetype,
                    "nooftimes" => $task->nooftimes,
                    "repeateon" => explode(",", $task->repeateon),
                    "dueondays" => $task->dueondays,
                    "repeatsevery" => $task->repeatsevery,
                    "dueontime" => $task->dueontime,
                    "executetime" => $task->executetime,
                    "endafteron" => $task->endafteron,
                    "executeon" => (($task->executeon != '0000-00-00' ? date("M d,Y", strtotime($task->executeon)) : '')),
                    "starton" => (date("M d,Y", strtotime($task->starton))),
                    "endon" => ($task->endon != '0000-00-00' ? date("M d,Y", strtotime($task->endon)) : ''),
                    "clientaccess" => $task->clientaccess,
                    "created_by" => $task->created_by,
                    "totalcomment" => ($totalComment == 0 ? '0' : $totalComment),
                    "usernames" => ($this->assignedUserName($task->taskid) == '' ? 'Unassigned' : $this->assignedUserName($task->taskid)),
                    "assignusers" => $this->assigneUserEmails($task->taskid),
                    "total_time" => $this->totalTime($task->taskid),
                );
                $this->newdata1[$this->j] = (object) $array1;
                $this->j++;
            }
        }
        return $this->newdata1;
    }
    
    public function getLabelTaskList($projectId = false, $userType = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $queryString = "";
        $projectInfo = DB::table('projects')->where('projectId', $projectId)->first();
        $inviteUsers = $this->invitedUser($projectId) . "," . $projectInfo->created_by . "," . Auth::user()->id;
        if (in_array("3", $userType)) {
            $inviteid = DB::table('invites')->where([['userid', Auth::user()->id], ['projectid', $projectId], ['invitetype', 'C'], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
            if ($inviteid) {
                $queryString = " and clientaccess = 0";
            }
        }
        $labels = DB::select("select * from todo_labels where projectid = " . $projectId . " and deleted_at is NULL " . $queryString . " order by labelid desc");
        if (count($labels) > 0) {
            $totalComplated = 0;
            $totalNotComplated = 0;
            $totalAll = 0;
            $totaltodos = 0;
            foreach ($labels as $label) {
                $seoUrl = "";
                $seoUrl = "project/" . $projectInfo->seoname . "/todolist/" . $label->seoname;

                $totalAll = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['deleted_at', null]])->count();
                $totalComplated = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['completed', 1], ['deleted_at', null]])->count();
                $totalNotComplated = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['completed', 0], ['deleted_at', null]])->count();
                $totaltodos = $totaltodos + $totalAll;
                if (($totalAll == $totalComplated) && ($totalComplated != 0) && ($totalAll != 0) && ($totalNotComplated == 0)) {

                } else if ($totalAll == 0 && $totalComplated == 0 && $totalNotComplated == 0) {
                    $array = array(
                        "labelid" => $label->labelid,
                        "labelname" => $label->labelname,
                        "projectid" => $label->projectid,
                        "clientaccess" => $label->clientaccess,
                        "created_at" => $this->general->converttimezoneFromUTCWTZ($label->created_at),
                        "seourl" => $seoUrl,
                        "todos" => $this->tasklist($projectId, $label->labelid, $inviteUsers, $userType),
                        "totaltodos" => $totaltodos,
                    );
                    $this->newdata[$this->i] = (object) $array;
                    $this->i++;
                } else {
                    $array = array(
                        "labelid" => $label->labelid,
                        "labelname" => $label->labelname,
                        "projectid" => $label->projectid,
                        "clientaccess" => $label->clientaccess,
                        "created_at" => $this->general->converttimezoneFromUTCWTZ($label->created_at),
                        "seourl" => $label->seourl,
                        "todos" => $this->tasklist($projectId, $label->labelid, $inviteUsers, $userType),
                        "totaltodos" => $totaltodos,
                    );
                    $this->newdata[$this->i] = (object) $array;
                    $this->i++;
                }
            }
        }
        return $this->newdata;
    }

    public function getProjects($companyId = false, $userId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        if ($userId == false) {
            $projects = DB::select("select projectid, projectname,seoname from todo_projects where archived = 0 and deleted_at is NULL and companyid=" . $companyId);
        } else {
            $projects = DB::select("select tp.projectid, tp.projectname,tp.seoname from todo_projects tp, todo_invites ti where tp.archived = 0 and tp.deleted_at is NULL and tp.companyid=" . $companyId . " and tp.projectid = ti.projectid and ti.userid = " . $userId . " and ti.deleted_at = '0000-00-00 00:00:00' ");
        }
        if (count($projects) > 0) {
            foreach ($projects as $project) {
                $array = array(
                    "projectid" => $project->projectid,
                    "projectname" => $project->projectname,
                    "seoname" => $project->seoname,
                );
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
            }
        }
        return $this->newdata;
    }

    public function getLabelTaskListByUserId($companyId = false,$userType = false, $userId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $projectIds = '';
        $curentDate = date("Y-m-d");
        $projectIds = $this->getAssignProjectIds($companyId, $userId);

        $projectIds = ($projectIds != '' ? $projectIds : '0');

        $labels = DB::select("select * from todo_labels where projectid in(" . $projectIds . ") and deleted_at is NULL order by labelid desc");

        if (count($labels) > 0) {
            $totalComplated = 0;
            $totalNotComplated = 0;
            $totalAll = 0;
            $totaltodos = 0;
            foreach ($labels as $label) {
                $totalCount = DB::select("select count(*) as totalcount from todo_tasks where labelid = " . $label->labelid . " and deleted_at is NULL and completed = 0 and created_at  < '" . $curentDate . "' and mastertask = 0  order by labelid");
                if ($totalCount[0]->totalcount > 0) {
                    $projectInfo = DB::table('projects')->where('projectid', $label->projectid)->first();
                    $projectArray = json_decode(json_encode($projectInfo), true);

                    $totalAll = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid]])->count();
                    $totalComplated = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['completed', 1]])->count();
                    $totalNotComplated = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['completed', 0]])->count();
                    $totaltodos = $totaltodos + $totalAll;
                    if (($totalAll == $totalComplated) && ($totalComplated != 0) && ($totalAll != 0) && ($totalNotComplated == 0)) {

                    } else if ($totalAll == 0 && $totalComplated == 0 && $totalNotComplated == 0) {
                        $array = array(
                            "labelid" => $label->labelid,
                            "labelname" => $label->labelname,
                            "projectid" => $label->projectid,
                            "clientaccess" => $label->clientaccess,
                            "projectname" => $projectArray['projectname'],
                            "projectseourl" => $projectArray['seourl'],
                            "created_at" => $this->general->converttimezoneFromUTCWTZ($label->created_at),
                            "seourl" => $label->seourl,
                            "todos" => $this->tasklist($label->projectid, $label->labelid, '',$userType),
                            "totaltodos" => $totaltodos,
                        );
                        $this->newdata[$this->i] = (object) $array;
                        $this->i++;
                    } else {
                        $array = array(
                            "labelid" => $label->labelid,
                            "labelname" => $label->labelname,
                            "projectid" => $label->projectid,
                            "clientaccess" => $label->clientaccess,
                            "projectname" => $projectArray['projectname'],
                            "projectseourl" => $projectArray['seourl'],
                            "created_at" => $this->general->converttimezoneFromUTCWTZ($label->created_at),
                            "seourl" => $label->seourl,
                            "todos" => $this->tasklist($label->projectid, $label->labelid, '',$userType),
                            "totaltodos" => $totaltodos,
                        );
                        $this->newdata[$this->i] = (object) $array;
                        $this->i++;
                    }
                }
            }
        }
        return $this->newdata;
    }

    public function getAjaxLabelTaskListByUserId($request,$companyId = false,$userType = false, $userId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $curentDate = ($request->taskduedate != 0 ? $request->taskduedate : date("Y-m-d"));
        $queryString = ($request->projectid == 0 ? '' : ' and projectid = ' . $request->projectid);

        if ($userId == false) {
            $labels = DB::select("select * from todo_labels where projectid in(select projectid from todo_projects where companyid = " . $companyId . " and archived = 0 " . $queryString . " and deleted_at is NULL ) and deleted_at is NULL order by labelid desc");
        } else {
            if ($request->projectid == 0) {
                $projectIds = $this->getAssignProjectIds($companyId, $userId);

                $labels = DB::select("select * from todo_labels where projectid in(" . $projectIds . ") and deleted_at is NULL order by labelid desc");
            } else {
                $labels = DB::select("select * from todo_labels where projectid = " . $request->projectid . " and deleted_at is NULL order by labelid desc");
            }
        }
        if ($labels) {
            $totalComplated = 0;
            $totalNotComplated = 0;
            $totalAll = 0;
            $totaltodos = 0;
            foreach ($labels as $label) {
                $totalCount = DB::select("select count(*) as totalcount from todo_tasks where labelid = " . $label->labelid . " and deleted_at is NULL and completed = 0 and created_at  < '" . $curentDate . "' and mastertask = 0  order by labelid");
                if ($totalCount[0]->totalcount > 0) {
                    $projectInfo = DB::table('projects')->where('projectid', $label->projectid)->first();
                    $projectArray = json_decode(json_encode($projectInfo), true);

                    $totalAll = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid]])->count();
                    $totalComplated = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['completed', 1]])->count();
                    $totalNotComplated = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['completed', 0]])->count();
                    $totaltodos = $totaltodos + $totalAll;
                    if (($totalAll == $totalComplated) && ($totalComplated != 0) && ($totalAll != 0) && ($totalNotComplated == 0)) {

                    } else if ($totalAll == 0 && $totalComplated == 0 && $totalNotComplated == 0) {
                        $array = array(
                            "labelid" => $label->labelid,
                            "labelname" => $label->labelname,
                            "projectid" => $label->projectid,
                            "clientaccess" => $label->clientaccess,
                            "projectname" => $projectArray['projectname'],
                            "projectseourl" => $projectArray['seourl'],
                            "created_at" => $this->general->converttimezoneFromUTCWTZ($label->created_at),
                            "seourl" => $label->seourl,
                            "todos" => $this->tasklist($label->projectid, $label->labelid, '',$userType),
                            "totaltodos" => $totaltodos,
                        );
                        $this->newdata[$this->i] = (object) $array;
                        $this->i++;
                    } else {
                        $array = array(
                            "labelid" => $label->labelid,
                            "labelname" => $label->labelname,
                            "projectid" => $label->projectid,
                            "clientaccess" => $label->clientaccess,
                            "projectname" => $projectArray['projectname'],
                            "projectseourl" => $projectArray['seourl'],
                            "created_at" => $this->general->converttimezoneFromUTCWTZ($label->created_at),
                            "seourl" => $label->seourl,
                            "todos" => $this->tasklist($label->projectid, $label->labelid, '',$userType),
                            "totaltodos" => $totaltodos,
                        );
                        $this->newdata[$this->i] = (object) $array;
                        $this->i++;
                    }
                }
            }
        }
        return $this->newdata;
    }

    private function getAssignProjectIds($companyId, $userId){

        $assignProjectIdArr = array();
        $assignProjectIdArr = DB::table('assigns')
        ->join('tasks', 'assigns.taskid', '=', 'tasks.taskid')
        ->where([['assigns.userid', $userId], ['assigns.status', 0], ['tasks.completed', 0], ['assigns.deleted_at', null]])
        ->pluck('tasks.projectid')->toArray();
        $projectIds = (!empty($assignProjectIdArr) ? implode(",", $assignProjectIdArr) : '');
        return $projectIds;
    }

    private function notifyUserName($taskid)
    {
        $userNames = '';
        $notifiedIds = '';
        $assignIds = '';
        $allUserNames = array();
        $UId = (isset(Auth::user()->id) ? Auth::user()->id : Session::get('invitedNotRegUserId'));
        $commentInfo = DB::table('comments')->where('taskid', '=', $taskid)->orderBy('commentid', 'desc')->first();

        //Assign also includes in notify users 10-01-2018
        $assignUIdArr = DB::table('assigns')
            ->join('users', 'assigns.userid', '=', 'users.id')
            ->where([['assigns.taskid', $taskid], ['assigns.status', 0], ['users.isactive', 1], ['assigns.deleted_at', null]])
            ->pluck('assigns.userid')->toArray();
        $assignIds = (!empty($assignUIdArr) ? implode(",", $assignUIdArr) : '');
        //end

        if ($commentInfo && $commentInfo->notifiedids != null) {
            if ($assignIds != '') {
                $notifiedIds = $commentInfo->notifiedids . "," . $commentInfo->created_by . "," . $assignIds;
            } else {
                $notifiedIds = $commentInfo->notifiedids . "," . $commentInfo->created_by;
            }
            $notifiedIds = ($notifiedIds != '' ? explode(",", $notifiedIds) : '');
        } else {
            if ($assignIds != '') {
                $notifiedIds = ($assignIds != '' ? explode(",", $assignIds) : '');
            }
        }

        if ($notifiedIds != '' && count($notifiedIds) > 0) {
            $notifiedids = array_unique($notifiedIds);
            foreach ($notifiedids as $notifiedid) {
                $userInfo = DB::table('users')->where('id', $notifiedid)->first();
                if ($UId != $userInfo->id) {
                    $allUserNames[] = $userInfo->firstname;
                }
            }
            if ($allUserNames != '') {
                $userNames = implode(", ", $allUserNames);
            }
        }
        return $userNames;
    }

    private function assignedUserName($taskId)
    {
        $userNames = '';
        // $userNameArr = DB::table('users')
        //         ->join('assigns', 'users.id', '=', 'assigns.userid')
        //         ->where([['assigns.taskid', $taskId],['assigns.status', '0'], ['users.deleted_at', '0000-00-00 00:00:00']])
        //         ->pluck('users.firstname','users.lastname')->toArray();
        $allUserNames = array();
        $assigns = DB::table('assigns')->where([['taskid', $taskId], ['status', '0']])->get();
        if (count($assigns) > 0) {
            foreach ($assigns as $assign) {
                $userInfo = DB::table('users')->where('id', $assign->userid)->first();
                if ($userInfo) {
                    $allUserNames[] = $userInfo->firstname . " " . $userInfo->lastname;
                }
            }
            $userNames = (empty($allUserNames) ? '' : implode(", ", $allUserNames));
        }
        return $userNames;
    }

    private function assigneUserEmails($taskId)
    {
        $userEmailArr = DB::table('users')
                ->join('assigns', 'users.id', '=', 'assigns.userid')
                ->where([['assigns.taskid', $taskId],['assigns.status', '0'], ['users.isactive', '1']])
                ->pluck('users.email')->toArray();
        return $userEmailArr;
    }

    private function totalTime($taskid)
    {
        $returnTotalTime = '';
        $totalTimeEntry = DB::table('timeentries')->where('taskid', $taskid)->count();
        if ($totalTimeEntry > 0) {
            $totalTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS totalSum FROM todo_comments where taskid = " . $taskid);
            $returnTotalTime = $totalTime[0]->totalSum;
        }
        return $returnTotalTime;
    }

    private function getAssignUserNames($taskId)
    {
        $userNames = '';
        $assignUserEmailArr = array();
        $allUserNames = array();
        $taskInfo = DB::table('tasks')->where([['taskid', $taskId]])->first();
        if ($taskInfo->mastertask == 1) {
            $assignUserEmailArr = explode(",", $taskInfo->assignuseremails);
            if (!empty($assignUserEmailArr)) {
                foreach ($assignUserEmailArr as $assignemail) {
                    $userInfo = DB::table('users')->where('email', $assignemail)->first();
                    $userArray = json_decode(json_encode($userInfo), true);
                    $allUserNames[] = $userArray['firstname'] . " " . $userArray['lastname'];
                }
                $userNames = implode(", ", $allUserNames);
            }
        }
        return $userNames;
    }

    public function getTotalCompletedTodo($projectId = false)
    {
        return DB::table('tasks')->where([['projectid', $projectId], ['completed', 1], ['deleted_at', null]])->count();
    }

    public function getTotalAcorssLabel($projectId = false)
    {
        $total = DB::select("select count(distinct(labelid)) as total from todo_tasks where projectid = " . $projectId . " and completed = 1");
        return ($total[0]);
    }

    public function getCompletedtodolist($projectId = false, $userType = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $queryString = "";
        if (in_array("3", $userType)) {
            $inviteid = DB::table('invites')->where([['userid', Auth::user()->id], ['projectid', $projectId], ['invitetype', 'C'], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
            if ($inviteid) {
                $inviteid = DB::table('invites')->where([['userid', Auth::user()->id], ['projectid', $projectId], ['invitetype', 'C'], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
                if ($inviteid) {
                    $queryString = " and clientaccess = 0";
                }
            }
        }
        $projectInfo = DB::table('projects')->where('projectid', $projectId)->first();
        $inviteUsers = $this->invitedUser($projectId);
        $labels = DB::select("select labelid, projectid, labelname, seoname, seourl, clientaccess from todo_labels where projectid = " . $projectId . " and created_by in (" . $inviteUsers . "," . $projectInfo->created_by . "," . Auth::user()->id . ") " . $queryString . " order by labelid desc");
        if (count($labels) > 0) {
            $k = 0;
            foreach ($labels as $label) {
                $seoUrl = "project/" . $projectInfo->seoname . "/todolist/" . $label->seoname;
                $totalAll = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['deleted_at', null]])->count();
                $totalComplated = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['completed', 1], ['deleted_at', null]])->count();
                $totalNotComplated = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['completed', 0], ['deleted_at', null]])->count();
                if ($totalAll == $totalComplated && $totalComplated != 0 && $totalAll != 0 && $totalNotComplated == 0) {
                    $array = array(
                        "lableid" => $label->labelid,
                        "labelname" => $label->labelname,
                        "seourl" => $seoUrl,
                        "clientaccess" => $label->clientaccess,
                        "first" => ($k == 0 ? 1 : 0),
                    );
                    $k++;
                    $this->newdata[$this->i] = (object) $array;
                    $this->i++;
                }
            }
        }
        return $this->newdata;
    }


    public function completeTask($request)
    {
        $taskInfo = DB::table('tasks')->where('taskid', $request->taskid)->first();
        if ($taskInfo) {
            if ($taskInfo->completed == 1) {
                return "2";
            }
        }
        $data = array("taskid" => $request->taskid, "status" => $request->status, "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
        $tcid = DB::table('tasks_completed')->insertGetId($data);
        if ($tcid > 0) {
            $notifiedIds = '';
            $commentInfo = DB::table('comments')->where('taskid', '=', $request->taskid)->orderBy('commentid', 'desc')->first();
            if ($commentInfo && $commentInfo->notifiedids != null) {
                $notifiedIds = $commentInfo->notifiedids;
            }
            $data = array("taskid" => $request->taskid, "projectid" => $taskInfo->projectid, "labelid" => $taskInfo->labelid, 'notifiedids' => $notifiedIds, "status" => $request->status, "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
            $comid = DB::table('comments')->insertGetId($data);
            DB::table('tasks')->where(['taskid' => $request->taskid])->update(['completed' => $request->status]);
        }

        // send email
        if ($taskInfo->projectid != 0 && $taskInfo->labelid != 0) {
            $completedByInfo = DB::table('users')->where('id', Auth::user()->id)->first();
            $projectInfo = DB::table('projects')->where('projectid', $taskInfo->projectid)->first();
            $labelInfo = DB::table('labels')->where('labelid', $taskInfo->labelid)->first();

            $inviteEmails = $this->completeTodoUserEmails($request->taskid);
            $userNames = $this->completeTodoUserName($request->taskid);

            $mailvar = ['todolistname' => $labelInfo->labelname, 'todolisturl' => $labelInfo->seourl, 'inviteEmails' => $inviteEmails, 'projectname' => $projectInfo->projectname, 'taskName' => $taskInfo->taskname, 'profilePic' => $completedByInfo->profilepic, 'completedByName' => $completedByInfo->firstname . " " . $completedByInfo->lastname, 'userNames' => $userNames, 'seoUrl' => $taskInfo->seourl, 'templateName' => 'emails.todoCompleted'];
            dispatch((new SendRequestEmail($mailvar))->delay(10 * 1));
        }
        if ($tcid > 0) {
            return "1";
        } else {
            return "0";
        }
    }

    public function reopenTask($request)
    {
        $taskcompletedid = DB::table('tasks_completed')->where([['status', 1], ['taskid', $request->taskid]])->value('taskcompletedid');
        if ($taskcompletedid > 0) {
            DB::table('tasks_completed')->where(['taskcompletedid' => $taskcompletedid])->update(['status' => 2, 'updated_at' => date("Y-m-d H:i:s")]);
        }
        $taskInfo = DB::table('tasks')->where('taskid', $request->taskid)->first();

        $data = array("taskid" => $request->taskid, "status" => $request->status, "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
        $tcid = DB::table('tasks_completed')->insertGetId($data);
        if ($tcid > 0) {
            $notifiedIds = '';
            $commentInfo = DB::table('comments')->where('taskid', '=', $request->taskid)->orderBy('commentid', 'desc')->first();
            if ($commentInfo && $commentInfo->notifiedids != null) {
                $notifiedIds = $commentInfo->notifiedids;
            }

            $data = array("taskid" => $request->taskid, "projectid" => $taskInfo->projectid, "labelid" => $taskInfo->labelid, "status" => 2, 'notifiedids' => $notifiedIds, "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
            $comid = DB::table('comments')->insertGetId($data);

            DB::table('tasks')->where(['taskid' => $request->taskid])->update(['completed' => $request->status]);
        }

        // send email
        $reopenByInfo = DB::table('users')->where('id', Auth::user()->id)->first();
        $projectInfo = DB::table('projects')->where('projectid', $taskInfo->projectid)->first();
        $labelInfo = DB::table('labels')->where('labelid', $taskInfo->labelid)->first();

        $inviteEmails = $this->completeTodoUserEmails($request->taskid);
        $userNames = $this->completeTodoUserName($request->taskid);

        $mailvar = ['todolistname' => $labelInfo->labelname, 'todolisturl' => $labelInfo->seourl, 'inviteEmails' => $inviteEmails, 'projectname' => $projectInfo->projectname, 'profilePic' => $reopenByInfo->profilepic, 'reopenByName' => $reopenByInfo->firstname . " " . $reopenByInfo->lastname, 'userNames' => $userNames, 'taskName' => $taskInfo->taskname, 'seoUrl' => $taskInfo->seourl, 'templateName' => 'emails.todoReOpen'];

        dispatch((new SendRequestEmail($mailvar))->delay(10 * 1));

        if ($tcid > 0) {
            return "1";
        } else {
            return "0";
        }
    }


    private function completeTodoUserEmails($taskId)
    {
        $allUserEmails = array();
        $commentInfo = DB::table('comments')->where([['taskid', $taskId]])->orderBy('commentid', 'desc')->limit(1)->first();
        if ($commentInfo) {
            $projectInfo = DB::table('projects')->where([['projectid', $commentInfo->projectid]])->first();
            $notifiedIds = ($commentInfo->notifiedids != '' ? $commentInfo->notifiedids . "," . $projectInfo->created_by : $projectInfo->created_by);
            $notifiedIds = ($notifiedIds != '' ? explode(",", $notifiedIds) : '');
            $notifiedIds = array_unique($notifiedIds);
            if (!empty($notifiedIds)) {
                foreach ($notifiedIds as $notifiedId) {
                    $userInfo = DB::table('users')->where([['id', $notifiedId], ['isactive', 1]])->first();
                    if ($userInfo->id != Auth::user()->id) {
                        if (!in_array($userInfo->email, $allUserEmails)) {
                            $allUserEmails[] = $userInfo->email;
                        }
                    }
                }
            }
        }
        return $allUserEmails;
    }

    private function completeTodoUserName($taskId)
    {
        $userNames = '';
        $allUserNames = array();
        $commentInfo = DB::table('comments')->where([['taskid', $taskId]])->orderBy('commentid', 'desc')->limit(1)->first();
        if ($commentInfo) {
            $projectInfo = DB::table('projects')->where([['projectid', $commentInfo->projectid]])->first();
            $notifiedIds = ($commentInfo->notifiedids != '' ? $commentInfo->notifiedids . "," . $projectInfo->created_by : $projectInfo->created_by);

            $notifiedIds = ($notifiedIds != '' ? explode(",", $notifiedIds) : '');
            $notifiedIds = array_unique($notifiedIds);
            if (!empty($notifiedIds)) {
                foreach ($notifiedIds as $notifiedId) {
                    $userInfo = DB::table('users')->where([['id', $notifiedId], ['isactive', 1]])->first();
                    if ($userInfo->id != Auth::user()->id) {
                        if (!in_array($userInfo->firstname . " " . $userInfo->lastname, $allUserNames)) {
                            $allUserNames[] = $userInfo->firstname . " " . $userInfo->lastname;
                        }
                    }
                }
                $userNames = implode(", ", $allUserNames);
            }
        }
        return $userNames;
    }

    public function getTaskByLabelById($labelId = false, $userType = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $queryString = "";
        $label = DB::table('labels')->where([['labelid', $labelId]])->first();
        if ($label) {
            $inviteUsers = $this->invitedUser($label->projectid);
            $projectInfo = DB::table('projects')->where('projectid', $label->projectid)->first();
            $seoUrl = "project/" . $projectInfo->seoname . "/todolist/" . $label->seoname;

            $totalAll = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['deleted_at', null]])->count();
            $array = array(
                "labelid" => $label->labelid,
                "labelname" => $label->labelname,
                "projectid" => $label->projectid,
                "clientaccess" => $label->clientaccess,
                "created_at" => $this->general->converttimezoneFromUTCWTZ($label->created_at),
                "seourl" => $seoUrl,
                "todos" => $this->tasklist($label->projectid, $label->labelid, $inviteUsers, $userType),
                "totaltodos" => $totalAll,
            );
            $this->newdata[$this->i] = (object) $array;
            $this->i++;
        }
        return $this->newdata;
    }

    public function getTaskByProjectid($projectId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $queryString = "";
        $tasks = DB::table('tasks')->where([['projectid', $projectId],['mastertask', '0']])->get()->toArray();
        if (count($tasks) > 0) {
            foreach ($tasks as $task) {
                $array = array(
                    "taskid" => $task->taskid,
                    "taskname" => $task->taskname,
                );
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
            }
        }
        return $this->newdata;
    }


    public function getTaskByLabelByUid($projectId = false, $labelId = false, $userId = false, $taskDueDate = false, $userType = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $queryString = "";
        $label = DB::table('labels')->where([['labelid', $labelId]])->first();
        if ($label) {
            $inviteUsers = $this->invitedUser($label->projectid);
            $projectInfo = DB::table('projects')->where('projectid', $label->projectid)->first();
            $seoUrl = "project/" . $projectInfo->seoname . "/todolist/" . $label->seoname;

            $totalAll = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['deleted_at', null]])->count();
            $array = array(
                "labelid" => $label->labelid,
                "labelname" => $label->labelname,
                "projectid" => $label->projectid,
                "clientaccess" => $label->clientaccess,
                "created_at" => $this->general->converttimezoneFromUTCWTZ($label->created_at),
                "seourl" => $seoUrl,
                "todos" => $this->tasklistbyuid($projectId, $labelId, $inviteUsers, $userId, $taskDueDate, $userType),
                "totaltodos" => $totalAll,
            );
            $this->newdata[$this->i] = (object) $array;
            $this->i++;
        }
        return $this->newdata;
    }

    public function getTask($request, $projectId)
    {
        $notifiedIds = '';
        //DB::enableQueryLog();
        $task = DB::table('tasks')->where([['seoname', $request->todoseoname], ['projectid', $projectId]])->first();
       
        //print_r(DB::getQueryLog());
        if (!$task) {
            dd($task);
            return '';
        }
        $userinfo = DB::table('users')->where('id', $task->created_by)->first();
        $task->created_by = $userinfo->firstname . " " . $userinfo->lastname;
        $userdeletedinfo = DB::table('users')->where('id', $task->deleted_by)->first();
        $task->deleted_by = (isset($userdeletedinfo) ? $userdeletedinfo->firstname . " " . $userdeletedinfo->lastname : '');
        $task->seourl = $task->seourl;
        $task->assignedusername = $this->assignedUserName($task->taskid);
        $task->created_at = $this->general->converttimezoneFromUTCWTZ($task->created_at);
        $task->usernames = ($this->assignedUserName($task->taskid) == '' ? 'Unassigned' : $this->assignedUserName($task->taskid));
        //$notifiedids = DB::table('comments')->where('taskid', '=', $task->taskid)->orderBy('commentid','desc')->value('notifiedids');

        //Assign also includes in notify users 10-01-2018
        $assignIds = '';
        $assignUIdArr = DB::table('assigns')
            ->join('users', 'assigns.userid', '=', 'users.id')
            ->where([['assigns.taskid', $task->taskid], ['assigns.status', 0], ['users.isactive', 1], ['assigns.deleted_at', null]])
            ->pluck('assigns.userid')->toArray();
        $assignIds = (!empty($assignUIdArr) ? implode(",", $assignUIdArr) : '');
        /*$assigns = DB::table('assigns')->where([['taskid', $task->taskid],['status','0']])->get();
        if(count($assigns) > 0)
        {
        foreach($assigns as $assign)
        {
        $userInfo = DB::table('users')->where([['id', $assign->userid],['isactive',1]])->first();
        if(!empty($userInfo))
        {
        $allUserIds[] = $userInfo->id;
        }
        }
        $assignIds =  (!empty($allUserIds) ? implode(",",$allUserIds):'');
        }*/
        //end

        $commentInfo = DB::table('comments')->where('taskid', '=', $task->taskid)->orderBy('commentid', 'desc')->first();

        if ($commentInfo && $commentInfo->notifiedids != null) {
            if ($assignIds != '') {
                $notifiedIds = $commentInfo->notifiedids . "," . $commentInfo->created_by . "," . $assignIds;
            } else {
                $notifiedIds = $commentInfo->notifiedids . "," . $commentInfo->created_by;
            }
            $notifiedIds = ($notifiedIds != '' ? explode(",", $notifiedIds) : '');
        } else {
            if ($assignIds != '') {
                $notifiedIds = ($assignIds != '' ? explode(",", $assignIds) : '');
            }
        }

        //dd($notifiedIds);
        $notifiedNames = $this->notifyUserName($task->taskid);
        $task->notifiedids = ($notifiedIds != '' ? array_unique($notifiedIds) : array());
        $task->notifiednames = $notifiedNames;
        $task->loopnotifiedids = (isset($commentInfo->loopnotifiedids) ? $commentInfo->loopnotifiedids : '');

        $projectinfo = DB::table('projects')->where('projectid', $task->projectid)->first();
        if ($task->projectid != 0 && $task->labelid != 0) {
            $labelinfo = DB::table('labels')->where('labelid', $task->labelid)->first();
            $task->projectid = $projectinfo->projectid;
            $task->projectname = $projectinfo->projectname;
            $task->projecturl = $projectinfo->seourl;
            $task->archived = $projectinfo->archived;
            $task->timeentry = $projectinfo->timeentry;
            $task->labelname = $labelinfo->labelname;
            $task->labelurl = $labelinfo->seourl;

        } elseif ($task->projectid != 0 && $task->labelid == 0) {
            $task->projectid = $projectinfo->projectid;
            $task->projectname = $projectinfo->projectname;
            $task->projecturl = $projectinfo->seourl;
            $task->archived = $projectinfo->archived;
            $task->timeentry = $projectinfo->timeentry;
            $task->labelname = '';
            $task->labelurl = '';
        } else {
            $task->projectname = '';
            $task->projecturl = '';
            $task->labelname = '';
            $task->timeentry = 0;
            $task->labelurl = '';
        }
        return $task;
    }   

    public function getTaskById($taskId)
    {
        $task = DB::table('tasks')->where([['taskid', $taskId]])->first();
        if (!$task) {
            return '';
        }
        $userinfo = DB::table('users')->where('id', $task->created_by)->first();
        $task->created_by = $userinfo->firstname . " " . $userinfo->lastname;
        $task->seourl = $task->seourl;
        $task->assignedusername = $this->assignedUserName($task->taskid);
        $task->assignusers = $this->assigneUserEmails($task->taskid);
        $task->assignuseremails = ($task->assignuseremails != '' ? explode(",", $task->assignuseremails) : array());
        $task->created_at = $this->general->converttimezoneFromUTCWTZ($task->created_at);

        $assignIds = '';
        $assignUIdArr = DB::table('assigns')
            ->join('users', 'assigns.userid', '=', 'users.id')
            ->where([['assigns.taskid', $task->taskid], ['assigns.status', 0], ['users.isactive', 1], ['assigns.deleted_at', null]])
            ->pluck('assigns.userid')->toArray();
        $assignIds = (!empty($assignUIdArr) ? implode(",", $assignUIdArr) : '');
        

        $commentInfo = DB::table('comments')->where('taskid', '=', $task->taskid)->orderBy('commentid', 'desc')->first();

        if ($commentInfo && $commentInfo->notifiedids != null) {
            if ($assignIds != '') {
                $notifiedIds = $commentInfo->notifiedids . "," . $commentInfo->created_by . "," . $assignIds;
            } else {
                $notifiedIds = $commentInfo->notifiedids . "," . $commentInfo->created_by;
            }
            $notifiedIds = ($notifiedIds != '' ? explode(",", $notifiedIds) : '');
        } else {
            if ($assignIds != '') {
                $notifiedIds = ($assignIds != '' ? explode(",", $assignIds) : '');
            }
        }
        $notifiedNames = $this->notifyUserName($task->taskid);
        $task->notifiedids = (isset($notifiedIds) && $notifiedIds != '' ? array_unique($notifiedIds) : array());
        $task->notifiednames = $notifiedNames;
        $task->loopnotifiedids = (isset($commentInfo->loopnotifiedids) ? $commentInfo->loopnotifiedids : '');
        return $task;
    }

    public function editTask($request)
    {
        $seoName = '';
        $seoName = DB::table('tasks')->where('taskname', '=', trim($request->taskname))->value('seoname');
        $seoName = ($seoName != '' ? $this->general->seoName($seoName,'tasks','taskid') : $this->general->getSeoName(trim($request->taskname)));

        $taskInfo = DB::table('tasks')->where('taskid', '=', $request->taskid)->first();
        $projectInfo = DB::table('projects')->where('projectid', '=', $taskInfo->projectid)->first();
        if (isset($taskInfo->mastertask) && $taskInfo->mastertask == 1) {
            $projectid = $taskInfo->projectid;
            $labelid = $taskInfo->labelid;
            $repeateon = "";
            if (!empty($request->repeateon)) {
                $repeateon = implode(",", $request->repeateon);
            }
            $repeatsEvery = "";
            if ($request->repeatetype == 'D') {
                $repeatsEvery = $request->noofdays;
            } else if ($request->repeatetype == 'W') {
                $repeatsEvery = $request->noofweeks;
            } else if ($request->repeatetype == 'F') {
                $repeatsEvery = $request->nooffortnights;
            } else if ($request->repeatetype == 'M') {
                $repeatsEvery = $request->noofmonths;
            } else if ($request->repeatetype == 'Y') {
                $repeatsEvery = $request->noofyears;
            }

            $nooftimes = "";
            $endOnDate = "";
            $startOnDate = date("Y-m-d", strtotime($request->starton));
            if ($request->endafteron == 'O') {
                $endOnDate = date("Y-m-d", strtotime($request->endon));
                $totalDays = $this->get_time_difference($endOnDate, $startOnDate);
                $nooftimes = ($totalDays['days'] > 0 ? $totalDays['days'] : 5);
            } elseif ($request->endafteron == 'A') {
                $nooftimes = $request->endafter;
                if ($request->repeatetype == 'D') {
                    $endOnDate = date("Y-m-d", strtotime("+" . ($nooftimes * $repeatsEvery) . " days", strtotime($startOnDate)));
                } else if ($request->repeatetype == 'W') {
                    $endOnDate = date("Y-m-d", strtotime("+" . ($nooftimes * $repeatsEvery * 7) . " days", strtotime($startOnDate)));
                } else if ($request->repeatetype == 'F') {
                    $endOnDate = date("Y-m-d", strtotime("+" . ($nooftimes * $repeatsEvery * 14) . " days", strtotime($startOnDate)));
                } else if ($request->repeatetype == 'M') {
                    $endOnDate = date("Y-m-d", strtotime("+" . ($nooftimes * $repeatsEvery) . " months", strtotime($startOnDate)));
                } else if ($request->repeatetype == 'Y') {
                    $endOnDate = date("Y-m-d", strtotime("+" . ($nooftimes * $repeatsEvery) . " years", strtotime($startOnDate)));
                }
            }

            $assignUserArr = array();
            $assignUserIds = "";

            $assignUserEmailArr = array();
            $assignUserEmails = "";

            if (!empty($request->email)) {
                foreach ($request->email as $email) {
                    $userid = DB::table('users')->where('email', '=', $email)->value('id');
                    if ($userid) {
                        $assignUserArr[] = $userid;
                        $assignUserEmailArr[] = $email;
                    }
                }
                $assignUserIds = implode(",", $assignUserArr);
                $assignUserEmails = implode(",", $assignUserEmailArr);
            }
            $clientAccess = (isset($request->clientaccess) && $request->clientaccess != '' ? $request->clientaccess : 0);
            $dtid = DB::table('tasks')->where(['taskid' => $request->taskid])->update(["taskname" => trim($request->mastertaskname), "assignuseremails" => $assignUserEmails, "repeatetype" => $request->repeatetype, "nooftimes" => $nooftimes, "repeateon" => $repeateon, "dueondays" => $request->dueondays, "repeatsevery" => $repeatsEvery, "dueontime" => $request->dueontime, "executetime" => date("H:i:s", strtotime($request->executetime)), "endafteron" => $request->endafteron, "starton" => $startOnDate, "executeon" => $startOnDate, "endon" => $endOnDate, "summerytext" => $request->summerytext, "clientaccess" => $clientAccess, 'updated_at' => date("Y-m-d H:i:s")]);
            if ($dtid == 1) {
                return "2";
            }
        } else {

            $clientAccess = (isset($request->clientaccess) && $request->clientaccess != '' ? $request->clientaccess : ($taskInfo->clientaccess == 0 ? 0 : $taskInfo->clientaccess ));
            $dtid = DB::table('tasks')->where(['taskid' => $request->taskid])->update(["taskname" => trim($request->taskname), "seoname" => $seoName, "clientaccess" => $clientAccess, 'updated_at' => date("Y-m-d H:i:s"), "updated_by" => Auth::user()->id]);

            // add to project history
            $dataps = array("companyid" => $projectInfo->companyid, "projectid" => $taskInfo->projectid, "comment" => '', "oldprojectstatus" => $taskInfo->taskname, "newprojectstatus" => $request->taskname, "oldseoname" => $taskInfo->seoname, "newseoname" => $seoName, "action" => 'todoedit', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
            $phid = DB::table('projects_history')->insertGetId($dataps);
            //end
        }

        if ($dtid == 1) {
            return "2";
        } else {
            return "0";
        }
    }

    public function deleteTask($request)
    {
        $taskInfo = DB::table('tasks')->where('taskid', $request->taskid)->first();
        if ($taskInfo->mastertask == 1) {
            $dtid = DB::table('tasks')->where(['taskid' => $request->taskid])->update(['deleted_at' => date("Y-m-d H:i:s"), 'deleted_by' => Auth::user()->id]);
            if ($dtid == 1) {
                $deletes = DB::delete('delete from todo_repeatetasks where taskid =' . $request->taskid);
            }
            return $dtid;
        } else {
            $comments = DB::select("select commentid from todo_comments where taskid = " . $request->taskid . " order by commentid");
            $dtid = DB::table('tasks')->where(['taskid' => $request->taskid])->update(['deleted_at' => date("Y-m-d H:i:s"), 'deleted_by' => Auth::user()->id]);
            if ($comments) {
                $dcid = DB::table('comments')->where(['taskid' => $request->taskid])->update(['deleted_at' => date("Y-m-d H:i:s"), 'deleted_by' => Auth::user()->id]);
                foreach ($comments as $comment) {
                    $dfid = DB::table('files')->where(['commentid' => $comment->commentid])->update(['deleted_at' => date("Y-m-d H:i:s"), 'deleted_by' => Auth::user()->id]);
                }
            }
        }
        return $dtid;
    }

    public function getTaskDueDate($projectId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $projectInfo = DB::table('projects')->where('projectId', $projectId)->first();
        $inviteUsers = $this->invitedUser($projectId) . "," . $projectInfo->created_by . "," . Auth::user()->id;
        $tasks = DB::select("select distinct(taskenddate) from todo_tasks where projectid = " . $projectId . " and labelid != 0 and created_by in (" . $inviteUsers . ") order by taskenddate asc");
        if ($tasks) {
            foreach ($tasks as $task) {
                if ($task->taskenddate != null) {
                    $array = array(
                        "taskenddate" => $task->taskenddate,
                    );
                    $this->newdata[$this->i] = (object) $array;
                    $this->i++;
                }
            }
        }
        return $this->newdata;
    }

    private function tasklistbyuid($projectId, $labelId, $inviteUsers, $userId, $taskDueDate, $userType)
    {
        $this->j = 0;
        $this->newdata1 = array();
        $array1 = array();
        $query = "";
        if ($taskDueDate != 0) {
            $query = " and taskenddate  <= '" . $taskDueDate . "' ";
        }
        $queryString = "";
        if (in_array("3", $userType)) {
            $inviteid = DB::table('invites')->where([['userid', Auth::user()->id], ['projectid', $projectId], ['invitetype', 'C'], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
            if ($inviteid) {
                $queryString = " and clientaccess = 0";
            }
        }
        $label = DB::table('labels')->where([['labelid', $labelId], ['deleted_at', null]])->first();
        if ($label) {
            $projectInfo = DB::table('projects')->where('projectid', $projectId)->first();

            if ($taskDueDate == 0) {
                if ($userId == 0) {
                    $tasks = DB::select("select * from todo_tasks where completed = 0 and projectid = " . $label->projectid . " and labelid = " . $label->labelid . "  and repeatcompleted = 0  and created_by in (" . $inviteUsers . "," . $projectInfo->created_by . "," . Auth::user()->id . ") and deleted_at is NULL " . $queryString . " order by taskid desc");
                } else {
                    $tasks = DB::select("select * from todo_tasks where completed = 0 and projectid = " . $label->projectid . " and labelid = " . $label->labelid . " " . $queryString . "  and repeatcompleted = 0  and created_by in (" . $inviteUsers . "," . $projectInfo->created_by . "," . Auth::user()->id . ") and deleted_at is NULL and taskid in (select taskid from todo_assigns where todo_assigns.taskid = todo_tasks.taskid and userid = " . $userId . ")order by taskid desc");
                }
            } else {
                if ($userId == 0) {
                    $tasks = DB::select("select * from todo_tasks where completed = 0 and projectid = " . $label->projectid . " and labelid = " . $label->labelid . "  and repeatcompleted = 0  and created_by in (" . $inviteUsers . "," . $projectInfo->created_by . "," . Auth::user()->id . ") and deleted_at is NULL and taskenddate <= '" . $taskDueDate . "' " . $queryString . " order by taskid desc");
                } else {
                    $tasks = DB::select("select * from todo_tasks where completed = 0 and projectid = " . $label->projectid . " and labelid = " . $label->labelid . " " . $queryString . " and repeatcompleted = 0 and created_by in (" . $inviteUsers . "," . $projectInfo->created_by . "," . Auth::user()->id . ") and deleted_at is NULL  and taskenddate <= '" . $taskDueDate . "' and taskid in (select taskid from todo_assigns where todo_assigns.taskid = todo_tasks.taskid and userid = " . $userId . ")order by taskid desc");
                }
            }
            //$tasks = DB::select("select * from todo_tasks where completed = 0 and projectid = " . $projectId . " and labelid = " . $labelId . " " . $query . " " . $queryString . " and repeatcompleted = 0 and deleted_at is NULL  order by taskid desc");
            if ($tasks) {
                foreach ($tasks as $task) {
                    $seoUrl = "";
                    $projectInfo = DB::table('projects')->where('projectid', $task->projectid)->first();
                    $seoUrl = "/project/" . $projectInfo->seoname . "/todo/" . $task->seoname;
                    $totalComment = DB::table('comments')->where([['taskid', '=', $task->taskid], ['description', '!=', null], ['deleted_at', null]])->count();
                    $array1 = array(
                        "taskid" => $task->taskid,
                        "mastertask" => $task->mastertask,
                        "summerytext" => $task->summerytext,
                        "taskname" => $task->taskname,
                        "projectid" => $task->projectid,
                        "labelid" => $task->labelid,
                        "taskenddate" => ($task->taskenddate != null ? $this->general->converttimezoneFromUTCWTZ($task->taskenddate) : null),
                        "created_at" => $this->general->converttimezoneFromUTCWTZ($task->created_at),
                        "seourl" => $seoUrl,
                        "assignuseremails" => ($task->assignuseremails != '' ? explode(",", $task->assignuseremails) : array()),
                        "assignusernames" => $this->getAssignUserNames($task->taskid),
                        "repeatetype" => $task->repeatetype,
                        "nooftimes" => $task->nooftimes,
                        "repeateon" => explode(",", $task->repeateon),
                        "dueondays" => $task->dueondays,
                        "repeatsevery" => $task->repeatsevery,
                        "dueontime" => $task->dueontime,
                        "executetime" => $task->executetime,
                        "endafteron" => $task->endafteron,
                        "executeon" => (($task->executeon != '0000-00-00' ? date("M d,Y", strtotime($task->executeon)) : '')),
                        "starton" => (date("M d,Y", strtotime($task->starton))),
                        "endon" => ($task->endon != '0000-00-00' ? date("M d,Y", strtotime($task->endon)) : ''),
                        "clientaccess" => $task->clientaccess,
                        "created_by" => $task->created_by,
                        "totalcomment" => ($totalComment == 0 ? '0' : $totalComment),
                        "usernames" => ($this->assignedUserName($task->taskid) == '' ? 'Unassigned' : $this->assignedUserName($task->taskid)),
                        "assignusers" => $this->assigneUserEmails($task->taskid),
                        "total_time" => $this->totalTime($task->taskid),
                    );
                    $this->newdata1[$this->j] = (object) $array1;
                    $this->j++;
                }
            }
        }
        return $this->newdata1;
    }

    public function getLabelTaskListByUid($projectId = false, $userId = false, $taskDueDate = false, $userType = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $queryString = "";
        $projectInfo = DB::table('projects')->where('projectId', $projectId)->first();
        $inviteUsers = $this->invitedUser($projectId) . "," . $projectInfo->created_by . "," . Auth::user()->id;
        if (in_array("3", $userType)) {
            $inviteid = DB::table('invites')->where([['userid', Auth::user()->id], ['projectid', $projectId], ['invitetype', 'C'], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
            if ($inviteid) {
                $queryString = " and clientaccess = 0";
            }
        }
        $labels = DB::select("select * from todo_labels where projectid = " . $projectId . " and deleted_at is NULL " . $queryString . " order by labelid desc");
        if ($labels) {
            $totalComplated = 0;
            $totalNotComplated = 0;
            $totalAll = 0;
            $totaltodos = 0;
            foreach ($labels as $label) {
                $query = "";
                if ($userId != 0) {
                    $query = " and userid = " . $userId;
                }
                //DB::enableQueryLog();
                if ($taskDueDate == 0) {
                    $totalCount = DB::select("select count(*) as totalcount from todo_assigns where status = 0 " . $query . " and taskid in(select taskid from todo_tasks where projectid = " . $projectId . " and labelid = " . $label->labelid . " and deleted_at is NULL and completed = 0 order by labelid) ");
                } else {
                    $totalCount = DB::select("select count(*) as totalcount from todo_assigns where status = 0 " . $query . " and taskid in(select taskid from todo_tasks where projectid = " . $projectId . " and labelid = " . $label->labelid . " and deleted_at is NULL and taskenddate <= '" . $taskDueDate . "' and completed = 0 order by labelid) ");
                }
                //print_r(DB::getQueryLog());
                if ($totalCount[0]->totalcount > 0) {
                    $totalAll = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid]])->count();
                    $totalComplated = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['completed', 1]])->count();
                    $totalNotComplated = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid], ['completed', 0]])->count();
                    $totaltodos = $totaltodos + $totalAll;
                    if ($totalAll == $totalComplated && $totalComplated != 0 && $totalAll != 0 && $totalNotComplated == 0) {

                    } else if ($totalAll == 0 && $totalComplated == 0 && $totalNotComplated == 0) {
                        $array = array(
                            "labelid" => $label->labelid,
                            "labelname" => $label->labelname,
                            "projectid" => $label->projectid,
                            "clientaccess" => $label->clientaccess,
                            "created_at" => $this->general->converttimezoneFromUTCWTZ($label->created_at),
                            "seourl" => $label->seourl,
                            "todos" => $this->tasklistbyuid($projectId, $label->labelid, $inviteUsers, $userId, $taskDueDate, $userType),
                            "totaltodos" => $totaltodos,
                        );
                        $this->newdata[$this->i] = (object) $array;
                        $this->i++;
                    } else {
                        $array = array(
                            "labelid" => $label->labelid,
                            "labelname" => $label->labelname,
                            "projectid" => $label->projectid,
                            "clientaccess" => $label->clientaccess,
                            "created_at" => $this->general->converttimezoneFromUTCWTZ($label->created_at),
                            "seourl" => $label->seourl,
                            "todos" => $this->tasklistbyuid($projectId, $label->labelid, $inviteUsers, $userId, $taskDueDate, $userType),
                            "totaltodos" => $totaltodos,
                        );
                        $this->newdata[$this->i] = (object) $array;
                        $this->i++;
                    }
                }
            }
        }
        return $this->newdata;
    }

    public function getCompletedTaskByLabelId($labelId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $label = DB::table('labels')->where('labelid', $labelId)->first();

        $projectInfo = DB::table('projects')->where('projectid', $label->projectid)->first();

        $inviteUsers = $this->invitedUser($label->projectid);

        if ($label) {
            //DB::enableQueryLog();
            $tasks = DB::select("select * from todo_tasks where completed = 1 and projectid = " . $label->projectid . " and labelid = " . $label->labelid . " and created_by in (" . $inviteUsers . "," . $projectInfo->created_by . "," . Auth::user()->id . ") order by taskid desc");
            //print_r(DB::getQueryLog());
            foreach ($tasks as $task) {
                $taskseoUrl = "";
                $taskcompletedInfo = DB::table('tasks_completed')->where([['taskid', $task->taskid], ['status', 1]])->orderBy('taskcompletedid', 'desc')->first();
                $createdInfo = DB::table('users')->where('id', '=', $taskcompletedInfo->created_by)->first();
                $userArray = json_decode(json_encode($createdInfo), true);

                $tottask = (count($tasks) > 0 ? count($tasks) : 0);
                $totalComment = DB::table('comments')->where('taskid', '=', $task->taskid)->count();

                $taskseoUrl = "/project/" . $projectInfo->seoname . "/todo/" . $task->seoname;
                $array = array(
                    "taskid" => $task->taskid,
                    "taskname" => $task->taskname,
                    "projectid" => $task->projectid,
                    "labelid" => $task->labelid,
                    "taskenddate" => $this->general->converttimezoneFromUTCWTZ($taskcompletedInfo->created_at),
                    "created_at" => $this->general->converttimezoneFromUTCWTZ($task->created_at),
                    //"seourl"=>$task->seourl,
                    "seourl" => $taskseoUrl,
                    "totalcomment" => ($totalComment == 0 ? '0' : $totalComment),
                    "username" => $userArray['firstname'] . " " . $userArray['lastname'],
                );
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
            }
        }
        return $this->newdata;
    }

    public function assignTask($request)
    {
        $aid = 0;
        $removeUserEmails = array();
        $assignEmails = array();

        $duedate = (isset($request->assigndate) && $request->assigndate != '' ? date("Y-m-d", strtotime($request->assigndate)) : '0000-00-00');

        $assignUserEmails = ($request->assignusers != '' ? explode(",", $request->assignusers) : array());
        if (!empty($request->emailpop)) {
            if (!empty($assignUserEmails)) {
                foreach ($assignUserEmails as $newemail) {
                    if (!in_array($newemail, $request->emailpop)) {
                        $removeUserEmails[] = $newemail;
                    }
                }
            }
            foreach ($request->emailpop as $email) {
                //assign user
                $userid = DB::table('users')->where('email', '=', $email)->value('id');
                if ($userid) {
                    $assign = DB::table('assigns')->where([['userid', $userid], ['taskid', $request->taskid], ['status', '!=', 1]])->value('userid');
                    if ($assign == null) {
                        $data = array("taskid" => $request->taskid, "userid" => $userid, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_byassign);
                        $aid = DB::table('assigns')->insertGetId($data);
                        if ($aid > 0) {
                            $assignEmails[] = $email;
                        }
                    }
                }
            }
            if ($duedate != '0000-00-00') {
                $aid = DB::table('tasks')->where(['taskid' => $request->taskid])->update(['taskenddate' => $duedate]);
            }
            // send email to assign user
            if (!empty($assignEmails)) {
                $taskInfo = DB::table('tasks')->where('taskid', $request->taskid)->first();
                $createdByInfo = DB::table('users')->where('id', Auth::user()->id)->first();
                $allUserNames = array();
                $userNames = $this->assignedUserName($request->taskid);
                $projectInfo = DB::table('projects')->where('projectid', $taskInfo->projectid)->first();

                $mailvar = ['projectname' => $projectInfo->projectname, 'taskName' => $taskInfo->taskname, 'assignEmails' => $assignEmails, 'profilePic' => $createdByInfo->profilepic, 'createtByName' => $createdByInfo->firstname . " " . $createdByInfo->lastname, 'userNames' => $userNames, 'seoUrl' => $taskInfo->seourl, 'taskenddate' => $taskInfo->taskenddate, 'templateName' => 'emails.todoAssigned'];
                dispatch((new SendRequestEmail($mailvar))->delay(1 * 1));
            }
        }

        // send mail to remove users
        if (!empty($removeUserEmails)) {
            foreach ($removeUserEmails as $remail) {
                $rmuserid = DB::table('users')->where('email', $remail)->value('id');
                $assignid = DB::table('assigns')->where([['userid', $rmuserid], ['taskid', $request->taskid], ['status', 0]])->value('assignid');
                if ($assignid) {
                    $aid = DB::table('assigns')->where(['assignid' => $assignid])->update(['status' => 1], ['updated_at' => date("Y-m-d H:i:s")]);
                }
            }
            $taskInfo = DB::table('tasks')->where('taskid', $request->taskid)->first();
            $createdByInfo = DB::table('users')->where('id', Auth::user()->id)->first();
            $userNames = $this->assignedUserName($request->taskid);
            $projectInfo = DB::table('projects')->where('projectid', $taskInfo->projectid)->first();

            $mailvar = ['projectname' => $projectInfo->projectname, 'taskName' => $taskInfo->taskname, 'removeUserEmails' => $removeUserEmails, 'profilePic' => $createdByInfo->profilepic, 'createtByName' => $createdByInfo->firstname . " " . $createdByInfo->lastname, 'userNames' => $userNames, 'seoUrl' => $taskInfo->seourl, 'templateName' => 'emails.todoUnassigned'];

            dispatch((new SendRequestEmail($mailvar))->delay(1 * 1));
        }

        if ($aid > 0) {
            return "1";
        } else {
            return "0";
        }

    }

    public function addUserPackage(){
        $companyIdArr = DB::table('companies')->where([['deleted_at', null]])->pluck('companyid')->toArray();
        if (count($companyIdArr) > 0) {
            $statdate = date("Y-m-d H:i:s");
            $statdatetime = strtotime($statdate);
            $expdate = date("Y-m-d H:i:s", strtotime("+1 month", $statdatetime));
            foreach ($companyIdArr as $companyid) {
                $companyInfo = DB::table('companies')->where('companyid', $companyid)->first();
                $data = array("companyid" => $companyid, "userid" => $companyInfo->created_by, "packagetype" => 'f', "startdate" => $statdate, "expdate" => $expdate, "created_at" => date("Y-m-d H:i:s"), "created_by" => $companyInfo->created_by);
                $id = DB::table('userpackage')->insertGetId($data);
            }
        }
    }

    public function addCompanyProjectStatus(){
        $dprojectstatus = DB::select("select * from todo_default_projects_status where deleted_at is NULL order by dprojectstatusid");

        $companyIdArr = DB::table('companies')->where([['deleted_at', null]])->pluck('companyid')->toArray();
        if (count($companyIdArr) > 0) {
            foreach ($companyIdArr as $companyid) {
                foreach($dprojectstatus as $projectstatus) {
                    $data = array("companyid" => $companyid, "statusname" => $projectstatus->dstatusname, "timeentry" => $projectstatus->dtimeentry, "statuschangedays" => $projectstatus->dstatuschangedays, "ordering" => $projectstatus->dordering, "created_at" => date("Y-m-d H:i:s"), "created_by" => 1);
                    $id = DB::table('projects_status')->insertGetId($data);
                }
            }
        }
    }


    public function saveTask($request)
    {
        $seoName = '';

        $seoName = DB::table('tasks')->where('taskname', '=', trim($request->taskname))->value('seoname');

        $seoName = ($seoName != '' ? $this->general->seoName($seoName,'tasks','taskid') : $this->general->getSeoName(trim($request->taskname)));

        $projectid = (isset($request->projectid) ? $request->projectid : 0);
        $labelid = (isset($request->labelid) ? $request->labelid : 0);
        $taskenddate = (isset($request->taskenddate) && $request->taskenddate != '' ? date("Y-m-d", strtotime($request->taskenddate)) : null);

        $projectInfo = DB::table('projects')->where('projectid', '=', $projectid)->first();
        $labelSeoName = DB::table('labels')->where('labelid', '=', $labelid)->value('seoname');
        if (isset($projectInfo->seoname) && $projectInfo->seoname != '') {
            $seoUrl = ($labelSeoName != '' ? "project/" . $projectInfo->seoname . "/todo/" . $seoName : "project/" . $projectInfo->seoname . "/discussion/" . $seoName);
        } else {
            $seoUrl = "todo/" . $seoName;
        }

        $clientAccess = (isset($request->clientaccess) && $request->clientaccess != '' ? $request->clientaccess : 0);
        $data = array("taskname" => trim($request->taskname), "projectid" => $projectid, "seoname" => $seoName, "seourl" => $seoUrl, "labelid" => $labelid, "taskenddate" => $taskenddate, "clientaccess" => $clientAccess, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_bytask);
        $id = DB::table('tasks')->insertGetId($data);
        if ($id > 0) {
            $assignEmails = array();
            if (!empty($request->email)) {
                foreach ($request->email as $email) {
                    $userid = DB::table('users')->where('email', '=', $email)->value('id');
                    if ($userid) {
                        $assign = DB::table('assigns')->where([['userid', $userid], ['taskid', $id]])->value('userid');
                        if ($assign == 0) {
                            $data = array("taskid" => $id, "userid" => $userid, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_bytask);
                            $aid = DB::table('assigns')->insertGetId($data);
                            if ($aid > 0) {
                                $assignEmails[] = $email;
                            }
                        }
                    }
                }
                // send email to assigned users
                if (!empty($assignEmails)) {
                    $createdByInfo = DB::table('users')->where('id', $request->created_bytask)->first();

                    $userNames = $this->assignedUserName($id);

                    $mailvar = ['projectname' => $projectInfo->projectname, 'taskName' => $request->taskname, 'assignEmails' => $assignEmails, 'profilePic' => $createdByInfo->profilepic, 'createtByName' => $createdByInfo->firstname . " " . $createdByInfo->lastname, 'userNames' => $userNames, 'seoUrl' => $seoUrl, 'taskenddate' => $taskenddate, 'templateName' => 'emails.todoAssigned'];

                    dispatch((new SendRequestEmail($mailvar))->delay(1 * 1));
                }
            }
            return $id . "|" . $labelid . "|" . $projectInfo->projectid;
        } else {
            return "0";
        }
    }

    public function moveTodo($request)
    {
        $error = 0;
        $targetProjectInfo = DB::table('projects')->where('projectid', $request->moveprojectid)->first();
        if ($targetProjectInfo) {
            $targetLabelInfo = DB::table('labels')->where([['projectid', $request->moveprojectid], ['labelid', $request->movelabelid]])->first();
            if ($targetLabelInfo) {
                $moveTodoInfo = DB::table('tasks')->where('taskid', $request->movetaskid)->first();
                if ($moveTodoInfo) {
                    $todoSeoUrl = "project/" . $targetProjectInfo->seoname . "/todolist/" . $targetLabelInfo->seoname . "/todo/" . $moveTodoInfo->seoname;

                    $projectInfo = DB::table('projects')->where('projectid', $moveTodoInfo->projectid)->first();
                    $labelInfo = DB::table('labels')->where('labelid', $moveTodoInfo->labelid)->first();
                    $oldTodoSeoUrl = "project/" . $projectInfo->seoname . "/todolist/" . $labelInfo->seoname . "/todo/" . $moveTodoInfo->seoname;

                    $sendtodoSeoUrl = "<a id='movetodolink' href='" . url($todoSeoUrl) . "'>See it in its new location</a>";
                    $tid = DB::table('tasks')->where([['taskid', $request->movetaskid]])->update(["projectid" => $request->moveprojectid, "labelid" => $request->movelabelid, "seourl" => $todoSeoUrl, "updated_at" => date("Y-m-d H:i:s")]);
                    if ($tid) {
                        //update comments db
                        $comments = DB::table('comments')->where('projectid', $moveTodoInfo->projectid)->get()->toArray();
                        if (count($comments) > 0) {
                            foreach ($comments as $comment) {
                                $taskSeoName = DB::table('tasks')->where('taskid', $comment->taskid)->value('seoname');
                                if ($comment->labelid == 0) {
                                    $cid = DB::table('comments')->where([['commentid', $comment->commentid]])->update(["seourl" => "project/" . $targetProjectInfo->seoname . "/discussion" . "/" . $moveTodoInfo->seoname . "#" . $comment->commentid, "projectid" => $request->moveprojectid, "taskid" => $request->movetaskid]);
                                } else {
                                    $cid = DB::table('comments')->where([['commentid', $comment->commentid]])->update(["seourl" => "project/" . $targetProjectInfo->seoname . "/todolist" . "/" . $targetLabelInfo->seoname . "/todo" . "/" . $moveTodoInfo->seoname . "#" . $comment->commentid, "projectid" => $request->moveprojectid, "taskid" => $request->movetaskid, "labelid" => $request->movelabelid]);
                                }

                                //update files db
                                $files = DB::table('files')->where('commentid', $comment->commentid)->get()->toArray();
                                if (count($files) > 0) {
                                    $fid = DB::table('files')->where([['commentid', $comment->commentid]])->update(["foldername" => $targetProjectInfo->seoname, "projectid" => $request->moveprojectid]);
                                    foreach ($files as $file) {
                                        if (File::exists("public/img/comment_files/" . $projectInfo->seoname . "/" . $file->filenewname)) {
                                            File::move("public/img/comment_files/" . $projectInfo->seoname . "/" . $file->filenewname, "public/img/comment_files/" . $targetProjectInfo->seoname . "/" . $file->filenewname);
                                        }
                                        if (File::exists("public/img/comment_files/" . $projectInfo->seoname . "/list/" . $file->filenewname)) {
                                            File::move("public/img/comment_files/" . $projectInfo->seoname . "/list/" . $file->filenewname, "public/img/comment_files/" . $targetProjectInfo->seoname . "/list/" . $file->filenewname);
                                        }
                                        if (File::exists("public/img/comment_files/" . $projectInfo->seoname . "/thum/" . $file->filenewname)) {
                                            File::move("public/img/comment_files/" . $projectInfo->seoname . "/thum/" . $file->filenewname, "public/img/comment_files/" . $targetProjectInfo->seoname . "/thum/" . $file->filenewname);
                                        }
                                    }
                                }
                                //end
                            }
                            //update invite db

                            $allUserIdArr = DB::table('invites')->where([['projectid', $projectInfo->projectid], ['deleted_by', 0]])->pluck('userid')->toArray();

                            $targetInviteIdArr = DB::table('invites')->where('projectid', $targetProjectInfo->projectid)->pluck('userid')->toArray();
                            $oldInvites = DB::table('invites')->where('projectid', $projectInfo->projectid)->get()->toArray();
                            if (count($oldInvites) > 0) {
                                foreach ($oldInvites as $oldInvite) {
                                    if (!in_array($oldInvite->userid, $targetInviteIdArr)) {
                                        $inviteid = DB::table('invites')->where([['userid', $oldInvite->userid], ['projectid', $targetProjectInfo->projectid], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
                                        if (!isset($inviteid) && $inviteid == '') {
                                            $inviteolddata = array("projectid" => $targetProjectInfo->projectid, "userid" => $oldInvite->userid, "invitetype" => $oldInvite->invitetype, "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
                                            $icid = DB::table('invites')->insertGetId($inviteolddata);
                                        }
                                    }
                                }
                            }
                            //end

                            // add to project history
                            $dataps = array("companyid" => $targetProjectInfo->companyid, "projectid" => $moveTodoInfo->projectid, "comment" => $moveTodoInfo->taskname, "oldprojectstatus" => $moveTodoInfo->seoname, "newprojectstatus" => $targetProjectInfo->projectid, "oldseoname" => $moveTodoInfo->labelid, "newseoname" => $request->movelabelid, "action" => 'todomove', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
                            $phid = DB::table('projects_history')->insertGetId($dataps);
                            //end

                            //Send email to old invitee users
                            if (!empty($allUserIdArr)) {
                                $profilepic = Auth::user()->profilepic;
                                $todomovedby = Auth::user()->firstname . " " . Auth::user()->lastname;
                                $userNames = $this->getUserNames(implode(",", $allUserIdArr));

                                $mailSubject = "Todo move: " . $moveTodoInfo->taskname;
                                $newtodolisturl = "project/" . $targetProjectInfo->seoname . "/todolist/" . $targetLabelInfo->seoname;
                                $mailvar = ['profilepic' => $profilepic, 'todomovedby' => $todomovedby, 'taskName' => $moveTodoInfo->taskname, 'oldprojectname' => $projectInfo->projectname, 'oldtodolistname' => $labelInfo->labelname, 'newprojectname' => $targetProjectInfo->projectname, 'newprojecturl' => "project/" . $targetProjectInfo->seoname, 'newtodolistname' => $targetLabelInfo->labelname, 'newtodolisturl' => $newtodolisturl, 'notifyUserArray' => $allUserIdArr, 'userNames' => $userNames, 'seoUrl' => $todoSeoUrl, 'templateName' => 'emails.todoMove', 'mailSubject' => $mailSubject];
                                dispatch((new SendRequestEmail($mailvar))->delay(10 * 1));
                            }
                            //end
                            return "1|" . $sendtodoSeoUrl;
                        } else {
                            return $tid . "|" . $sendtodoSeoUrl;
                        }
                        //end
                    } else {
                        return $error;
                    }
                } else {
                    return $error;
                }
            } else {
                return $error;
            }
        } else {
            return $error;
        }
        return $error;
    }

    private function getUserNames($notifyUserIds)
    {
        $userNames = '';
        $allUserNames = array();
        $notifyUsers = DB::select("select firstname, lastname from todo_users where id in( " . $notifyUserIds . " ) and isactive = 1");
        if (count($notifyUsers) > 0) {
            foreach ($notifyUsers as $notifyUser) {
                $allUserNames[] = $notifyUser->firstname . " " . $notifyUser->lastname;
            }
            $userNames = (!empty($allUserNames) ? implode(", ", $allUserNames) : '');
        }
        return $userNames;
    }

    public function getInviteUsers($projectId)
    {
        $this->l = 0;
        $this->newdata3 = array();
        $array = array();
        $userIdArr = DB::table('invites')->where([['projectid', $projectId], ['deleted_at', '0000-00-00 00:00:00']])->pluck('userid')->toArray();
        if (count($userIdArr) > 0) {
            foreach ($userIdArr as $userid) {
                $userInfo = DB::table('users')->where('id', $userid)->first();
                if ($userInfo->id != Auth::user()->id) {
                    $array = array(
                        "inviteuserid" => $userid,
                        "inviteemail" => $userInfo->email,
                        "username" => $userInfo->firstname . " " . $userInfo->lastname,
                    );
                    $this->newdata3[$this->l] = (object) $array;
                    $this->l++;
                }
            }
        }
        return $this->newdata3;
    }

    public function getLabelByProjId($projectId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $labels = DB::select("select labelid, labelname from todo_labels where projectid = " . $projectId . " and deleted_by = 0 order by labelname asc");
        if (count($labels) > 0) {
            foreach ($labels as $label) {
                $array = array(
                    "labelid" => $label->labelid,
                    "labelname" => $label->labelname,
                );
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
            }
        }
        return $this->newdata;
    }

    private function commentlist($taskId)
    {
        $this->k = 0;
        $this->newdata2 = array();
        $array2 = array();
        $comments = DB::select("select * from todo_comments where taskid = " . $taskId . " and working_time !='00:00:00' and deleted_by = 0 order by commentid desc");
        if (count($comments) > 0) {
            foreach ($comments as $comment) {
                $createdInfo = DB::table('users')->where('id', '=', $comment->created_by)->first();
                $userArray = json_decode(json_encode($createdInfo), true);
                $array2 = array(
                    "commentid" => $comment->commentid,
                    "description" => $comment->description,
                    "projectid" => $comment->projectid,
                    "labelid" => $comment->labelid,
                    "taskid" => $comment->taskid,
                    "created_at" => $this->general->converttimezoneFromUTCWTZ($comment->created_at),
                    "working_time" => $comment->working_time,
                    "username" => $userArray['firstname'] . " " . $userArray['lastname'],
                );
                $this->newdata2[$this->k] = (object) $array2;
                $this->k++;
            }
        }
        return $this->newdata2;
    }

    private function tasklisting($projectId, $labelId, $inviteUsers)
    {
        $count = 0;
        $this->j = 0;
        $this->newdata1 = array();
        $array1 = array();
        //DB::enableQueryLog();
        $tasks = DB::select("select * from todo_tasks where projectid = " . $projectId . " and labelid = " . $labelId . " order by taskid desc");
        //print_r(DB::getQueryLog());
        if (count($tasks) > 0) {
            foreach ($tasks as $task) {
                $count = 0;
                //$count = DB::table('comments')->where([['taskid', '=', $task->taskid], ['description', '!=', null]])->count();
                $count = DB::table('comments')->where([['taskid', '=', $task->taskid], ['description', '!=', null],['deleted_by', 0]])->count();
                if ($count != 0) {
                    $totalTodoListTime = '00:00:00';
                    $totalTodoListTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS timeSum FROM todo_comments where deleted_by = 0 and taskid = " . $task->taskid);
                    $taskenddate = $task->taskenddate != null ? $task->taskenddate : null;
                    if (strlen($totalTodoListTime[0]->timeSum) > 0) {
                        $array1 = array(
                            "taskid" => $task->taskid,
                            "taskname" => $task->taskname,
                            "projectid" => $task->projectid,
                            "labelid" => $task->labelid,
                            "taskenddate" => ($taskenddate != null ? $this->general->converttimezoneFromUTCWTZ($taskenddate) : null),
                            "created_at" => $this->general->converttimezoneFromUTCWTZ($task->created_at),
                            "seourl" => $task->seourl,
                            "comments" => $this->commentlist($task->taskid),
                            "totaltdltime" => $totalTodoListTime[0]->timeSum,
                        );
                        $this->newdata1[$this->j] = (object) $array1;
                        $this->j++;
                    }
                }
            }
        }
        return $this->newdata1;
    }

    public function getCommentTaskByLabelId($projectId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $inviteUsers = $this->invitedUser($projectId);
        $labels = DB::select("select * from todo_labels where projectid = " . $projectId . " and deleted_by = 0 order by labelid desc");
        if (count($labels) > 0) {
            foreach ($labels as $label) {
                $countLabel = 0;
                $countLabel = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid],['deleted_by', 0]])->count();
                if ($countLabel != 0 ) {

                    $comments = DB::select("select * from todo_comments where projectid = " . $projectId . " and labelid in ( select labelid from todo_tasks where projectid = " . $projectId . " and labelid = ".$label->labelid." and deleted_by = 0 and taskid in(select taskid  from todo_comments where projectid = " . $projectId . " and labelid = ".$label->labelid." and deleted_by = 0 ) ) and deleted_by = 0 order by labelid desc");
                    if(count($comments) > 0){
                        $totalTime = DB::table('comments')
                        ->where([['projectid', $label->projectid], ['labelid', $label->labelid],['deleted_by', 0]])
                        ->selectRaw('SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) as timetdlSum')
                        ->first();
                        //$totalTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS timetdlSum FROM todo_comments where  projectid = " . $label->projectid . " and labelid = " . $label->labelid);
                        if(isset($totalTime)){
                            $array = array(
                                "labelid" => $label->labelid,
                                "labelname" => $label->labelname,
                                "projectid" => $label->projectid,
                                "seoname" => $label->seoname,
                                "seourl" => $label->seourl,
                                "tasks" => $this->tasklisting($projectId, $label->labelid, $inviteUsers),
                                "totaltime" => $totalTime->timetdlSum,
                            );
                            $this->newdata[$this->i] = (object) $array;
                            $this->i++;
                        }
                    }
                }
                unset($totalTime);
            }
        }
        return $this->newdata;
    }

    private function commentlistbyrange($taskId = false, $startdate = false, $enddate = false, $inviteuserid = false)
    {
        $this->k = 0;
        $this->newdata2 = array();
        $array2 = array();
        $queryString = ($inviteuserid != 0 ? " and created_by = " . $inviteuserid : "");
        if ($startdate == 0 && $enddate == 0) {
            $comments = DB::select("select * from todo_comments where taskid = " . $taskId . " and working_time != '00:00:00' " . $queryString . " order by commentid desc");
        } else {
            $comments = DB::select("select * from todo_comments where taskid = " . $taskId . " and created_at between '" . $startdate . "' and '" . $enddate . "' and working_time != '00:00:00' " . $queryString . " order by commentid desc");
        }
        if (count($comments) > 0) {
            foreach ($comments as $comment) {
                $createdInfo = DB::table('users')->where('id', '=', $comment->created_by)->first();
                $userArray = json_decode(json_encode($createdInfo), true);
                $array2 = array(
                    "commentid" => $comment->commentid,
                    "description" => $comment->description,
                    "projectid" => $comment->projectid,
                    "labelid" => $comment->labelid,
                    "taskid" => $comment->taskid,
                    "created_at" => $this->general->converttimezoneFromUTCWTZ($comment->created_at),
                    "working_time" => $comment->working_time,
                    "username" => $userArray['firstname'] . " " . $userArray['lastname'],
                );
                $this->newdata2[$this->k] = (object) $array2;
                $this->k++;
            }
        }
        return $this->newdata2;
    }

    private function tasklistingbyrange($projectId, $labelId, $inviteUsers, $startdate, $enddate, $inviteuserid)
    {
        $count = 0;
        $this->j = 0;
        $this->newdata1 = array();
        $array1 = array();
        $queryString = ($inviteuserid != 0 ? " and created_by = " . $inviteuserid : "");
        $tasks = DB::select("select * from todo_tasks where projectid = " . $projectId . " and labelid = " . $labelId . " order by taskid desc");
        //$tasks = DB::select("select * from todo_tasks where projectid = ".$projectId." and labelid = ".$labelId." and created_by in (".$inviteUsers.") order by taskid desc");
        if (count($tasks) > 0) {
            foreach ($tasks as $task) {
                $count = 0;
                $count = DB::table('comments')->where([['taskid', $task->taskid]])->count();
                if ($count != 0) {
                    $totalTodoListTime = '00:00:00';
                    if ($startdate == 0 && $enddate == 0) {
                        $totalTodoListTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS timeSum FROM todo_comments where taskid = " . $task->taskid . " " . $queryString);
                    } else {
                        $totalTodoListTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS timeSum FROM todo_comments where taskid = " . $task->taskid . " and created_at >= '" . $startdate . "' and created_at <='" . $enddate . "' " . $queryString . "");
                    }
                    $taskenddate = $task->taskenddate != null ? $task->taskenddate : null;
                    if ($totalTodoListTime[0]->timeSum != null) {
                        $array1 = array(
                            "taskid" => $task->taskid,
                            "taskname" => $task->taskname,
                            "projectid" => $task->projectid,
                            "labelid" => $task->labelid,
                            "taskenddate" => ($task->taskenddate != null ? $this->general->converttimezoneFromUTCWTZ($task->taskenddate) : null),
                            "created_at" => $this->general->converttimezoneFromUTCWTZ($task->created_at),
                            "seourl" => $task->seourl,
                            "comments" => $this->commentlistbyrange($task->taskid, $startdate, $enddate, $inviteuserid),
                            "totaltdltime" => $totalTodoListTime[0]->timeSum,
                        );
                        $this->newdata1[$this->j] = (object) $array1;
                        $this->j++;
                    }
                }
            }
        }
        return $this->newdata1;
    }

    public function getCommentTaskByRange($projectId = false, $startdate = false, $enddate = false, $inviteuserid = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $inviteUsers = $this->invitedUser($projectId);
        $queryString = ($inviteuserid != 0 ? " and created_by = " . $inviteuserid : "");
        $labels = DB::select("select * from todo_labels where projectid = " . $projectId . " order by labelid desc");
        if (count($labels) > 0) {
            foreach ($labels as $label) {
                $countLabel = 0;
                $countLabel = DB::table('tasks')->where([['projectid', $label->projectid], ['labelid', $label->labelid]])->count();
                if ($countLabel != 0) {
                    if ($startdate == 0 && $enddate == 0) {
                        $totalTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS timetdlSum FROM todo_comments where projectid = " . $label->projectid . " and labelid = " . $label->labelid . " " . $queryString);
                    } else {
                        $totalTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS timetdlSum FROM todo_comments where projectid = " . $label->projectid . " and labelid = " . $label->labelid . " and created_at between '" . $startdate . "' and '" . $enddate . "' " . $queryString . "");
                    }
                    if ($totalTime[0]->timetdlSum != '00:00:00' && $totalTime[0]->timetdlSum != '') {
                        $array = array(
                            "labelid" => $label->labelid,
                            "labelname" => $label->labelname,
                            "projectid" => $label->projectid,
                            "seoname" => $label->seoname,
                            "seourl" => $label->seourl,
                            "tasks" => $this->tasklistingbyrange($label->projectid, $label->labelid, $inviteUsers, $startdate, $enddate, $inviteuserid),
                            "totaltime" => $totalTime[0]->timetdlSum,
                        );
                        $this->newdata[$this->i] = (object) $array;
                        $this->i++;
                    }
                }
            }
        }
        return $this->newdata;
    }

    public function getTotalTimeEntryByRange($projectId = false, $startdate = false, $enddate = false, $inviteuserid = false)
    {
        $queryString = ($inviteuserid != 0 ? " and created_by = " . $inviteuserid : "");
        if ($startdate == 0 && $enddate == 0) {
            $total = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS totalSum FROM todo_comments where projectid = " . $projectId . " " . $queryString . " ");
        } else {
            $total = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS totalSum FROM todo_comments where projectid = " . $projectId . " and created_at >= '" . $startdate . "' and created_at <= '" . $enddate . "' " . $queryString . "");
        }
        return substr($total[0]->totalSum, 0, 5);
    }

    public function getInviteNotifyUsers($taskid = false, $projectId = false)
    {
        $this->l = 0;
        $this->newdata3 = array();
        $array = array();
        $inviteuids = '';
        $assignuids = '';
        $alluserids = '';
        $UId = (isset(Auth::user()->id) ? Auth::user()->id : Session::get('invitedNotRegUserId'));
        //DB::enableQueryLog();
        $userIdArr = DB::table('invites')->where([['projectid', $projectId], ['deleted_at', '0000-00-00 00:00:00']])->pluck('userid')->toArray();
        $inviteuids = (!empty($userIdArr) ? implode(",", $userIdArr) : '');
        //print_r(DB::getQueryLog());

        $assignUIdArr = DB::table('assigns')
            ->join('users', 'assigns.userid', '=', 'users.id')
            ->where([['assigns.taskid', $taskid], ['assigns.status', 0], ['users.isactive', 1], ['assigns.deleted_at', null]])
            ->pluck('assigns.userid')->toArray();
        $assignuids = (!empty($assignUIdArr) ? implode(",", $assignUIdArr) : '');

        if ($assignuids != '') {
            $alluserids = $inviteuids . "," . $assignuids;
        } else {
            $alluserids = $inviteuids;
        }
        if ($alluserids != '') {
            $alluserIdArr = explode(",", $alluserids);
            $alluserIdArrUnique = array_unique($alluserIdArr);
            foreach ($alluserIdArrUnique as $invite) {
                if ($invite != '') {
                    $userInfo = DB::table('users')->where([['id', $invite],['loopinuser','0']])->first();
                    if (isset($userInfo) && $userInfo->id != $UId) {
                        if ($userInfo->projectnotification == 'S' && $userInfo->notifiedprojects != '') {
                            if (in_array($projectId, explode(",", $userInfo->notifiedprojects))) {
                                $array = array(
                                    "inviteuserid" => $userInfo->id,
                                    "inviteemail" => $userInfo->email,
                                    "username" => $userInfo->firstname . " " . $userInfo->lastname,
                                );
                                $this->newdata3[$this->l] = (object) $array;
                                $this->l++;
                            }
                        } else if ($userInfo->projectnotification == 'A') {
                            $array = array(
                                "inviteuserid" => $userInfo->id,
                                "inviteemail" => $userInfo->email,
                                "username" => $userInfo->firstname . " " . $userInfo->lastname,
                            );
                            $this->newdata3[$this->l] = (object) $array;
                            $this->l++;
                        }
                    }
                }
            }
        }
        return $this->newdata3;
    }

    public function getStoppedTimeEntry($taskId)
    {
        $UId = (isset(Auth::user()->id) ? Auth::user()->id : Session::get('invitedNotRegUserId'));
        $totaltime = DB::table('timeentries')->orderBy('timeentryid', 'Desc')->limit(1)->where([['created_by', $UId], ['taskid', $taskId], ['status', 3]])->value('total_time');
        return $totaltime;
    }

    public function getProjectsUpdatesByUserId($userId = false, $companyId = false, $limitQuery = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();

        $projectIds = $this->getProjectIds($companyId, $userId);
        //DB::enableQueryLog();
        $comments = DB::select("select max(commentid) commentid, taskid, projectid, labelid, max(created_at) created_at, created_by from todo_comments where created_by = " . $userId . " and companyid = " . $companyId . " and projectid in(" . $projectIds . ") group by taskid order by commentid desc " . $limitQuery);
        //print_r(DB::getQueryLog());
        if (count($comments) > 0) {
            foreach ($comments as $comment) {
                $seoUrl = "";
                $projectInfo = DB::table('projects')->where('projectid', $comment->projectid)->first();
                $projectArray = json_decode(json_encode($projectInfo), true);

                $taskInfo = DB::table('tasks')->where('taskid', $comment->taskid)->first();
                $taskArray = json_decode(json_encode($taskInfo), true);

                $createdInfo = DB::table('users')->where('id', '=', $comment->created_by)->first();
                $userArray = json_decode(json_encode($createdInfo), true);

                $seoUrl = "/project/" . $projectArray['seoname'] . "/todo/" . $taskArray['seoname'] . "#" . $comment->commentid;
                $array = array(
                    "taskname" => $taskArray['taskname'],
                    "commentby" => $userArray['firstname'],
                    "projectname" => $projectArray['projectname'],
                    "projectseourl" => $projectArray['seourl'],
                    "created_at" => $this->general->converttimezoneFromUTCWTZ($comment->created_at),
                    "seourl" => $seoUrl,
                );
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
            }
        }
        return $this->newdata;
    }

    public function getCompletedTodos($projectId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $projectInfo = DB::table('projects')->where('projectid', $projectId)->first();
        $inviteUsers = $this->invitedUser($projectId);
        //DB::enableQueryLog();
        $tasks = DB::select("select distinct (taskid), created_at, taskcompletedid from todo_tasks_completed where status = 1 and created_by in (" . $inviteUsers . "," . $projectInfo->created_by . "," . Auth::user()->id . ") group by created_at order by created_at desc");
        //print_r(DB::getQueryLog());
        $j = 1;
        $prevCompletedDate = '';
        $prevTodolistName = '';
        foreach ($tasks as $index=>$task) {
            $taskseoUrl = "";
            $nextCompletedDate = '';
            $labelArray = array();
            $userArray = array();

            if( isset($tasks[$index+1]->taskid) && array_key_exists($index + 1, $tasks )) {
                $nextCompletedDate = $this->general->converttimezoneFromUTCWTZ($tasks[$index+1]->created_at);
            } 
            $taskInfo = DB::table('tasks')->where('taskid', '=', $task->taskid)->first();

            if ($taskInfo->projectid == $projectId) {
                $labelArray = array();
                $taskcompletedInfo = DB::table('tasks_completed')->where('taskcompletedid', '=', $task->taskcompletedid)->first();

                $createdInfo = DB::table('users')->where('id', '=', $taskcompletedInfo->created_by)->first();
                $userArray = json_decode(json_encode($createdInfo), true);

                $labelInfo = DB::table('labels')->where('labelid', '=', $taskInfo->labelid)->first();
                $labelArray = json_decode(json_encode($labelInfo), true);

                $projectInfo = DB::table('projects')->where('projectid', $taskInfo->projectid)->first();
                $taskseoUrl = "/project/" . $projectInfo->seoname . "/todo/" . $taskInfo->seoname;
                $array = array(
                    "taskid" => $taskInfo->taskid,
                    "taskname" => $taskInfo->taskname,
                    "projectid" => $taskInfo->projectid,
                    "labelid" => $taskInfo->labelid,
                    "nextCompletedDate" => $nextCompletedDate,
                    "labelname" => $labelArray['labelname'],
                    "labelseourl" => $labelArray['seourl'],
                    "taskenddate" => $this->general->converttimezoneFromUTCWTZ($taskInfo->taskenddate),
                    "created_at" => $this->general->converttimezoneFromUTCWTZ($taskInfo->created_at),
                    "seourl" => $taskseoUrl,
                    "completed_at" => $this->general->converttimezoneFromUTCWTZ($task->created_at),
                    "name" => $userArray['firstname'] . " " . $userArray['lastname'],
                    "first" => ($j == 1 ? 1 : 0),
                    "last" => (count($tasks) == $j ? 1 : 0),
                    
                    "prevTodolistName" => ($prevTodolistName != $labelArray['labelname'] ? '' : $labelArray['labelname']),
                    "prevCompletedDate" => ($prevCompletedDate != date("Y-m-d", strtotime($this->general->converttimezoneFromUTCWTZ($task->created_at))) ? '' : date("Y-m-d", strtotime($this->general->converttimezoneFromUTCWTZ($task->created_at)))),
                );
                $j++;
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
                $prevTodolistName = $labelArray['labelname'];
                $prevCompletedDate = date("Y-m-d", strtotime($this->general->converttimezoneFromUTCWTZ($task->created_at)));
            }
        }
        return $this->newdata;
    }

    private function getProjectIds($companyId = false, $userId = false)
    {
        if ($userId == false) {
            $projects = DB::select("select projectid from todo_projects where archived = 0 and deleted_at is NULL and companyid=" . $companyId);
        } else {
            $projects = DB::select("select tp.projectid from todo_projects tp, todo_invites ti where tp.archived = 0 and tp.deleted_at is NULL and tp.companyid=" . $companyId . " and tp.projectid = ti.projectid and ti.userid = " . $userId . " and ti.deleted_at = '0000-00-00 00:00:00' ");
        }
        $projectIds = '0';
        if ($projects) {
            foreach ($projects as $project) {
                $allProjectIdArr[] = $project->projectid;
            }
            $projectIds = (!empty($allProjectIdArr) ? implode(",", $allProjectIdArr) : '');
        }
        return $projectIds;
    }
}
