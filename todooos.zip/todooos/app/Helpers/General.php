<?php
    namespace App\Helpers;
    use DB;
    use Auth;
    use \App\Library\Simpleimage;
    use Timezone;
    class General
    {
        /**
         * @param string  $seoName Name-String
         * @param string  $tableName Database Table Name
         * @param integer $orderBy Database Table Order by column
         * 
         * @return string
         */

        public static function seoName($seoName, $tableName,$orderBy) {

            $dbseoName = DB::table($tableName)->orderBy($orderBy, 'Desc')->limit(1)->where('seoname', 'like', $seoName . "%")->value('seoname');
            
            if($dbseoName != ''){
                $newdbseoName = explode("-", $dbseoName);
                if (is_array($newdbseoName)) {
                    $cnt = sizeof($newdbseoName);
                    $lastval = $newdbseoName[$cnt - 1];
                    if (is_numeric($lastval)) {
                        $newval = (int) $lastval + 1;
                        $seoName = $seoName . "-" . $newval;
                    } else {
                        $seoName = $seoName . "-1";
                    }
                } else {
                    $seoName = $seoName . "-1";
                }
            }
            return strtolower($seoName);
        }

        /**
         * @param string  $string Name-String
         * @return string
         */
        public static function getSeoName($string){
            //Lower case everything
            $string = strtolower($string);
            //Make alphanumeric (removes all other characters)
            $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
            //Clean up multiple dashes or whitespaces
            $string = preg_replace("/[\s-]+/", " ", $string);
            //Convert whitespaces and underscore to dash
            $string = preg_replace("/[\s_]/", "-", $string);
            return $string;
        }


        public function saveImage($imageName = false, $folder = false, $userId = false, $imageSize = false)
        {
            if ($imageName != '' && $folder != '') {
                $this->simpleimage = new Simpleimage;
                $array = explode(".",$imageName);
                $ext = end($array);
                $newImageName = $userId.".".$ext;

                if ($this->simpleimage->load('public/img/temp/' . $imageName)->get_width() >= $imageSize['width'] && $this->simpleimage->load('public/img/temp/' . $imageName)->get_height() >= $imageSize['height']) {
                    $this->imageResize('public/img/temp/' . $imageName, $newImageName, $folder, $imageSize);
                    rename('public/img/temp/' . $imageName, 'public/img/' . $folder . '/' . $newImageName);
                } else {
                    return 'size';
                }
                if (file_exists("public/img/temp/" . $imageName)) {
                    unlink("public/img/temp/" . $imageName);
                }
                if (file_exists("public/img/temp/thumbnail/" . $imageName)) {
                    unlink("public/img/temp/thumbnail/" . $imageName);
                }
                return $newImageName;
            }
        }

        private function imageResize($imageWithPath = false, $newimageName = false, $uploadFolder = false, $imageSize = false)
        {
            if ($imageWithPath && $uploadFolder) {
                $resizeArray = array(
                    'Thum' => array('width' => $imageSize['width'], 'height' => $imageSize['height'], 'folder' => 'thum'),
                );
                foreach ($resizeArray as $type => $configuration) {
                    if ($type == 'Thum') {
                        $this->simpleimage->load($imageWithPath);
                        $this->simpleimage->thumbnail($configuration['width'], $configuration['height'])->resize($configuration['width'], $configuration['height'])->save('public/img/' . $uploadFolder . '/' . $configuration['folder'] . '/' . $newimageName);
                    }
                }
            }
        }

        public function converttimezoneFromUTC($timestamp,$timezone)
        {
            if (isset($timezone) && $timezone != '') {
                return Timezone::convertFromUTC($timestamp, $timezone);
            } else {
                return Timezone::convertFromUTC($timestamp, date_default_timezone_get());
            }
        }

        public function converttimezoneFromUTCWTZ($timestamp)
        {
            $UId = (isset(Auth::user()->id) ? Auth::user()->id : Session::has('invitedNotRegUserId'));
            if (isset(Auth::user()->timezone) && Auth::user()->timezone != '') {
                return Timezone::convertFromUTC($timestamp, Auth::user()->timezone);
            } else {
                return Timezone::convertFromUTC($timestamp, date_default_timezone_get());
            }
        }

        public function get_time_difference($start, $end)
        {
            $uts['start'] = strtotime($start);
            $uts['end'] = strtotime($end);
            if ($uts['start'] >= $uts['end']) {
                $uts['start'] = $uts['end'];
            }
            if ($uts['start'] !== -1 && $uts['end'] !== -1) {
                if ($uts['end'] >= $uts['start']) {
                    $diff = $uts['end'] - $uts['start'];
                    if ($days = intval((floor($diff / 86400)))) {
                        $diff = $diff % 86400;
                    }

                    if ($hours = intval((floor($diff / 3600)))) {
                        $diff = $diff % 3600;
                    }

                    if ($minutes = intval((floor($diff / 60)))) {
                        $diff = $diff % 60;
                    }

                    $diff = intval($diff);
                    return (array('days' => $days, 'hours' => $hours, 'minutes' => $minutes, 'seconds' => $diff));
                } else {
                    trigger_error("Ending date/time is earlier than the start date/time", E_USER_WARNING);
                }
            } else {
                trigger_error("Invalid date/time data detected", E_USER_WARNING);
            }
            return (false);
        }

        public function saveAudittrial($request)
        {
            $dataAuditArr = array("entitytypeid"=>$request['entitytypeid'], "entityid"=>$request['entityid'], "action"=>$request['action'], "description"=>$request['description'], "created_at"=>date("Y-m-d H:i:s"), "created_by"=>$request['created_by']);
            $atid = DB::table('audittrial')->insertGetId($dataAuditArr);
        }
        
        public function mimeType($path)
        {
            return finfo_file(finfo_open(FILEINFO_MIME_TYPE), $path);
        }


    }