<?php

namespace App;
use Auth;
use DB;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use General;
class User extends Authenticatable
{
    use Notifiable;

    protected $primaryKey = 'id';
    protected $guarded = array();
    protected $table = 'users';
    protected $tableWithPrefix = 'todo_users';
    protected $i = 0;
    protected $newdata = array();

    protected $l = 0;
    protected $newdata3 = array();

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['username', 'firstname', 'lastname', 'usertype', 'email', 'password', 'mobile', 'zipcode', 'profilepic', 'last_login', 'timezone', 'projectnotification', 'notifiedprojects', 'createproject', 'dailyrecap', 'needtakecare', 'completetodo', 'isactive', 'eachitemrightaway', 'summaryeveryfewhours', 'listingtype', 'leftpaneltype', 'created_at', 'updated_at', 'created_by'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['password', 'remember_token'];

    public function getUserByCode($confirmationCode = false)
    {
        if ($confirmationCode) {
            $newconfirmationCode = explode("|", base64_decode($confirmationCode));
            if (is_array($newconfirmationCode) && count($newconfirmationCode) < 2) {
                return "2";
            }
            $user = DB::table('users')->where('id', $newconfirmationCode[1])->first();
            if (isset($user->email) && $user->email != '' && $user->isactive == 0) {
                User::where(['id' => $user->id])->update(['confirmation_code' => '', 'isactive' => 1]);
                return "1";
            } else {
                return '2';
            }
        }
        return "0";
    }

    public function getUserConfirmByCode($confirmationCode = false)
    {
        if ($confirmationCode) {
            $newconfirmationCode = explode("|", base64_decode($confirmationCode));
            if (is_array($newconfirmationCode) && count($newconfirmationCode) < 2) {
                return "2";
            }
            $userInfo = DB::table('users')->where('id', $newconfirmationCode[1])->first();
            if (isset($userInfo)) {
                if (isset($userInfo->email) && $userInfo->email != '' && $userInfo->isactive == 0) {
                    $id = User::where(['id' => $userInfo->id])->update(['confirmation_code' => '', 'isactive' => 1]);
                    $userInfo->status = 1;
                } else if (isset($userInfo->email) && $userInfo->email != '' && $userInfo->isactive == 1) {
                    $id = User::where(['id' => $userInfo->id])->update(['confirmation_code' => '']);
                    $userInfo->status = 1;
                } else {
                    $userInfo->status = 2;
                }
            } else {
                return "2";
            }
        }
        return $userInfo;
    }

    public function getUser($userId = false)
    {
        if ($userId) {
            $users = DB::table('users')->where('id', $userId)->first();
        } else {
            if (Auth::user()->usertype == 'S') {
                $users = DB::select("select * from " . $this->tableWithPrefix . " where deleted_at is NULL ");
            } else {
                $users = DB::select("select * from " . $this->tableWithPrefix . " where id = " . Auth::user()->id . " and deleted_at is NULL ");
            }
        }
        return $users;
    }

    public function getLog($logId = false)
    {
        $general = new General;
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $logInfo = DB::table('log')->where('logid', $logId)->first();
        if ($logInfo) {
            $timezone = DB::table('users')->where('id', $logInfo->userid)->value('timezone');
            $array = array(
                "logid" => $logInfo->logid,
                "userid" => $logInfo->userid,
                "ip" => $logInfo->ip,
                "country" => $logInfo->country,
                "region" => $logInfo->region,
                "city" => $logInfo->city,
                "latitude" => $logInfo->latitude,
                "longitude" => $logInfo->longitude,
                "device" => $logInfo->device,
                "devicetype" => $logInfo->devicetype,
                "browser" => $logInfo->browser,
                "browsertype" => $logInfo->browsertype,
                "removed" => $logInfo->removed,
                "logged_at" => $general->converttimezoneFromUTC($logInfo->logged_at,$timezone),
            );
            $this->newdata = (object) $array;
        }
        return $this->newdata;
    }

    public function getPaymentGateway()
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $pgatewayInfo = DB::table('payment_gateway')->where('pgatewayid', 1)->first();
        if ($pgatewayInfo) {
            $array = array(
                "pgatewayid" => $pgatewayInfo->pgatewayid,
                "sendpoint" => $pgatewayInfo->sendpoint,
                "susername" => $pgatewayInfo->susername,
                "spassword" => $pgatewayInfo->spassword,
                "ssignature" => $pgatewayInfo->ssignature,
                "scheckouturl" => $pgatewayInfo->scheckouturl,
                "lendpoint" => $pgatewayInfo->lendpoint,
                "lusername" => $pgatewayInfo->lusername,
                "lpassword" => $pgatewayInfo->lpassword,
                "lsignature" => $pgatewayInfo->lsignature,
                "lcheckouturl" => $pgatewayInfo->lcheckouturl,
                "version" => $pgatewayInfo->version,
                "live" => $pgatewayInfo->live
            );
            $this->newdata = (object) $array;
        }
        return $this->newdata;
    }

    public function getUsers($seoname)
    {
        /*$projectCreated_by = DB::table('projects')->where('seoname', '=', $seoname)->value('created_by');
        $users = DB::select("select * from ".$this->tableWithPrefix." where id not in( ".Auth::user()->id.",".$projectCreated_by.") and isactive = 1 and deleted_at is NULL ");*/
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $UId = (isset(Auth::user()->id) ? Auth::user()->id : Session::get('invitedNotRegUserId'));
        $userids = DB::select("select distinct(userid) from todo_invites where projectid in(select projectid from todo_invites where userid =" . $UId . ")");
        if (count($userids) > 0) {
            foreach ($userids as $userid) {
                $user = DB::table('users')->where([['id', $userid->userid], ['isactive', 1]])->first();
                if ($user) {
                    $array = array(
                        "userid" => $user->id,
                        "firstname" => $user->firstname,
                        "lastname" => $user->lastname,
                        "username" => $user->firstname . " " . $user->lastname,
                        "email" => $user->email,
                        "profilepic" => $user->profilepic,
                    );
                    $this->newdata[$this->i] = (object) $array;
                    $this->i++;
                }
            }
        }
        return $this->newdata;
    }

    public function getClientUsers($companyId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $clientuserids = DB::select("select distinct(userid) from todo_user_company_link where companyid = " . $companyId . " and FIND_IN_SET(3,user_type) and deleted_at = '0000-00-00 00:00:00'");
        if (count($clientuserids) > 0) {
            foreach ($clientuserids as $userid) {
                $user = DB::table('users')->where([['id', $userid->userid], ['isactive', 1]])->first();
                if ($user) {
                    $array = array(
                        "userid" => $user->id,
                        "firstname" => $user->firstname,
                        "lastname" => $user->lastname,
                        "username" => $user->firstname . " " . $user->lastname,
                        "email" => $user->email,
                        "address" => $user->address,
                    );
                    $this->newdata[$this->i] = (object) $array;
                    $this->i++;
                }
            }
        }
        return $this->newdata;

    }

    public function getShareUsers($seoname)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $noteInfo = DB::table('notes')->where('seoname', '=', $seoname)->first();
        $shares = DB::table('notes_share')->where([['noteid', $noteInfo->noteid],['deleted_at',null]])->get();
        if (count($shares) > 0) {
            foreach ($shares as $share) {
                $user = DB::table('users')->where([['id', $share->userid], ['isactive', 1]])->first();
                if ($user) {
                    $array = array(
                        "shareid" => $share->shareid,
                        "userid" => $user->id,
                        "firstname" => $user->firstname,
                        "lastname" => $user->lastname,
                        "username" => $user->firstname . " " . $user->lastname,
                        "email" => $user->email,
                        "profilepic" => $user->profilepic,
                    );
                    $this->newdata[$this->i] = (object) $array;
                    $this->i++;
                }
            }
        }
        return $this->newdata;
    }

    public function getLogs($userId = false)
    {
        if ($userId) {
            $logs = DB::table('log')
            ->where([['userid', $userId],['removed','0']])
            ->orderBy('logid', 'Desc')
            ->get();
        } 
        return $logs;
    }
    
    public function getTimezones()
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $timezones = DB::select("select * from todo_timezone order by timezoneid");
        if (count($timezones) > 0) {
            foreach ($timezones as $timezone) {
                $array = array(
                    "timezoneid" => $timezone->timezoneid,
                    "timezonename" => $timezone->timezonename,
                    "timezonevalue" => $timezone->timezonevalue,
                );
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
            }
        }
        return $this->newdata;
    }

    public function savePaypal($request)
    {
        return DB::table('payment_gateway')->where(['pgatewayid' => $request->pgatewayid])->update(['sendpoint' => $request->sendpoint, 'susername' => $request->susername, 'spassword' => $request->spassword, 'ssignature' => $request->ssignature, "scheckouturl" => $request->scheckouturl,'lendpoint' => $request->lendpoint, 'lusername' => $request->lusername, 'lpassword' => $request->lpassword, 'lsignature' => $request->lsignature, "lcheckouturl" => $request->lcheckouturl, "version" => $request->version, "live" => $request->live, "updated_at" => date("Y-m-d H:i:s"), "updated_by" => Auth::user()->id]);
    }

    public function updateProfile($request)
    {
        if ($request->isXmlHttpRequest()) {
            $general = new General;
            $userInfo = DB::table('users')->where('id', '=', $request->userid)->first();
            $imageSize = array("width"=>100,"height"=>100);
            
            if ($request->profilepic != '' && file_exists("public/img/temp/" . $request->profilepic)) {
                $imageName = $general->saveImage($request->profilepic, 'profile_img', $userInfo->id, $imageSize);
                if ($imageName == 'size') {
                    return '5';
                }
            } else {
                $imageName = $userInfo->profilepic;
            }
        }
        Auth::user()->profilepic = $imageName;
        return User::where(['id' => $request->userid])->update(['firstname' => $request->firstname, 'lastname' => $request->lastname, 'phone' => $request->phone, 'timezone' => $request->timezone, "profilepic" => $imageName, "updated_at" => date("Y-m-d H:i:s")]);
    }

    public static function changePassword($request)
    {
        return User::where(['id' => $request->id])->update(['password' => bcrypt($request->newpassword), "updated_at" => date("Y-m-d H:i:s")]);
    }

    public static function removeLog($request)
    {
        return DB::table('log')->where(['logid' => $request->logid])->update(['removed' => '1']);
    }

    public function resetPassword($request)
    {
        $userInfo = DB::table('users')->where('id', base64_decode($request->keycode))->first();
        if (!$userInfo) {
            return "3";
        }
        if($userInfo->timezone == ''){
            return User::where(['id' => $userInfo->id])->update(['timezone' => $request->timezone, 'isactive' => 1, 'forgotpassword_at' => null, 'confirmation_code'=> null, 'password' => bcrypt($request->password)]);
        }else{
            return User::where(['id' => $userInfo->id])->update(['isactive' => 1, 'forgotpassword_at' => null, 'confirmation_code'=> null, 'password' => bcrypt($request->password)]);
        }
    }

    public static function setListingType($request)
    {
        return User::where(['id' => $request->id])->update(['listingtype' => $request->listingtype, "updated_at" => date("Y-m-d H:i:s")]);
    }

    public static function setLeftPanelType($request)
    {
        return User::where(['id' => $request->id])->update(['leftpaneltype' => $request->leftpaneltype, "updated_at" => date("Y-m-d H:i:s")]);
    }

    public function getUsersByPSN($seoname)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $UId = (isset(Auth::user()->id) ? Auth::user()->id : Session::get('invitedNotRegUserId'));
        $projectId = DB::table('projects')->where('seoname', '=', $seoname)->value('projectid');

        $userids = DB::select("select distinct(userid) from todo_invites where projectid in(select projectid from todo_invites where userid =" . $UId . ")");
        if (count($userids) > 0) {
            foreach ($userids as $userid) {
                $user = DB::table('users')->where([['id', $userid->userid]])->first();
                if ($user) {
                    $array = array(
                        "userid" => $user->id,
                        "firstname" => $user->firstname,
                        "lastname" => $user->lastname,
                        "username" => $user->firstname . " " . $user->lastname,
                        "email" => $user->email,
                        "profilepic" => $user->profilepic,
                    );
                    $this->newdata[$this->i] = (object) $array;
                    $this->i++;
                }
            }
        }
        return $this->newdata;
    }

    public function getInviteUserByPID($projectId = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array2 = array();
        $array3 = array();
        $project = DB::table('projects')->where('projectid',$projectId)->first();
        $users = DB::select("select i.inviteid, i.invitetype, i.manager, i.created_by, u.id, u.firstname, u.lastname, u.email, u.profilepic from " . $this->tableWithPrefix . " u,todo_invites i where u.isactive = 1 and u.deleted_at = '0000-00-00 00:00:00' and i.userid = u.id and i.projectid = " . $project->projectid . " and i.deleted_at = '0000-00-00 00:00:00' ");
        if (count($users) > 0) {
            foreach ($users as $user) {
                $array2 = array(
                    "inviteuserid" => $user->id,
                    "inviteid" => $user->inviteid,
                    "invitetype" => $user->invitetype,
                    "manager" => $user->manager,
                    "created_by" => $user->created_by,
                    "firstname" => $user->firstname,
                    "lastname" => $user->lastname,
                    "email" => $user->email,
                    "profilepic" => $user->profilepic,
                    "created" => ($user->id == $project->created_by ? '1' : ''),
                );
                if (!in_array($user->id, $array3)) {
                    $array3[] = $user->id;
                    $this->newdata[$this->i] = (object) $array2;
                    $this->i++;
                }
            }
        }
        return $this->newdata;
    }

    public function getTeamOrClient($projectId = false, $userType = false)
    {
        $inviteType = DB::table('invites')->where([['userid', Auth::user()->id], ['projectid', $projectId], ['deleted_at', '0000-00-00 00:00:00']])->value('invitetype');
        return $inviteType;
    }

    public function getTotalClientInvite($projectId)
    {
        //DB::enableQueryLog();
        $totalinviteclient = DB::table('users')
                ->join('invites', 'users.id', '=', 'invites.userid')
                ->where([['users.isactive', 1], ['users.deleted_at', '0000-00-00 00:00:00'],['invites.deleted_at', '0000-00-00 00:00:00'], ['invites.projectid', $projectId], ['invites.invitetype','C']])
                ->count();
        //print_r(DB::getQueryLog());        
        //$totalinviteclient = DB::select("select count(i.inviteid) as totalinviteclient from " . $this->tableWithPrefix . " u,todo_invites i where u.isactive = 1 and u.deleted_at = '0000-00-00 00:00:00' and i.userid = u.id and i.projectid = " . $project->projectid . " and i.invitetype = 'C' and i.deleted_at = '0000-00-00 00:00:00' ");

        return $totalinviteclient;
    }

    public function getAllInviteUsers($projectId)
    {
        $this->l = 0;
        $this->newdata3 = array();
        $array = array();
        $invites = DB::table('invites')->where([['projectid', $projectId], ['deleted_at', '0000-00-00 00:00:00']])->get();
        if (count($invites) > 0) {
            foreach ($invites as $invite) {
                $userInfo = DB::table('users')->where('id', $invite->userid)->first();
                $array = array(
                    "inviteuserid" => $invite->userid,
                    "inviteemail" => $userInfo->email,
                    "username" => $userInfo->firstname . " " . $userInfo->lastname,
                );
                $this->newdata3[$this->l] = (object) $array;
                $this->l++;
            }
        }
        return $this->newdata3;
    }

    public static function projectNotification($request)
    {
        return User::where(['id' => Auth::user()->id])->update(['projectnotification' => $request->projectnotification]);
    }

    public static function editEmail($request)
    {
        $dbuserEmail = DB::table('users')->where('id', $request->userid)->value('email');
        if ($dbuserEmail == $request->useremail) {
            return "2";
        } else {
            $userEmail = DB::table('users')->where('email', $request->useremail)->value('email');
            if (isset($userEmail) && $userEmail != '') {
                return "3";
            } else {
                return User::where(['id' => $request->userid])->update(['email' => $request->useremail, "updated_at" => date("Y-m-d H:i:s")]);
            }
        }
    }

    public static function completeTodo($request)
    {
        return User::where(['id' => Auth::user()->id])->update(['completetodo' => $request->completetodo]);
    }

    public static function dailyRecap($request)
    {
        return User::where(['id' => Auth::user()->id])->update(['dailyrecap' => $request->dailyrecap]);
    }

    public static function needTakeCare($request)
    {
        return User::where(['id' => Auth::user()->id])->update(['needtakecare' => $request->needtakecare]);
    }

    public static function eachItemRightAway($request)
    {
        return User::where(['id' => Auth::user()->id])->update(['eachitemrightaway' => $request->eachitemrightaway]);
    }

    public static function summaryEveryFewHours($request)
    {
        return User::where(['id' => Auth::user()->id])->update(['summaryeveryfewhours' => $request->summaryeveryfewhours]);
    }

    public static function notifiedProject($request)
    {
        $notifiedprojects = DB::table('users')->where('id', Auth::user()->id)->value('notifiedprojects');
        $newnotifiedprojects = ($notifiedprojects != '' ? $notifiedprojects . "," . $request->projectid : $request->projectid);
        if ($request->status == 1) {
            return User::where(['id' => Auth::user()->id])->update(['notifiedprojects' => $newnotifiedprojects]);
        } else {
            $notifiedprojectIds = $notifiedprojects;
            $notifiedprojectArray = explode(",", $notifiedprojects);
            if (in_array($request->projectid, $notifiedprojectArray)) {
                if (($key = array_search($request->projectid, $notifiedprojectArray)) !== false) {
                    unset($notifiedprojectArray[$key]);
                }
                $notifiedprojectIds = implode(",", $notifiedprojectArray);
            }
            return User::where(['id' => Auth::user()->id])->update(['notifiedprojects' => $notifiedprojectIds]);
        }
    }

    

}
