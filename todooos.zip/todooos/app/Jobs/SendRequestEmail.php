<?php

namespace App\Jobs;

use App\Jobs\Job;
use DB;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendRequestEmail extends Job implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels;

    protected $mailvar;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($mailvar)
    {
        $this->mailvar = $mailvar;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(Mailer $mailer)
    {
        $newmailvar = $this->mailvar;

        switch ($newmailvar['templateName']) {
            case 'emails.newDevice':
                {
                    $mailer->send($this->mailvar['templateName'], ['mailvar' => $this->mailvar], function ($message) use ($newmailvar) {
                        $message->to($newmailvar['email'], 'New user')->subject('Security alert');
                    });
                    break;
                }
            case 'emails.signUp':
                {
                    $mailer->send($this->mailvar['templateName'], ['mailvar' => $this->mailvar], function ($message) use ($newmailvar) {
                        $message->to($newmailvar['email'], 'New user')->subject('Registration');
                    });
                    break;
                }
            case 'emails.forgotPassWord':
                {
                    $mailer->send($this->mailvar['templateName'], ['mailvar' => $this->mailvar], function ($message) use ($newmailvar) {
                        $message->to($newmailvar['email'], 'New user')->subject('Forgot Password');
                    });
                    break;
                }
            case 'emails.noteSendRequest':
                {
                    $mailer->send($this->mailvar['templateName'], ['mailvar' => $this->mailvar], function ($message) use ($newmailvar) {
                        $message->to($newmailvar['createdByemail']);
                        $message->subject($newmailvar['notename'] . " - Request for access");
                    });
                    break;
                }
            case 'emails.noteAcceptRequest':
                {
                    $noteInfo = DB::table('notes')->where('noteid', $newmailvar['noteId'])->first();
                    $sharedByInfo = DB::table('users')->where('id', $newmailvar['createrId'])->first();
                    foreach ($newmailvar['shareIds'] as $shareId) {
                        $userInfo = DB::table('users')->where('id', $shareId)->first();
                        $mailvar = ['mailText' => $newmailvar['mailText'], 'email' => $userInfo->email, 'profilePic' => $sharedByInfo->profilepic, 'sharedByName' => $sharedByInfo->firstname . " " . $sharedByInfo->lastname, 'noteName' => $noteInfo->notename, 'seoUrl' => $noteInfo->seourl];
                        $mailer->send('emails.noteAcceptRequest', ['mailvar' => $mailvar], function ($message) use ($mailvar) {
                            $message->to($mailvar['email'])->subject('Share Note');
                        });
                    }
                    break;
                }
            case 'emails.projectInvitation':
                {
                    $userNames = "";
                    $projectInfo = DB::table('projects')->where('projectid', $newmailvar['projectid'])->first();
                    $invitedByInfo = DB::table('users')->where('id', $newmailvar['invitedId'])->first();
                    foreach ($newmailvar['inviteIds'] as $inviteId) {
                        $userNames = $this->inviteUserName($projectInfo->projectid, $inviteId);
                        $userinfo = DB::table('users')->where('id', $inviteId)->first();
                        $mailvar = ['mailText' => $newmailvar['mailText'], 'email' => $userinfo->email, 'profilePic' => $invitedByInfo->profilepic, 'invitedByName' => $invitedByInfo->firstname . " " . $invitedByInfo->lastname, 'userNames' => $userNames, 'projectName' => $projectInfo->projectname, 'seoUrl' => $projectInfo->seourl];
                        $mailer->send('emails.projectInvitation', ['mailvar' => $mailvar], function ($message) use ($mailvar) {
                            $message->to($mailvar['email'])->subject('Invitation');
                        });
                    }
                    break;
                }
            case 'emails.todoAutoProjectStatus':
                {
                    $projectInfo = DB::table('projects')->where('projectid', $newmailvar['projectid'])->first();
                    foreach ($newmailvar['notifyUserArray'] as $notifyUser) {
                        $userinfo = DB::table('users')->where('id', $notifyUser)->first();
                        $mailvar = ['email' => $userinfo->email];
                        $mailer->send('emails.todoAutoProjectStatus', ['mailvar' => $newmailvar], function ($message) use ($mailvar, $newmailvar) {
                            $message->to($mailvar['email']);
                            $message->from('admin@todooos.com', 'todooos');
                            $message->subject($newmailvar['mailSubject']);
                        });
                    }
                    break;
                }
            case 'emails.todoProjectEdit':
                {
                    foreach ($newmailvar['notifyUserArray'] as $notifyUser) {
                        $userinfo = DB::table('users')->where('id', $notifyUser)->first();
                        $mailvar = ['email' => $userinfo->email];
                        $mailer->send('emails.todoProjectEdit', ['mailvar' => $newmailvar], function ($message) use ($mailvar, $newmailvar) {
                            $message->to($mailvar['email']);
                            $message->from('admin@todooos.com', 'todooos');
                            $message->subject($newmailvar['mailSubject']);
                        });
                    }
                    break;
                }
            case 'emails.todoMove':
                {
                    foreach ($newmailvar['notifyUserArray'] as $notifyUser) {
                        $userinfo = DB::table('users')->where('id', $notifyUser)->first();
                        $mailvar = ['email' => $userinfo->email];
                        $mailer->send('emails.todoMove', ['mailvar' => $newmailvar], function ($message) use ($mailvar, $newmailvar) {
                            $message->to($mailvar['email'])->subject($newmailvar['mailSubject']);
                        });
                    }
                    break;

                }
            case 'emails.projectClientInvitation':
                {
                    $userNames = "";
                    $projectInfo = DB::table('projects')->where('projectid', $newmailvar['projectid'])->first();
                    $invitedByInfo = DB::table('users')->where('id', $newmailvar['invitedId'])->first();
                    foreach ($newmailvar['inviteIds'] as $inviteId) {
                        $userNames = $this->inviteClientUserName($projectInfo->projectid, $inviteId);
                        $userinfo = DB::table('users')->where('id', $inviteId)->first();
                        $mailvar = ['mailText' => $newmailvar['mailText'], 'email' => $userinfo->email, 'profilePic' => $invitedByInfo->profilepic, 'invitedByName' => $invitedByInfo->firstname . " " . $invitedByInfo->lastname, 'userNames' => $userNames, 'projectName' => $projectInfo->projectname, 'seoUrl' => $projectInfo->seourl];
                        $mailer->send('emails.projectClientInvitation', ['mailvar' => $mailvar], function ($message) use ($mailvar) {
                            $message->to($mailvar['email'])->subject('Invitation');
                        });
                    }
                    break;
                }
            case 'emails.todoProjectStatus':
                {
                    foreach ($newmailvar['notifyUserArray'] as $notifyUser) {
                        $userEmail = DB::table('users')->where('id', $notifyUser)->value('email');

                        $mailer->send('emails.todoProjectStatus', ['mailvar' => $newmailvar], function ($message) use ($newmailvar, $userEmail) {
                            $message->to($userEmail);
                            $message->from('admin@todooos.com', 'todooos');
                            $message->subject($newmailvar['mailSubject']);
                        });
                    }
                    break;
                }
            case 'emails.todoAssigned':
                {
                    foreach ($newmailvar['assignEmails'] as $assignEmail) {
                        $userinfo = DB::table('users')->where('email', $assignEmail)->first();
                        $mailer->send('emails.todoAssigned', ['mailvar' => $newmailvar], function ($message) use ($newmailvar, $assignEmail) {
                            $message->to($assignEmail);
                            $message->subject("(" . $newmailvar['projectname'] . ") " . $newmailvar['taskName']);
                        });
                    }
                    break;
                }
            case 'emails.todoUnassigned':
                {
                    foreach ($newmailvar['removeUserEmails'] as $removeUserEmail) {
                        $userinfo = DB::table('users')->where('email', $removeUserEmail)->first();
                        $mailer->send('emails.todoUnassigned', ['mailvar' => $newmailvar], function ($message) use ($newmailvar, $removeUserEmail) {
                            $message->to($removeUserEmail);
                            $message->subject("(" . $newmailvar['projectname'] . ") " . $newmailvar['taskName']);
                        });
                    }
                    break;
                }
            case 'emails.todoCompleted':
                {
                    foreach ($newmailvar['inviteEmails'] as $inviteEmail) {
                        $userinfo = DB::table('users')->where('email', $inviteEmail)->first();
                        if($userinfo->completetodo == 1){
                            $mailer->send('emails.todoCompleted', ['mailvar' => $newmailvar], function ($message) use ($newmailvar, $inviteEmail) {
                                $message->to($inviteEmail);
                                $message->subject("(" . $newmailvar['projectname'] . ") " . $newmailvar['taskName']);
                            });
                        }
                    }
                    break;
                }
            case 'emails.todoReOpen':
                {
                    foreach ($newmailvar['inviteEmails'] as $inviteEmail) {
                        $userinfo = DB::table('users')->where('email', $inviteEmail)->first();
                        $mailer->send('emails.todoReOpen', ['mailvar' => $newmailvar], function ($message) use ($newmailvar, $inviteEmail) {
                            $message->to($inviteEmail);
                            $message->subject("(" . $newmailvar['projectname'] . ") " . $newmailvar['taskName']);
                        });
                    }
                    break;
                }
            case 'emails.todoComment':
                {
                    $filevar = $newmailvar['filevar'];
                    $reademaillink = "";
                    $companyid = $newmailvar['companyid'];
                    $commentid = $newmailvar['id'];
                    foreach ($newmailvar['notifyUserArray'] as $notifyUser) {
                        $reademaillink = "comment/reademail/" . base64_encode($newmailvar['id'] . "|" . $newmailvar['companyid'] . "|" . $notifyUser);
                        $stopreceivedUrl = "stop-receiving-emails/" . base64_encode($notifyUser . "|" . $newmailvar['taskid'] . "|" . $newmailvar['id']);
                        $newmailvar['stopreceivedUrl'] = $stopreceivedUrl;
                        $newmailvar['reademaillink'] = $reademaillink;

                        $replyToEmail = "comment-" . base64_encode($newmailvar['id']) . "-" . base64_encode($notifyUser) . "@todooos.com";
                        $newmailvar['replyTo'] = $replyToEmail;
                        $userInfo = DB::table('users')->where('id', $notifyUser)->first();
                        $userEmail = $userInfo->email;
                        if($userInfo->isactive == '1'){
                                $mailer->send('emails.todoComment', ['mailvar' => $newmailvar, 'filevar' => $filevar], function ($message) use ($newmailvar, $filevar, $userEmail) {
                                $message->to($userEmail);
                                $message->from('admin@todooos.com', 'todooos');
                                $message->subject("Re: (" . $newmailvar['projectname'] . ") " . $newmailvar['taskName']);
                                $message->replyTo($newmailvar['replyTo']);
                            });
                        }else{
                                $newmailvar['seoViewUrl'] = "project/".$newmailvar['projectseoname']."/".$notifyUser."/viewtodo/".$newmailvar['seoName']."#".$newmailvar['id'];
                                $mailer->send('emails.todoViewComment', ['mailvar' => $newmailvar, 'filevar' => $filevar], function ($message) use ($newmailvar, $filevar, $userEmail) {
                                $message->to($userEmail);
                                $message->from('admin@todooos.com', 'todooos');
                                $message->subject("Re: (" . $newmailvar['projectname'] . ") " . $newmailvar['taskName']);
                                $message->replyTo($newmailvar['replyTo']);
                            });
                        }
                        
                    }
                    if(!empty($newmailvar['loopUserArray'])){
                        foreach ($newmailvar['loopUserArray'] as $loopUser) {
                            $reademaillink = "comment/reademail/" . base64_encode($newmailvar['id'] . "|" . $newmailvar['companyid'] . "|" . $loopUser);
                            $stopreceivedUrl = "stop-receiving-emails/" . base64_encode($notifyUser . "|" . $newmailvar['taskid'] . "|" . $newmailvar['id']);
                            $newmailvar['stopreceivedUrl'] = $stopreceivedUrl;
                            $newmailvar['reademaillink'] = $reademaillink;
    
                            $replyToEmail = "comment-" . base64_encode($newmailvar['id']) . "-" . base64_encode($loopUser) . "@todooos.com";
                            $newmailvar['replyTo'] = $replyToEmail;
                            $userInfo = DB::table('users')->where('id', $loopUser)->first();
                            $userEmail = $userInfo->email;
                            
                            $newmailvar['seoViewUrl'] = "project/".$newmailvar['projectseoname']."/".$loopUser."/viewtodo/".$newmailvar['seoName']."#".$newmailvar['id'];

                            $mailer->send('emails.todoViewComment', ['mailvar' => $newmailvar, 'filevar' => $filevar], function ($message) use ($newmailvar, $filevar, $userEmail) {
                            $message->to($userEmail);
                            $message->from('admin@todooos.com', 'todooos');
                            $message->subject("Re: (" . $newmailvar['projectname'] . ") " . $newmailvar['taskName']);
                            $message->replyTo($newmailvar['replyTo']);
                            });
                            
                        }
                    }
                    
                    break;
                }
            case 'emails.dailyRecap':
                {
                    $mailer->send('emails.dailyRecap', ['project5updates' => $newmailvar['project5updates']], function ($message) use ($newmailvar) {
                        $message->to($newmailvar['email']);
                        $message->from('admin@todooos.com', 'todooos');
                        $message->subject("Daily Recap");
                    });
                    break;
                } 
            case 'emails.needtotakecare':
                {
                    $mailer->send('emails.needtotakecare', ['needtotakecares' => $newmailvar['needtotakecares'], 'username' => $newmailvar['username']], function ($message) use ($newmailvar) {
                        $message->to($newmailvar['email']);
                        $message->from('admin@todooos.com', 'todooos');
                        $message->subject("You Need To Take Care");
                    });
                    break;
                }        
            case 'emails.signUpInvitation':
                {
                    $mailer->send('emails.signUpInvitation', ['mailvar' => $newmailvar], function ($message) use ($newmailvar) {
                        $message->to($newmailvar['email'], 'New user')->subject("You've been added to the " . $newmailvar['projectName'] . " project on todooos");
                    });
                    break;
                }
            case 'emails.signUpWithInvoice':
                {
                    $sentToVar = $newmailvar['sentToInfo'];
                    $sentFromVar = $newmailvar['sentFromInfo'];
                    $invoiceVar = $newmailvar['invoicevar'];
                    $invoiceVar = $newmailvar['invoicevar'];
                    $sendemail = $newmailvar['sendemail'];
                    $mailer->send('emails.signUpWithInvoice', ['mailvar' => $newmailvar, 'sentToVar' => $sentToVar, 'sentFromVar' => $sentFromVar, 'invoiceVar' => $invoiceVar], function ($message) use ($newmailvar, $sentToVar, $sentFromVar, $invoiceVar, $sendemail) {
                        $message->to($sendemail, 'New user')->subject("Registration with invoice");
                    });
                    break;
                }
            case 'emails.todoInvoice':
                {
                    $sentToVar = $newmailvar['sentToInfo'];
                    $sentFromVar = $newmailvar['sentFromInfo'];
                    $invoiceVar = $newmailvar['invoicevar'];
                    $invoiceVar = $newmailvar['invoicevar'];
                    $sendemail = $newmailvar['sendemail'];
                    $mailer->send('emails.todoInvoice', ['mailvar' => $newmailvar, 'sentToVar' => $sentToVar, 'sentFromVar' => $sentFromVar, 'invoiceVar' => $invoiceVar], function ($message) use ($newmailvar, $sentToVar, $sentFromVar, $invoiceVar, $sendemail) {
                        $message->to($sendemail, 'New user')->subject("Invoice");
                    });
                    break;
                }
            default:
                break;
        }

        /*$mailer->send($this->mailvar['templateName'], ['mailvar' => $this->mailvar], function ($message) use ($newmailvar)
    {
    $message->to($newmailvar['createdByemail']);
    $message->subject($newmailvar['notename']." - Request for access");
    //$message->from('satinath@gmail.com', 'Satinath Mondal');
    //$message->to('jayantadhn@gmail.com','Jayanta Mondal')->subject('Share Note');
    });*/
    }

    private function inviteUserName($projectId = false, $inviteId = false)
    {
        $userNames = '';
        $invites = DB::table('invites')->where('projectid', $projectId)->get();
        if (count($invites) > 0) {
            foreach ($invites as $invite) {
                if ($invite->userid != $inviteId) {
                    $userInfo = DB::table('users')->where([['id', $invite->userid], ['isactive', 1]])->first();
                    if (count($userInfo) > 0) {
                        $allUserNames[] = $userInfo->firstname . " " . $userInfo->lastname;
                    }
                }
            }
            $last = array_pop($allUserNames);
            if ($allUserNames) {
                $userNames = implode(', ', $allUserNames) . " and " . $last;
            }
        }
        return $userNames;
    }

    private function inviteClientUserName($projectId = false, $inviteId = false)
    {
        $userNames = '';
        $invites = DB::table('clientinvites')->where('projectid', $projectId)->get();
        if (count($invites) > 0) {
            foreach ($invites as $invite) {
                if ($invite->userid != $inviteId) {
                    $userInfo = DB::table('users')->where([['id', $invite->userid], ['isactive', 1]])->first();
                    if (count($userInfo) > 0) {
                        $allUserNames[] = $userInfo->firstname . " " . $userInfo->lastname;
                    }
                }
            }
            $last = array_pop($allUserNames);
            if ($allUserNames) {
                $userNames = implode(', ', $allUserNames) . " and " . $last;
            }
        }
        return $userNames;
    }

    //Join a string with a natural language conjunction at the end.
    private function natural_language_join(array $list, $conjunction = 'and')
    {
        $last = array_pop($list);
        if ($list) {
            return implode(', ', $list) . ' ' . $conjunction . ' ' . $last;
        }
        return $last;
    }

}
