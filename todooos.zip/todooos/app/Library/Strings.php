<?php

//
// class.strings.php
//
// Description
//
// This class does not need to be assigned to an object,
// as you could use the :: access method,
// such as Strings::ValidateString
//
// created by
//
// sathyaraj, 2008
// sathyaraj@proconit.net
//
namespace App\Library 
{
	class Strings
	{
			/**
			 * Validates whether the given element is a string.
			 *
			 * @return bool
			 * @param  string $element
			 * @param  bool   $requireContent If the string can be empty or not
			 */
			public static function ValidateString($element, $requireContent = true)
			{
					return (!is_string($element)) ? false : ($requireContent && $element == '' ? false : true);
			}
	
			/**
			 * Validates whether the given element is an array.
			 *
			 * @return bool
			 * @param  array $element
			 * @param  bool  $requireContent If the array can be empty or not
			 */
			public static function ValidateArray($element, $requireContent = true)
			{
					return (!is_array($element)) ? false : ($requireContent && empty($element) ? false : true);
			}
	
			/**
			 * Validates whether an email address has a valid format.
			 *
			 * @return bool
			 * @param  string $email
			 */
			public function ValidateEmail($email)
			{
					return (eregi("[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-z]{2,3}", $email)) ? true : false;
			}
	
			/**
			 * Converts high-character symbols into their respective html entities.
			 *
			 * @return string
			 * @param  string $string
			 */
			public function ConvertSymbolsToEntities($string)
			{
					static $sSymbols =
							array(
									'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',
									'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',
									'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',
									'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',
									'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',
									'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',
									'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',
									'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',
									'�', '�');
					static $sEntities =
							array(
									'&#8218;',  '&#402;',   '&#8222;',  '&#8230;',  '&#8224;',  '&#8225;',  '&#710;',
									'&#8240;',  '&#352;',   '&#8249;',  '&#338;',   '&#8216;',  '&#8217;',  '&#8220;',
									'&#8221;',  '&#8226;',  '&#8211;',  '&#8212;',  '&#732;',   '&#8482;',  '&#353;',
									'&#8250;',  '&#339;',   '&#376;',   '&#8364;',  '&aelig;',  '&aacute;', '&acirc;',
									'&agrave;', '&aring;',  '&atilde;', '&auml;',   '&ccedil;', '&eth;',    '&eacute;',
									'&ecirc;',  '&egrave;', '&euml;',   '&iacute;', '&icirc;',  '&igrave;', '&iuml;',
									'&ntilde;', '&oacute;', '&ocirc;',  '&ograve;', '&oslash;', '&otilde;', '&ouml;',
									'&thorn;',  '&uacute;', '&ucirc;',  '&ugrave;', '&uuml;',   '&yacute;', '&aacute;',
									'&acirc;',  '&aelig;',  '&agrave;', '&aring;',  '&atilde;', '&auml;',   '&ccedil;',
									'&eacute;', '&ecirc;',  '&egrave;', '&eth;',    '&euml;',   '&iacute;', '&icirc;',
									'&igrave;', '&iuml;',   '&ntilde;', '&oacute;', '&ocirc;',  '&ograve;', '&oslash;',
									'&otilde;', '&ouml;',   '&szlig;',  '&thorn;',  '&uacute;', '&ucirc;',  '&ugrave;',
									'&uuml;',   '&yacute;', '&yuml;',   '&iexcl;',  '&pound;',  '&curren;', '&yen;',
									'&brvbar;', '&sect;',   '&uml;',    '&copy;',   '&ordf;',   '&laquo;',  '&not;',
									'&shy;',    '&reg;',    '&macr;',   '&deg;',    '&plusmn;', '&sup2;',   '&sup3;',
									'&acute;',  '&micro;',  '&para;',   '&middot;', '&cedil;',  '&sup1;',   '&ordm;',
									'&raquo;',  '&frac14;', '&frac12;', '&frac34;', '&iquest;', '&times;',  '&divide;',
									'&cent;',   '...',      '&micro;');
	
					if (Strings::ValidateString($string, false)) {
							return str_replace($sSymbols, $sEntities, $string);
					} else {
							return $string;
					}
			}
	
			/**
			 * Converts all strings, or all elements of an array, no matter how nested
			 * the array is, to html entities.
			 *
			 * @return string|array
			 * @param  string|array $element
			 */
			public function ConvertTextToHTML($element)
			{
					return stripslashes(Strings::ProcessFunction($element, 'htmlentities'));
			}
			 /**
			 * Converts all strings, or all elements of an array, no matter how nested
			 * the array is, to html entities decode.
			 *
			 * @return string|array
			 * @param  string|array $element
			 */
			public function ConvertHTMLToText($element)
			{
					return Strings::ProcessFunction($element, 'html_entity_decode');
			}
	
			/**
			 * Cuts the given string to a certain length without breaking a word.
			 *
			 * @return string
			 * @param  string  $string
			 * @param  int     $length number of maximum characters leave remaining
			 * @param  bool    $more   whether to display '...' on the end of the trimmed string
			 * @param  string  $trimString display trim string
			 */
			public  function TrimStringToLength($string, $length, $more = true,$trimString="...")
			{
					if (Strings::ValidateString($string)) {
							$trimmed = str_replace('<br>', $trimString, ereg_replace('(<br>)+', '<br>', $string));
							$trimmed = strip_tags($trimmed);
							if (strlen($trimmed) > $length) {
									$trimmed = substr($trimmed, 0, strrpos(substr($trimmed, 0, $length), ' '));
									if ($more === true) {
											$trimmed .= $trimString;
									}
							}
							return $trimmed;
					}
			}
	
			/**
			 * Removes the first or last word from a string.
			 *
			 * @return string
			 * @param  string $string
			 * @param  bool   $start whether to trim at start (true) or end (false) of string
			 */
			public  function TrimWordFromString($string, $start = true)
			{
					if (Strings::ValidateString($string)) {
							$trimmed = trim($string);
							if (!substr_count($trimmed, ' ')) {
									return $trimmed;
							} else {
									return ($start) ? substr($trimmed, strpos($trimmed, ' ')+1, strlen($trimmed)) : substr($trimmed, 0, strrpos($trimmed, ' '));
							}
					}
			}
	
			/**
			 * Removes the first word from a string.
			 *
			 * @return string
			 * @param  string $string
			 * @see   TrimWordFromString()
			 */
			public  function trimFirstWordFromString($string)
			{
					return Strings::TrimWordFromString($string, true);
			}
	
			/**
			 * Removes the last word from a string.
			 *
			 * @return string
			 * @param string $string
			 * @see   TrimWordFromString()
			 */
			public  function TrimLastWordFromString($string)
			{
					return Strings::TrimWordFromString($string, false);
			}
	
			/**
			 * Can perform a full trim a string, or all elements of an array, no
			 * matter how nested the array is.
			 *
			 * @return string|array
			 * @param  string|array $element
			 */
			public  function TrimString($element)
			{
					return Strings::ProcessFunction($element, 'trim');
			}
	
			/**
			 * Can left-trim a string, or all elements of an array, no matter
			 * how nested the array is.
			 *
			 * @return string|array
			 * @param  string|array $element
			 */
			public  function TrimStringLeft($element)
			{
					return Strings::ProcessFunction($element, 'ltrim');
			}
	
			/**
			 * Can right-trim a string, or all elements of an array, no matter
			 * how nested the array is.
			 *
			 * @return string|array
			 * @param  string|array $element
			 */
			public  function TrimStringRight($element)
			{
					return Strings::ProcessFunction($element, 'rtrim');
			}
	
			/**
			 * Adds slashes to a string, or all elements of an array, no matter
			 * how nested the array is.
			 *
			 * If the 'check_gpc' parameter is true then slashes will be applied
			 * depending on magic_quotes setting.
			 *
			 * @return string|array
			 * @param  string|array $element
			 * @param  bool         $checkGpc
			 */
			public  function AddSlashesToString($element, $checkGpc = true)
			{
					return ($checkGpc && get_magic_quotes_gpc()) ? $element : Strings::ProcessFunction($element, 'addslashes');
			}
	
			/**
			 * Removes slashes from a string, or all elements of an array, no matter
			 * how nested the array is.
			 *
			 * If the 'check_gpc' parameter is true then slashes will be removed
			 * depending on magic_quotes setting.
			 *
			 * @return string|array
			 * @param  string|array $element
			 * @param  bool         $checkGpc
			 */
			public  function TrimSlashesFromString($element, $checkGpc = true)
			{
					return ($checkGpc && !get_magic_quotes_gpc()) ? $element : Strings::ProcessFunction($element, 'stripslashes');
			}
	
			/**
			 * Performs the passed function recursively.
			 *
			 * @return string|array
			 * @param  string|array $element
			 * @param  string       $function
			 */
			public  static function ProcessFunction($element, $function)
			{
					if (function_exists($function) === true) {
							if (Strings::ValidateArray($element, false) === false) {
									return $function($element);
							} else {
									foreach ($element as $key => $val) {
											if (Strings::ValidateArray($element[$key], false)) {
													$element[$key] = Strings::ProcessFunction($element[$key], $function);
											} else {
													$element[$key] = $function($element[$key]);
											}
									}
							}
					}
					return $element;
			}
	
			/**
			 * Get the ordinal value of a number (1st, 2nd, 3rd, 4th).
			 *
			 * @return string
			 * @param  int    $value
			 */
			public  function GetOrdinalString($value)
			{
					static $ords = array('th', 'st', 'nd', 'rd');
					if ((($value %= 100) > 9 && $value < 20) || ($value %= 10) > 3) {
							$value = 0;
					}
					return $ords[$value];
			}
	
			/**
			 * Returns the plural appendage, handy for instances like: 1 file,
			 * 5 files, 1 box, 3 boxes.
			 *
			 * @return string
			 * @param  int    $value
			 * @param  string $append what value to append to the string
			 */
			public  function GetPluralString($value, $append = 's')
			{
					return ($value == 1 ? '' : $append);
			}
	
			/**
			 * Strips all newline characters (\n) from a string or recursively
			 * through a multi-dimensional array.
			 *
			 * @return string|array
			 * @param  string|array $element
			 */
			public  function TrimNewlinesFromString($element)
			{
					if (Strings::ValidateArray($element, false) === false) {
							return str_replace("\n", '', $element);
					} else {
							foreach ($element as $key => $val) {
									if (Strings::ValidateArray($element[$key], false)) {
											$element[$key] = Strings::TrimNewlinesFromString($element[$key]);
									} else {
											$element[$key] = str_replace("\n", '', $element[$key]);
									}
							}
					}
					return $element;
			}
	
			/**
			 * Strips all carriage return characters (\r) from a string or
			 * recursively through a multi-dimensional array.
			 *
			 * @return string|array
			 * @param  string|array $element
			 */
			public  function TrimCarriageReturnsFromString($element)
			{
					if (Strings::ValidateArray($element, false) === false) {
							return str_replace("\r", '', $element);
					} else {
							foreach ($element as $key => $val) {
									if (Strings::ValidateArray($element[$key], false)) {
											$element[$key] = Strings::TrimCarriageReturnsFromString($element[$key]);
									} else {
											$element[$key] = str_replace("\r", '', $element[$key]);
									}
							}
					}
					return $element;
			}
	
			/**
			 * Returns the extension of a file (ie. anything that appears after
			 * the last '.')
			 *
			 * @return string|null
			 * @param  string $string
			 */
			public  function GetFileExtension($string)
			{
					if (Strings::ValidateString($string)) {
							return substr($string, (strrpos($string, '.') ? strrpos($string, '.')+1 : strlen($string)), strlen($string));
					} else {
							return null;
					}
			}
	
			/**
			 * Returns the name of a file (ie. anything that appears before
			 * the last '.')
			 *
			 * @return string|null
			 * @param  string $string
			 */
			public  function GetFileName($string)
			{
					if (Strings::ValidateString($string)) {
							return substr($string, 0, (strrpos($string, '.') ? strrpos($string, '.') : strlen($string)));
					} else {
							return null;
					}
			}
	
		/**
		 * Displays a human readable file size.
		 *
		 * @return string|null
		 * @param  string $file
		 * @param  bool   $round
		 */
		public  function GetFileSize($file, $round = false)
		{
			if (@file_exists($file)) {
				$value = 0;
				$size = filesize($file);
				if ($size >= 1073741824) {
					$value = round($size/1073741824*100)/100;
					return  ($round) ? round($value) . 'Gb' : "{$value}Gb";
				} else if ($size >= 1048576) {
					$value = round($size/1048576*100)/100;
					return  ($round) ? round($value) . 'Mb' : "{$value}Mb";
				} else if ($size >= 1024) {
					$value = round($size/1024*100)/100;
					return  ($round) ? round($value) . 'kb' : "{$value}kb";
				} else {
					return "$size bytes";
				}
			} else {
				return null;
			}
			}
	
		/**
		 * Counts number of words in a string.
		 *
		 * if $realWords == true then remove things like '-', '+', that
		 * are surrounded with white space.
		 *
		 * @return string|null
		 * @param  string $string
		 * @param  bool   $realWords
		 */
			public  function CountWords($string, $realWords = true)
			{
					if (Strings::ValidateString($string)) {
							if ($realWords == true) {
									$string = preg_replace('/(\s+)[^a-zA-Z0-9](\s+)/', ' ', $string);
							}
							return (count(split('[[:space:]]+', $string)));
					} else {
							return null;
					}
			}
	
		/**
		 * generate random word.
		 *
		 * @return string|null
		 * @param  number $length
		 * @param  bool $lcase
		 * @param  bool $ucase
			 * @param  bool $number
			 * @param  bool $specchar
			 *
		 */
			public  function RoundWord($length=10,$lcase=true,$ucase=true,$number=true,$specchar=true) {
				 if ($lcase) {
				$chars = array("A","B","C","D","E","F","G","H","I","J","K",
													 "L","M","N","O","P","Q",
							 "R","S","T","U","V","W",
							 "X","Y","Z");
			}
			if ($ucase) {
				$chars[] = "a";
				$chars[] = "b";
				$chars[] = "c";
				$chars[] = "d";
				$chars[] = "e";
				$chars[] = "f";
				$chars[] = "g";
				$chars[] = "h";
				$chars[] = "i";
				$chars[] = "j";
				$chars[] = "k";
				$chars[] = "l";
				$chars[] = "m";
				$chars[] = "n";
				$chars[] = "o";
				$chars[] = "p";
				$chars[] = "q";
				$chars[] = "r";
				$chars[] = "s";
				$chars[] = "t";
				$chars[] = "u";
				$chars[] = "v";
				$chars[] = "w";
				$chars[] = "x";
				$chars[] = "y";
				$chars[] = "z";
			}
			if ($number) {
				$chars[] = "1";
				$chars[] = "2";
				$chars[] = "3";
				$chars[] = "4";
				$chars[] = "5";
				$chars[] = "6";
				$chars[] = "7";
				$chars[] = "8";
				$chars[] = "9";
				$chars[] = "0";
			}
			if ($specchar) {
				$chars[] = '!';
				$chars[] = '@';
				$chars[] = '#';
				$chars[] = "$";
				$chars[] = '%';
				$chars[] = '^';
				$chars[] = '&';
				$chars[] = '*';
				$chars[] = '(';
				$chars[] = ')';
				$chars[] = '{';
				$chars[] = '}';
				$chars[] = '[';
				$chars[] = ']';
				$chars[] = '<';
				$chars[] = '>';
				$chars[] = '?';
				$chars[] = "=";
				$chars[] = '+';
				$chars[] = '-';
				$chars[] = "_";
				$chars[] = "/";
			}
	
			$max_elements = count($chars) - 1;
			$l = $length;
			for ($i = 0;$i<$l;$i++)
			{
				srand((double)microtime()*1000000);
				$newpw .= $chars[rand(0,$max_elements)];
			}
			return  $newpw;
		}
			/**
		 * Counts number of sentences in a string.
		 *
		 * @return string|null
		 * @param  string $string
			*/
			public  function CountSentences($string)
			{
					if (Strings::ValidateString($string)) {
							return preg_match_all('/[^\s]\.(?!\w)/', $string, $matches);
					} else {
							return null;
					}
			}
	
		/**
		 * Counts number of sentences in a string.
		 *
		 * @return string|null
		 * @param  string $string
		 */
			public  function CountParagraphs($string)
			{
					if (Strings::ValidateString($string)) {
							$string = str_replace("\r", "\n", $string);
							return count(preg_split('/[\n]+/', $string));
					} else {
							return false;
					}
			}
	
		/**
		 * Gather information about a passed string.
		 *
		 * If $realWords == true then remove things like '-', '+', that are
		 * surrounded with white space.
		 *
		 * @return string|null
		 * @param  string $string
		 * @param  bool   $realWords
		 */
			public  function GetStringInformation($string, $realWords = true)
			{
					if (Strings::ValidateString($string)) {
							$info = array();
							$info['character'] = ($realWords) ? preg_match_all('/[^\s]/', $string, $matches) : strlen($string);
							$info['word']      = Strings::CountWords($string, $realWords);
							$info['sentence']  = Strings::CountSentences($string);
							$info['paragraph'] = Strings::CountParagraphs($string);
							return $info;
					} else {
							return null;
					}
			}
	
			/**
			 * Returns the formatted string with highlighted search keywords.
			 * NOTE: This function formats string using preg_replace().
			 *
			 * @param search string, subject string and formatting to be applied for highlighting search keywords
			 *
			 * @access public
			 *
			 * @return formatted string with highlighted search keywords.
			 */
	
		public  function HighlightSearchString($searchString, $subjectString, $caseSensitive=true, $highlightedBgColor='', $highlightedFontColor='', $applyBold=true, $applyItalic=false, $applyUnderline=false)
		{
			if(!empty($searchString) && !empty($subjectString)){
				$style = '';
	
				if(!empty($highlightedFontColor)) {
					$style = "color : $highlightedFontColor; ";
				}
				if(!empty($highlightedBgColor)) {
					$style .= "background-color : $highlightedBgColor; ";
				}
				if($applyBold) {
					$style .= "font-weight : bold; ";
				}
				if($applyItalic) {
					$style .= "font-style : italic; ";
				}
				if($applyUnderline) {
					$style .= "text-decoration : underline; ";
				}
	
				$formattedString = preg_replace("/($searchString)/".($caseSensitive==true?'i':''),"<font style=\"$style\">$1</font>",$subjectString,-1);
			}else{
				$formattedString = $subjectString;
			}
	
			return $formattedString;
	
		} // end func HighlightSearchString
			/**
		 * Gather information about a passed string.
		 *
		 * converts numbers to words
		 *
		 * @return string|null
		 * @param  Integer $number
			 * @param  string $lang
		 */
	
			public  function GetHundreds($number,$lang="en")
			{
	
				$test=$number*1;
				if (empty($test))return;
					if($lang=="en")
					{
						$lasts=array('one','two','three','four','five','six','seven','eight','nine');
						$teens=array('eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen');
							$teen=array('ten','twenty','thirty','forty','fifty','sixty','seventy','eighty','ninety');
					}
					else if($lang=="nl")
					{
						$lasts=array('een','twee','drie','vier','vijf','zes','zeven','acht','negen');
						$teens=array('elf','twaalf','dertien','veertien','vijftien','zestien','zeventien','achttien','negentien');
							$teen=array('tien','twintig','dertig','veertig','vijftig','zestig','zeventig','tachtig','negentig');
					}
	
				/* written by bas@startpunt.cc */
	
				$string='';
				$j=strlen($number);
				$done=false;
				for($i=0; $i<strlen($number); $i++)
				{
					if($j==2)
					{
					if(strlen($number)>2)
					{
					if($number[0]!=0)$string.= ' hundred ';
					if(substr($number,$i+1))$string.= 'and ';
					}
					if ($number[$i]==1)
					{
						if($number[$i+1]==0) $string.=$teen[$number[$i]-1];
						else
						{
						$string.=$teens[$number[$i+1]-1];
						$done=true;
						}
					}
					else
					{
						if(!empty($teen[$number[$i]-1]))$string.=$teen[$number[$i]-1].' ';
					}
				}
	
					elseif($number[$i]!=0 && !$done) $string.=$lasts[$number[$i]-1];
	
					$j--;
				}
	
					return $string;
			}
			 /**
		 * Gather information about a passed string.
		 *
		 * converts numbers to words
		 *
		 * @return string|null
		 * @param  Integer $number
			 * @param  string $uk
			 * @param  string $lang
		 */
	
			public  function ConvertNumToWord($number,$uk=0,$lang="en")
			{
	
					if(!is_string($number))$number.="";
					if($lang=="en"){
						if(!$uk)$many=array('', ' thousand ',' million ',' billion ',' trillion ');
						else $many=array('', ' thousand ',' million ',' milliard ',' billion ');
					}
					else if($lang=="nl"){
						if(!$uk)$many=array('', ' duizend ',' miljoen ',' miljard ',' biljoen ');
						else $many=array('', ' duizend ',' miljoen ',' miljard ',' miljard ');
					}
	
				$string='';
				if(strlen($number)%3!=0)
				{
				$string.=Strings::GetHundreds(substr($number,0, strlen($number)%3 ),$lang);
				$string.=$many[floor(strlen($number)/3)];
	
				}
				for($i=0; $i<floor(strlen($number)/3); $i++)
				{
	
					$string.=Strings::GetHundreds(substr($number,strlen($number)%3+($i*3),3),$lang);
					if($number[strlen($number)%3+($i*3)]!=0)$string.=$many[floor(strlen($number)/3)-1-$i];
	
				}
	
				return $string;
			}
			
			public function limit_text($text,$limit)
			{
				$text = strip_tags($text);
				$words = str_word_count($text, 2);
				$pos = array_keys($words);
				if ( count($words) > $limit ) {
					$text = trim(substr($text, 0, $pos[$limit])).'...';
				};
				return $text;
			}
	
	}
}
?>