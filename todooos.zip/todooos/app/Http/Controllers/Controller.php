<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use App\Models\Project;
use App\Models\Comment;
use Session;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
	//protected $data = array();
	public function __construct() {
		//$this->comment = new Comment;
        //$this->project = new Project;
		//$this->getGlobalCommentView();
		
	}

	public function getGlobalCommentView(){
        
	}
}
