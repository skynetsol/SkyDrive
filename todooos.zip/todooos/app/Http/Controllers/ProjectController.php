<?php
namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Company;
use App\Models\Label;
use App\Models\Note;
use App\Models\Project;
//use App\Models\Report;
use App\Models\Task;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Response;
use Session;

class ProjectController extends Controller
{
    protected $data = array();
    private $result = '';
    private $redirecturl = '';

    public function __construct(){
        //parent::__construct();
        $this->label = new Label;
        $this->comment = new Comment;
        $this->project = new Project;
        $this->company = new Company;
        $this->note = new Note;
        $this->task = new Task;
        $this->user = new User;
        $this->middleware(function ($request, $next) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
                if(isset($companyInfo->companyid))
                {
                    if(isset($companyInfo->package->days) && $companyInfo->package->days == 'exp'){
                        if ($companyInfo->package->userid == Auth::user()->id){
                            abort(440);
                        }else{
                            abort(441);
                        }
                    }
                    $this->data['commentviews'] = $this->comment->getCommentView($companyInfo->companyid);
                    $this->data['totalcommentviews'] = $this->comment->getTotalCommentView($companyInfo->companyid);
                    $this->data['totalproject'] = $this->project->getTotalProjects($companyInfo->companyid,0);
                }
            }
            return $next($request);
        });
    }

    public function getProjectList(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->data['clients'] = $this->project->getAllClients($this->data['companyInfo']->companyid);
            $this->data['managers'] = $this->project->getAllManagers($this->data['companyInfo']->companyid);
            $this->data['projects'] = $this->project->getProjects($this->data['companyInfo']->companyid,$archived);
            $this->data['listingtype'] = Auth::user()->listingtype;
            $this->data['totarchivedproject'] = $this->project->getTotalProjects($this->data['companyInfo']->companyid, 1);
            $this->data['totalproject'] = $this->project->getTotalProjects($this->data['companyInfo']->companyid, 0);
            return view('project.projectlist',$this->data);
        } else {
            return redirect('signin');
        }
    }

    public function getAjaxProjectList(Request $request)
    {
        if (Auth::check()) {
            $this->data['listingtype'] = Auth::user()->listingtype;
            $this->data['lastalpha'] = $request->lastalpha;
            $this->data['projects'] = $this->project->getAjaxProjects($request,$this->data['companyInfo']->companyid);
            return view('project.ajaxprojectlist', $this->data);
        } else {
            return redirect('signin');
        }
    }

    public function getArchivedProjects(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 1;
            $this->data['projects'] = $this->project->getProjects($this->data['companyInfo']->companyid,$archived);
            $this->data['totarchivedproject'] = $this->project->getTotalProjects($this->data['companyInfo']->companyid, 1);
            $this->data['totalproject'] = $this->project->getTotalProjects($this->data['companyInfo']->companyid, 0);
            return view('project.archivedprojectlist', $this->data);
        } else {
            return redirect('signin');
        }
    }

    public function getAjaxArchivedProjectList(Request $request)
    {
        if (Auth::check()) {
            $this->data['lastalpha'] = $request->lastalpha;
            $this->data['projects'] = $this->project->getAjaxArchivedProjects($request,$this->data['companyInfo']->companyid);
            return view('project.ajaxarchivedprojectlist', $this->data);
        } else {
            return redirect('signin');
        }
    }

    private function getCommon($request)
    {
        if (isset($request->seoname)) {
            $strQuery = " seoname = '".$request->seoname."'";
            if (!isset($this->data['companyInfo']->companyid)) {
                $this->data['project'] = $this->project->getProjectByQuery($strQuery);
                $this->data['companyInfo'] = $this->company->getCompanyInfo($this->data['project']->companyid);
            }
            
            $this->data['project'] = $this->project->getProjectByQuery($strQuery);
            if (empty($this->data['project'])) {
                abort(404);
            }
            $this->data['totaldiscussion'] = $this->task->getTotalDiscussion($this->data['project']->projectid);
            $this->data['totaltask'] = $this->task->getTotalTask($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['totalfiles'] = $this->comment->getTotalFile($this->data['project']->projectid);
            $this->data['totaltimeentry'] = $this->task->getTotalTimeEntry($this->data['project']->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($this->data['project']->projectid);
            $this->data['totalproject'] = $this->project->getTotalProjects($this->data['companyInfo']->companyid,0);
            $this->data['totalnotes'] = $this->note->getTotalNotes($this->data['project']->projectid);
        }  

    }

    public function getProjectDetails(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0; 
            
            $this->getCommon($request);
            $this->data['project5updates'] = $this->task->getProjectUpdateList($this->data['project']->projectid, 'limit 5');
            $this->data['discussions'] = $this->task->getProjectDiscussions($this->data['project']->projectid, $searchQuery=false, $orderBy=false, 'limit 5');

            $this->data['notes'] = $this->note->getNoteList($this->data['project']->projectid);

            $orderBy = 'desc';
            $searchQuery = "deleted_at = '0000-00-00 00:00:00'";
            $limitQuery = "12";
            $this->data['projectfiles'] = $this->comment->getProjectFiles($this->data['project']->projectid, $searchQuery, $orderBy, $limitQuery);
            $this->data['labeltasks'] = $this->task->getLabelTaskList($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['totalcompletedtodo'] = $this->task->getTotalCompletedTodo($this->data['project']->projectid);
            $this->data['totalacrosslabel'] = $this->task->getTotalAcorssLabel($this->data['project']->projectid);
            $this->data['completedtodolists'] = $this->task->getCompletedtodolist($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            // $this->data['pd'] = "1";
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            return view('project.project',$this->data);
        } else {
            return redirect('signin');
        }
    }


    public function getFileList(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['listingtype'] = Auth::user()->listingtype;
            $orderBy = 'desc';
            $searchQuery = "deleted_at = '0000-00-00 00:00:00'";
            $limitQuery ="";
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            $this->data['projectfiles'] = $this->comment->getProjectFiles($this->data['project']->projectid, $searchQuery, $orderBy, $limitQuery);
            return view('project.filelist', $this->data);
        } else {
            return redirect('signin');
        }
    }

    public function getAjaxFileList(Request $request)
    {
        if (Auth::check()) {
            $orderBy = $request->orderby;
            $this->data['listingtype'] = Auth::user()->listingtype;
            $searchQuery = ($request->searchtext != "" ? ' deleted_at = "0000-00-00 00:00:00" and filename like "%'.$request->searchtext.'%" ' : ' deleted_at = "0000-00-00 00:00:00" ');
            $limitQuery = "";
            $this->data['projectfiles'] = $this->comment->getProjectFiles($request->projectid, $searchQuery, $orderBy, $limitQuery);
            return view('project.ajaxfilelist', $this->data);
        } else {
            return redirect('signin');
        }
    }

    public function postDeleteFile(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->comment->deleteFile($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('signin');
        }
    }

    public function postProjectStatusOneTime(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->projectStatusOneTime($request);
        } else {
            return redirect('signin');
        }
    }


    public function getNotes(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            //$this->note->editTempNote($this->result->projectid);
            $this->data['notes'] = $this->note->getNoteList($this->data['project']->projectid);
            $this->data['page'] = 'list';
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            return view('note.notelist', $this->data);
        } else {
            return redirect('signin');
        }
    }

    public function getAddNote(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['page'] = 'add';
            $this->note->editTempNote($this->data['project']->projectid);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            return view('note.add-note', $this->data);
        } else {
            return redirect('signin');
        }
    }

    public function postSaveNote(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->note->saveNote($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('signin');
        }
    }


    public function getEditNote(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['page'] = 'edit';
            //$this->note->editTempNote($this->data['project']->projectid);
            $this->data['note'] = $this->note->getNote($request->noteseoname, $this->data['project']->projectid);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            if($this->data['note']){
                return view('note.add-note', $this->data);
            }else{
                abort(404);
            }
            
        } else {
            return redirect('signin');
        }
    }

    public function postNoteCopy(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->note->noteCopy($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('signin');
        }
    }

    public function postNoteRename(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->note->noteRename($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('signin');
        }
    }

    public function postNoteDelete(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->note->noteDelete($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('signin');
        }
    }

    public function postProtectNote(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->note->protectNote($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('signin');
        }
    }

    public function getShareNote(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['note'] = $this->note->getNote($request->noteseoname, $this->data['project']->projectid);
            $this->data['users'] = $this->user->getUsers($request->seoname);
            $this->data['shareusers'] = $this->user->getShareUsers($request->noteseoname);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            return view('note.sharenote', $this->data);
        } else {
            return redirect('signin');
        }
    }

    public function postNoteShare(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->note->noteShare($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('signin');
        }
    }

    public function postRemoveNoteShare(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->note->removeNoteShare($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('signin');
        }
    }

    public function getInvite(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['teamorclient'] = $this->user->getTeamOrClient($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['users'] = $this->user->getUsers($request->seoname);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($this->data['project']->projectid);
            $this->data['totalinviteclient'] = $this->user->getTotalClientInvite($this->data['project']->projectid);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            return view('project.invite', $this->data);
        } else {
            return redirect('signin');
        }
    }

    public function postRemoveInvite(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->removeInvite($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('signin');
        }
    }

    public function postRemoveClientInvite(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->removeClientInvite($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('signin');
        }
    }

    public function postProjectManager(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->project->projectManager($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('signin');
        }
    }

    public function postProjectInvite(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->project->projectInvite($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('signin');
        }
    }

    public function postProjectClientInvite(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->project->projectClientInvite($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('signin');
        }
    }

    public function getAddProject(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->data['totalproject'] = $this->project->getTotalProjects($this->data['companyInfo']->companyid,0);
            //$this->data['projects'] = $this->project->getProjects($this->data['companyInfo']->companyid);
            $this->data['users'] = $this->user->getUsers("");
            $this->data['companyInfo'] = $this->data['companyInfo'];
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['companyInfo']->companyid,$archived);
            if (in_array(1, $this->data['companyInfo']->user_type) || in_array(2, $this->data['companyInfo']->user_type) || Auth::user()->createproject == 1) {
                return view('project.add-project', $this->data);
            } else {
                return redirect('me');
            }
        } else {
            return redirect('signin');
        }
    }

    public function getEditProject(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['teamorclient'] = $this->user->getTeamOrClient($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['users'] = $this->user->getUsers($request->seoname);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($this->data['project']->projectid);
            $this->data['totalinviteclient'] = $this->user->getTotalClientInvite($this->data['project']->projectid);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            $this->data['projectestimates'] = $this->project->getProjectEstimate($this->data['project']->projectid);
            $this->data['tasks'] = $this->task->getTaskByProjectid($this->data['project']->projectid);
            return view('project.edit-project', $this->data);
        } else {
            return redirect('signin');
        }
    }


    public function postProjectArchived(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->archivedProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postProjectDelete(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->deleteProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postProjectUnArchived(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->unArchivedProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postProjectFavourite(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->favouriteProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }


    public function getTodolist(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['labeltasks'] = $this->task->getLabelTaskList($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['inviteuserids'] = $this->user->getInviteUserByPID($this->data['project']->projectid);
            $this->data['allinviteuserids'] = $this->user->getAllInviteUsers($this->data['project']->projectid);
            $this->data['taskduedates'] = $this->task->getTaskDueDate($this->data['project']->projectid);
            //$this->data['labels'] = $this->task->getLabelTaskList($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['completedtodolists'] = $this->task->getCompletedtodolist($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            return view('task.todolist', $this->data);
        } else {
            return redirect('login');
        }
    }


    public function getTodoByLabelSeo(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $this->getCommon($request);
            $archived = 0;
            $this->data['label'] = $this->label->getLabel($request->labelseoname, $this->data['project']->projectid);
            // if (!$this->data['label']) {
            //     $projectHistoryInfo = $this->project->getProjectHistoryByAction($request->labelseoname, 'labeledit');
            //     if (!is_object($projectHistoryInfo)) {
            //         abort(404);
            //     } else {
            //         $this->redirecturl = $request->url();
            //         if (strpos($this->redirecturl, $projectHistoryInfo->oldseoname) !== false) {
            //             $this->redirecturl = str_replace($projectHistoryInfo->oldseoname, $projectHistoryInfo->newseoname, $this->redirecturl);
            //             $this->result = $this->project->getProjectById($projectHistoryInfo->projectid);
            //             if ($this->redirecturl != '') {
            //                 $tempurl = $this->redirecturl;
            //                 unset($this->redirecturl);
            //                 echo '<script type="text/javascript">window.location ="' . $tempurl . '";</script>';
            //             }
            //         }
            //     }
            // } else {
            //     if ($this->data['label']->clientaccess == 1) {
            //         abort(401);
            //     }
            // }
            $this->data['completedtasks'] = $this->task->getCompletedTaskByLabelId($this->data['label']->labelid);
            $this->data['labeltasks'] = $this->task->getTaskByLabelById($this->data['label']->labelid, $this->data['companyInfo']->user_type);
            $this->data['allinviteuserids'] = $this->user->getAllInviteUsers($this->data['project']->projectid);
            $this->data['inviteuserids'] = $this->user->getInviteUserByPID($this->data['project']->projectid);
            $this->data['taskduedates'] = $this->task->getTaskDueDate($this->data['project']->projectid);
            //$this->data['labels'] = $this->task->getLabelTaskList($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['completedtodolists'] = $this->task->getCompletedtodolist($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            $this->data['page'] = 'tld';
            return view('task.todolistdetails', $this->data);
        } else {
            return redirect('login');
        }
    }


    public function getAllUpdates(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            $this->data['allupdates'] = $this->comment->getAllUpdates($this->data['project']->projectid);
            return view('project.allupdates', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getUserAllUpdates(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['companyInfo']->companyid,$archived);
            $this->data['allupdates'] = $this->comment->getUserAllUpdates(base64_decode($request->userid), $this->data['companyInfo']->companyid);
            $this->data['user'] = $this->user->getUser(base64_decode($request->userid));
            return view('project.userallupdates', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getCompletedTodo(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $this->getCommon($request);
            $this->data['completedtodos'] = $this->task->getCompletedTodos($this->data['project']->projectid);
            return view('project.completed-todolist', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getDiscussions(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            $orderBy = "desc";
            $searchQuery = "";
            $limitQuery = "";
            $this->data['discussions'] = $this->task->getProjectDiscussions($this->data['project']->projectid, $searchQuery, $orderBy, $limitQuery);
            return view('task.discussion', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getAjaxDiscussionList(Request $request)
    {
        if (Auth::check()) {
            $orderBy = $request->orderby;
            $searchQuery = ($request->searchtext != "" ? ' and description like "%'.$request->searchtext.'%" ' : ' ');
            $limitQuery = "";
            $this->data['discussions'] = $this->task->getProjectDiscussions($request->projectid, $searchQuery, $orderBy, $limitQuery);
            return view('task.ajaxdiscussion', $this->data);
        } else {
            return redirect('signin');
        }
    }

    public function postSaveProject(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->saveProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postClientAccess(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->clientAccess($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function getTaskDetails(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            
            if ($request->todoseoname == 'add-discussion') {
                //$this->data['project'] = $this->project->getProject($request->projectname, $this->data['companyInfo']->companyid);
                $this->data['inviteusers'] = $this->task->getInviteNotifyUsers(false, $this->data['project']->projectid);
                $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
                return view('task.create_discussion', $this->data);
            } else {
                $result = $this->task->getTask($request, $this->data['project']->projectid);
                if ($result == '') {
                    $projectHistoryInfo = $this->project->getProjectHistoryByAction($request->todoname, 'todomove');
                    if (!is_object($projectHistoryInfo)) {
                        $projectHistoryInfo = $this->project->getProjectHistoryByAction($request->todoname, 'todoedit');
                        if (!is_object($projectHistoryInfo)) {
                            abort(404);
                        } else {
                            $this->redirecturl = $request->url();
                            if (strpos($this->redirecturl, $projectHistoryInfo->oldseoname) !== false) {
                                $this->redirecturl = str_replace($projectHistoryInfo->oldseoname, $projectHistoryInfo->newseoname, $this->redirecturl);
                            }
                            $result = $this->task->getTaskBySeoName($projectHistoryInfo->newseoname);
                            if ($this->redirecturl != '') {
                                $tempurl = $this->redirecturl;
                                unset($this->redirecturl);
                                echo '<script type="text/javascript">window.location ="' . $tempurl . '";</script>';
                                //return redirect($tempurl);
                            }
                        }
                    } else {
                        $this->redirecturl = $request->url();
                        if (strpos($this->redirecturl, $projectHistoryInfo->oldprojectseoname) !== false) {
                            $this->redirecturl = str_replace($projectHistoryInfo->oldprojectseoname, $projectHistoryInfo->newprojectseoname, $this->redirecturl);

                            if (strpos($this->redirecturl, $projectHistoryInfo->oldlabelseoname) !== false) {
                                $this->redirecturl = str_replace($projectHistoryInfo->oldlabelseoname, $projectHistoryInfo->newlabelseoname, $this->redirecturl);
                            }
                            $result = $this->task->getTaskById($projectHistoryInfo->oldprojectstatus);
                            if ($this->redirecturl != '') {
                                $tempurl = $this->redirecturl;
                                unset($this->redirecturl);
                                echo '<script type="text/javascript">window.location ="' . $tempurl . '";</script>';
                                //return redirect($tempurl);
                            }
                        }
                    }
                } else {
                    $this->data['task'] = $result;
                    $this->data['users'] = $this->user->getUsersByPSN($request->seoname);
                    $this->data['comments'] = $this->comment->getCommentList($result->taskid, $this->data['companyInfo']->user_type);
                    $this->data['inviteusers'] = $this->task->getInviteNotifyUsers($result->taskid, $this->data['project']->projectid);
                    $this->data['stoptimeentry'] = $this->task->getStoppedTimeEntry($result->taskid);
                    $request->taskid = $result->taskid;
                    $request->companyid = $this->data['companyInfo']->companyid;
                    $request->delete = 0;
                    $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
                    // $this->comment->viewComment($request);
                    // $this->data['projects'] = $this->report->getProjects($this->data['companyInfo']->companyid, Auth::user()->id);
                    // $this->data['commentviews'] = $this->comment->getCommentView($this->data['companyInfo']->companyid, Auth::user()->id);
                    // $this->data['totalcommentviews'] = $this->comment->getTotalCommentView($this->data['companyInfo']->companyid, Auth::user()->id);
                    // $this->data['totalproject'] = $this->project->getTotalProjects($this->data['companyInfo']->companyid, 0);
                    return view('task.taskdetails', $this->data);
                }
            }
        } else {
            echo '<script type="text/javascript">window.location ="http://sandipanpramanikinfra.com/todooos/signin";</script>';
        }
    }


    public function getTimeEntryReport(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            $this->data['inviteuserids'] = $this->task->getInviteUsers($this->data['project']->projectid);
            $this->data['labeltaskcomments'] = $this->task->getCommentTaskByLabelId($this->data['project']->projectid);
            $this->data['totaltimeentry'] = $this->task->getTotalTimeEntry($this->data['project']->projectid);
            return view('task.timeentryreport', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getTimeEntryReportByRange(Request $request)
    {
        if (Auth::check()) {
            $this->data['labeltaskcomments'] = $this->task->getCommentTaskByRange($request->projectid, $request->startdate, $request->enddate, $request->inviteuserid);
            $this->data['totaltimeentry'] = $this->task->getTotalTimeEntryByRange($request->projectid, $request->startdate, $request->enddate, $request->inviteuserid);
            return view('task.ajaxtimeentryreport', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function postProjectStatus(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->statusProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function getProjectHistory(Request $request)
    {
        if (Auth::check()) {
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['projecthistorys'] = $this->project->getProjectHistory($request->projectid);
            return view('project.ajaxprojecthistory', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function postProjectUpdate(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->projectUpdate($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }
    
}
