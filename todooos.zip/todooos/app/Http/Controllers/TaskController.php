<?php
namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Company;
use App\Models\Label;
//use App\Models\Note;
use App\Models\Project;
//use App\Models\Report;
use App\Models\Task;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Response;
use Session;

class TaskController extends Controller
{
    protected $data = array();
    private $result = '';
    private $redirecturl = '';

    public function __construct(){
        $this->task = new Task;
        $this->project = new Project;
        $this->label = new Label;
        $this->company = new Company;
        $this->user = new User;
        $this->comment = new Comment;

        $this->middleware(function ($request, $next) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
                if(isset($companyInfo->companyid))
                {
                    if($companyInfo->package->days == 'exp'){
                        if ($companyInfo->package->userid == Auth::user()->id){
                            abort(440);
                        }else{
                            abort(441);
                        }
                    }
                    $this->data['commentviews'] = $this->comment->getCommentView($companyInfo->companyid);
                    $this->data['totalcommentviews'] = $this->comment->getTotalCommentView($companyInfo->companyid);
                    $this->data['totalproject'] = $this->project->getTotalProjects($companyInfo->companyid,0);
                }
            }
            return $next($request);
        });
    }

    public function postCompleteTask(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->task->completeTask($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function getEditLabel(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['label'] = $this->label->getLabelById($request->labelid);
            return view('task.editlabel', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function postDeleteLabel(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->label->deleteLabel($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postSaveLabel(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->label->saveLabel($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function getAjaxLabelWPDProject(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($request->projectid);
            $this->data['label'] = $this->label->getLabelById($request->labelid);
            $this->data['labeltasks'] = $this->task->getTaskByLabelById($request->labelid, $this->data['companyInfo']->user_type);
            return view('task.ajaxlabelwpdproject', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getAjaxLabelWTaskList(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($request->projectid);
            $this->data['label'] = $this->label->getLabelById($request->labelid);
            $this->data['labeltasks'] = $this->task->getTaskByLabelById($request->labelid, $this->data['companyInfo']->user_type);
            return view('task.ajaxlabelwtasklist', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getAjaxMasterTodo(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($request->projectid);
            $this->data['label'] = $this->label->getLabelById($request->labelid);
            return view('task.addmastertodo', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getAjaxEditMasterTodo(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($request->projectid);
            $this->data['task'] = $this->task->getTaskById($request->taskid);
            return view('task.editmastertodo', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function postDeleteTask(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->task->deleteTask($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function getTaskAssign(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($request->projectid);
            $this->data['task'] = $this->task->getTaskById($request->taskid);
            return view('task.taskassign', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getAjaxTodolist(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($request->projectid);
            $this->data['labeltasks'] = $this->task->getLabelTaskListByUid($request->projectid, $request->userid, $request->taskduedate, $this->data['companyInfo']->user_type);
            //$this->data['userdetails'] = ($request->userid != 0 ? $this->user->getUser($request->userid) : '');
            return view('task.ajaxtodolist', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getAjaxTodoListDetails(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['completedtasks'] = $this->task->getCompletedTaskByLabelId($request->labelid);
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($request->projectid);
            $this->data['labeltasks'] = $this->task->getTaskByLabelByUid($request->projectid,$request->labelid, $request->userid, $request->taskduedate, $this->data['companyInfo']->user_type);
            $this->data['page'] = 'tld';
            return view('task.ajaxtodolistdetails', $this->data);
        } else {
            return redirect('login');
        }
    }

    
    public function getAjaxTaskList(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($request->projectid);
            $this->data['labeltasks'] = $this->task->getTaskByLabelById($request->labelid, $this->data['companyInfo']->user_type);
            $this->data['label'] = $this->label->getLabelById($request->labelid);
            return view('task.ajaxtasklist', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getAjaxTaskListWOAddTodo(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($request->projectid);
            $this->data['labeltasks'] = $this->task->getTaskByLabelById($request->labelid, $this->data['companyInfo']->user_type);
            return view('task.ajaxtasklistwoaddtodo', $this->data);
        } else {
            return redirect('login');
        }
    }
    

    public function postAssignTask(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->task->assignTask($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('login');
        }
    }

    public function postSaveTask(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            if ($request->mastertask == 1) {
                $returndata = $this->task->saveRepeatTask($request);
            } else {
                $returndata = $this->task->saveTask($request);
            }
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('login');
        }
    }

    public function postEditTask(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->task->editTask($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('login');
        }
    }

    public function postReOpenTask(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->task->reopenTask($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }
    
    public function postDeleteComment(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->comment->commentDelete($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('login');
        }
    }

    public function postSaveComment(Request $request)
    {
        if (Auth::check() || Session::has('invitedNotRegUserId')) {
            $returnData = false;
            $returnData = $this->comment->saveComment($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function getComment(Request $request)
    {
        if (Auth::check() || Session::has('invitedNotRegUserId')) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $result = $this->comment->getComment($request->commentid, $this->data['companyInfo']->user_type);
            $this->data['comments'] = $result;
            return view('task.ajaxtaskdetails', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getLabelList(Request $request)
    {
        if (Auth::check()) {
            $this->data['labels'] = $this->task->getLabelByProjId($request->projectid);
            return view('task.ajaxlabellist', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function postMoveTodo(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->task->moveTodo($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function getCommentHistory(Request $request)
    {
        if (Auth::check() || Session::has('invitedNotRegUserId')) {
            $this->data['task'] = $this->task->getTaskById($request->taskid);
            $this->data['commenthistorys'] = $this->comment->getCommentHistory($request->taskid);
            return view('task.ajaxcommenthistory', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getCommentEdit(Request $request)
    {
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $result = $this->comment->getComment($request->commentid, $this->data['companyInfo']->user_type);
            $this->data['comment'] = $result[0];
            $this->data['task'] = $this->task->getTaskById($this->data['comment']->taskid);
            $this->data['inviteusers'] = $this->task->getInviteNotifyUsers($this->data['comment']->taskid, $this->data['comment']->projectid);
            $this->data['stoptimeentry'] = $this->task->getStoppedTimeEntry($this->data['comment']->taskid);
            return view('task.ajaxcommentedit', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function postUpdateComment(Request $request)
    {
        if (Auth::check() || Session::has('invitedNotRegUserId')) {
            $returnData = false;
            $returnData = $this->comment->updateComment($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postSaveCommentWithDiscussion(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->comment->saveCommentWithDiscussion($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function getMe(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['project5updates'] = $this->task->getProjectsUpdatesByUserId(Auth::user()->id, $this->data['companyInfo']->companyid, "limit 5");
            $this->data['totalfiles'] = $this->comment->getTotalFilesByUserId(Auth::user()->id, $this->data['companyInfo']->companyid);
            $this->data['projectfiles'] = $this->comment->getProjectFilesByUserId(Auth::user()->id, $this->data['companyInfo']->companyid, 'limit 12');
            $this->data['projects'] = $this->task->getProjects($this->data['companyInfo']->companyid, Auth::user()->id);
            $this->data['labeltasks'] = $this->task->getLabelTaskListByUserId($this->data['companyInfo']->companyid,$this->data['companyInfo']->user_type,Auth::user()->id);
            $this->data['taskduedates'] = $this->task->getTaskDueDate($this->data['companyInfo']->companyid, Auth::user()->id);
            // $this->data['allassignuserids'] = $this->report->getAllAssignUsers($this->data['companyInfo']->companyid, Auth::user()->id);
            // if (Session::has('session_changesomeoneInfo')) {
            //     $session_changesomeoneInfo = Session::get('session_changesomeoneInfo');
            //     Session::forget('session_changesomeoneInfo');
            //     $this->data['changeuserInfo'] = $session_changesomeoneInfo;
            // }
            return view('user.me', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getUserMe(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $userId = base64_decode($request->userid);
            if ($userId == Auth::user()->id) {
                return redirect('me');
            }
            $this->data['user'] = $this->user->getUser($userId);
            if (!isset($this->data['user'])) {
                abort(503);
            }
            $this->data['project5updates'] = $this->task->getProjectsUpdatesByUserId($userId, $this->data['companyInfo']->companyid, "limit 5");
            $this->data['totalfiles'] = $this->comment->getTotalFilesByUserId($userId, $this->data['companyInfo']->companyid);
            $this->data['projectfiles'] = $this->comment->getProjectFilesByUserId($userId, $this->data['companyInfo']->companyid, 'limit 12');
            $this->data['projects'] = $this->task->getProjects($this->data['companyInfo']->companyid, $userId);
            $this->data['labeltasks'] = $this->task->getLabelTaskListByUserId($this->data['companyInfo']->companyid,$this->data['companyInfo']->user_type,$userId);
            $this->data['taskduedates'] = $this->task->getTaskDueDate($this->data['companyInfo']->companyid, $userId);
            // if (Session::has('session_changesomeoneInfo')) {
            //     $session_changesomeoneInfo = Session::get('session_changesomeoneInfo');
            //     Session::forget('session_changesomeoneInfo');
            //     $this->data['changeuserInfo'] = $session_changesomeoneInfo;
            // }
            return view('user.userme', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getAjaxPendingTodoList(Request $request)
    {
        if (!$request->ajax()) {
            abort(404);
        }
        if (Auth::check()) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
            }
            $this->data['labeltasks'] = $this->task->getAjaxLabelTaskListByUserId($request, $this->data['companyInfo']->companyid,$this->data['companyInfo']->user_type, Auth::user()->id);
            return view('user.ajaxmetodolist', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function postReadComment(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $request->companyid = $this->data['companyInfo']->companyid;
            $request->userid = Auth::user()->id;
            $returndata = $this->comment->readComment($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('login');
        }
    }

    public function postViewCommentBulk(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $request->userid = Auth::user()->id;
            $returndata = $this->comment->viewCommentBulk($request);
            return response()->json(array('sms' => $returndata));
        } else {
            return redirect('login');
        }
    }

    public function getMySettings(Request $request)
    {
        if($request->ajax())
        {
            abort(503);
        }
        if(Auth::check())
        {
            $this->data['projects'] = $this->task->getProjects($this->data['companyInfo']->companyid, Auth::user()->id);
            return view('user.mysettings', $this->data);
        }
        else
        {
            return redirect('login');
        }
    }

    public function getNeedToTakeCare(Request $request)
    {
        if (Auth::check()) {
            $this->data['needtakecares'] = $this->project->needTakeCare();
            return view('report.needtotakecare', $this->data);
        } else {
            return redirect('login');
        }
    }


    public function getDailyRecap(Request $request)
    {
        if (Auth::check()) {
            $this->data['project5updates'] = $this->project->dailyRecap();
            return view('report.dailyrecap', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function postAddUserPackage(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->task->addUserPackage($request);
        } else {
            return redirect('login');
        }
    }

    public function postAddCompanyProjectStatus(Request $request)
    {
        if (Auth::check()) {
            $returndata = false;
            $returndata = $this->task->addCompanyProjectStatus($request);
        } else {
            return redirect('login');
        }
    }

    
    
}
