var date = new Date();
var currentMonth = date.getMonth();
var currentDate = date.getDate();
var currentYear = date.getFullYear(); 
var ctr = 1;
var editctr = 1;
var weeklytext = " on {!! date('l') !!}";
var dayids = "{!! date('w')!!}";
var dayarray = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thusday", "Friday", "Saturday"];
$(function(){
    $('#timezone').val(tz.name());
    'use strict';
    var fileurl = sitepath + '/upload.php';
    $('form[id^="fileupload-"]').each(function () {
        var formid = $(this).prop('id').replace('fileupload-', '');
        $(this).fileupload({
            dropZone: $('#dropzone-' + formid),
            // dropZone: $('.dropzone')
            url: fileurl,
            dataType: 'json',
            maxFileSize: 2000000000, //2 GB
            maxChunkSize: 1000000, // 5 MB
            autoUpload: true
        }).bind('fileuploadstart', function (e, data) {
            $('button#submitcomment').attr('disabled', 'disabled');
            $('button#submitcomment').text('Uploading...');
        }).bind('fileuploaddone', function (e, data) {
            $('button#submitcomment').removeProp('disabled');
            $('button#submitcomment').text('Add comment');
            //$('#fileupload').formValidation('revalidateField', 'description');
        }).bind('fileuploadfail', function (e,data) {
            var commentFiles = $('input#commentFiles').val();
            if(commentFiles != ''){
                var commentFileArr = commentFiles.split(",");
                $.each(data.files, function (index, file) {
                    //alert('Dropped file: ' + file.name);
                    indexnumber = commentFileArr.indexOf(file.name);
                    if(indexnumber > -1){
                        delete commentFileArr[indexnumber];
                        if(commentFileArr.length == 0){
                            $('input#commentFiles').val('');
                        }else{
                            $('input#commentFiles').val(commentFileArr.join());
                        }
                    }
                });
            }
            $('button#submitcomment').removeProp('disabled');
            $('button#submitcomment').text('Add comment');
        });
    });

    // for drag and drop
    $(document).bind('dragover', function (e) {
        var dropZone = $('.dropzone'),
            foundDropzone,
            timeout = window.dropZoneTimeout;
        var dropZoneId = dropZone.attr('id');
        if (!timeout) {
            $('div#' + dropZoneId).addClass('in')
            //dropZone.addClass('in');
        } else {
            clearTimeout(timeout);
        }
        var found = false,
            node = e.target;

        do {

            if ($(node).hasClass('dropzone')) {
                found = true;
                $(node).addClass('in')
                foundDropzone = $(node);
                break;
            }
            node = node.parentNode;
        } while (node != null);

        dropZone.removeClass('hover');
        if (found) {
            foundDropzone.addClass('hover');
        }
        window.dropZoneTimeout = setTimeout(function () {
            window.dropZoneTimeout = null;
            dropZone.removeClass('in hover');
        }, 100);
    });


    if (!CKEDITOR.instances['description']) {
        CKEDITOR.replace('description', {
                resize_maxWidth: '100%',
                resize_enabled: 'false',
                toolbar: 'MyToolbar',
                startupFocus: true,
                extraPlugins: 'autogrow',
                removePlugins: 'resize',
                height: 150,
                autoGrow_minHeight: 150
            })
            .on('change', function () {
                // Revalidate the bio field
                for (instance in CKEDITOR.instances) {
                    CKEDITOR.instances[instance].updateElement();
                }
                $('#fileupload-0').formValidation('revalidateField', 'description');
            });
    } else {
        CKEDITOR.instances['description'].setData('')
    }
    $(".add-comment").click(function () {
        if (!CKEDITOR.instances['description']) {
            CKEDITOR.replace('description', {
                    resize_maxWidth: '100%',
                    resize_enabled: 'false',
                    toolbar: 'MyToolbar',
                    startupFocus: true,
                    extraPlugins: 'autogrow',
                    removePlugins: 'resize',
                    height: 150,
                    autoGrow_minHeight: 150
                })
                .on('change', function () {
                    // Revalidate the bio field
                    for (instance in CKEDITOR.instances) {
                        CKEDITOR.instances[instance].updateElement();
                    }
                    $('#fileupload-0').formValidation('revalidateField', 'description');
                });
        } else {
            CKEDITOR.instances['description'].setData('')
        }
        $("div#addcomment").show();
        $('html, body').animate({
            scrollTop: $("div#addcomment").offset().top
        }, 1500);
        $("#user-documents-row").hide();
    });

    $(".cancel-comment").click(function () {
        CKEDITOR.instances['description'].setData('')
        CKEDITOR.instances['description'].destroy();
        CKEDITOR.replace('description', {
                resize_maxWidth: '100%',
                resize_enabled: 'false',
                toolbar: 'MyToolbar',
                startupFocus: true,
                extraPlugins: 'autogrow',
                removePlugins: 'resize',
                height: 150,
                autoGrow_minHeight: 150
            })
            .on('change', function () {
                // Revalidate the bio field
                for (instance in CKEDITOR.instances) {
                    CKEDITOR.instances[instance].updateElement();
                }
                $('#fileupload-0').formValidation('revalidateField', 'description');
            });
        $("#addcomment").slideUp(600);
        $("#user-documents-row").slideDown(800);
    });

    $('.timeField').mask('00:00');

    $(".emelcomment-text").click(function () {
        $(this).addClass("nolink");
        $(".commentHide").slideDown();
        $("p#aloopuser").show();
    });

    $("#emelcomment").click(function () {
        $('#emailnamelink').html('');
        $(this).addClass("nolink");
        $(".commentHide").slideDown();
        $("p#aloopuser").show();
    });

    $('a[id^="selectall"]').click(function () {
        $('input[id^="inviteuserid-"]').each(function (index, element) {
            var userid = $(this).prop('id').replace('inviteuserid-', '');
            $('#inviteuserid-' + userid).prop('checked', true);
        });
    });

    $('a[id^="selectnone"]').click(function () {
        $('input[id^="inviteuserid-"]').each(function (index, element) {
            var userid = $(this).prop('id').replace('inviteuserid-', '');
            $('#inviteuserid-' + userid).prop('checked', false);
        });
        // un selecting all
        $("select#rrfuserid").val(null).trigger("change");
    });

    $('p[id^="aloopuser"]').click(function () {
        $('#divloopemail').show();
    });

    $(".js-example-basic-single-rrfuserid").select2({
        placeholder: "Request respons from",
        tokenSeparators: [',']
    });

    $(".js-example-basic-single-loopemails").select2({
        placeholder: "The person you select will be notified by email",
        tokenSeparators: [',']
    });

    $('input[id^="taskcomplete-"]').click(function () {
        var taskid = $(this).prop('id').replace('taskcomplete-', '');
        var status = '';
        var msg = "Are you sure you want to "+($(this).prop('checked') == true ? 'complete' : 're-open')+" this to-do?";
        if (confirm(msg)) {
            status = ($(this).prop('checked') == true ? '1' : '0');
            var arg = 'taskid=' + taskid + '&status=' + status;
            $.ajax({
                url: sitepath + (status == 1 ? "/task/complete" : "/task/reopen"),
                type: "POST",
                dataType: 'html',
                data: arg,
                timeout: 20000,
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                cache: false,
                success: function (html) {
                    var nhtml = html.sms;
                    if (parseInt(nhtml) == 2) {
                        alert("This to-do is already compleeted.");
                    }
                    setTimeout('window.location.reload()', 10);
                    return false;
                }
            });
        } else {
            ($(this).prop('checked') == true ? $(this).prop('checked', false) : $(this).prop('checked', true));
        }
    });

    $('div#todopost').on('click','a[id^="deletecomment-"]',function(){     
        var commentid = $(this).prop('id').replace('deletecomment-', '');
        var msg = "Are you sure you want to delete this comment?";
        if (confirm(msg)) {
            var arg = 'commentid=' + commentid + '&status=1';
            $.ajax({
                url: sitepath + "/comment/deletecomment/"+commentid,
                type: "POST",
                data: arg,
                timeout: 20000,
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                cache: false,
                success: function (html) {
                    var nhtml = html.sms;
                    if (nhtml == 1) {
                        $('div#deletecom-' + commentid).hide();
                        setTimeout('$.unblockUI()', 1000);
                    }
                    return false;
                }
            });
        }
    });

    $('div#todopost').on('click','a[id^="editcomment-"]',function(){     
        commentid = $(this).prop('id').replace('editcomment-', '');
        var arg = 'commentid=' + commentid;
        $.ajax({
            url: sitepath+"/comment/commentedit/"+commentid,
            type: "POST",
            data: arg,
            timeout: 20000,
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            cache: false,
            success: function(html)
            {
                $('div#ajaxeditcomment-'+commentid).html(html).slideDown(400);
                $('div#deletecom-'+commentid).slideUp(300);
            }
        });
    });


    $('div#todopost').on('click','button[id^="cancelcomment-"]',function(){     
        var commentid = $(this).prop('id').replace('cancelcomment-', '');
        $('div#ajaxeditcomment-'+commentid).html('').slideUp(300);
        $('div#deletecom-'+commentid).slideDown(300);
    });

    $('div#todopost').on('click','span[id^="commentfile-"]',function(){     
        var fileid = $(this).prop('id').replace('commentfile-', '');
        fileid = fileid.split('|');
        if ($('input#fileids-' + fileid[1]).val() == '') {
            $('input#fileids-' + fileid[1]).val(fileid[0]);
        } else {
            $('input#fileids-' + fileid[1]).val(fileid[0] + ',' + $('input#fileids-' + fileid[1]).val());
        }
        $('div#filedelete-' + fileid[0]).html('');
    });

    if (timeentry == 1) {
        $('#fileupload-0')
            .formValidation({
                framework: 'bootstrap',
                excluded: [':disabled'],
                icon: {
                    valid: 'fas fa-check',
                    invalid: 'fas fa-times',
                    validating: 'fas fa-sync-alt'
                },
                fields: {
                    description: {
                        validators: {
                            notEmpty: {
                                message: 'The comment is required and cannot be empty'
                            }
                        }
                    },
                    'loopemails[]': {
                        validators: {
                            callback: {
                                message: 'The input is not a valid email address',
                                callback: function (value, validator, $field) {
                                    // Get the selected options
                                    var options = validator.getFieldElements('loopemails[]').val();
                                    return validateEmails(options);
                                    //return (options != null && options.length >= 2 && options.length <= 3);
                                }
                            }
                        }
                    },
                    working_time: {
                        validators: {
                            notEmpty: {
                                message: 'The time entry is required'
                            },
                            regexp: {
                                regexp: /^(00|01|02|03|04|05|06|07|08|09|10|11|12|[1-9]):[0-5][0-9]$/,
                                message: 'The time entry is not valid time.'
                            }
                        }
                    }
                }
            })
            .on('success.form.fv', function (e) {
                e.preventDefault();
                var arg = $("form#fileupload-0").serialize();
                $.ajax({
                    url: sitepath + "/comment/save",
                    type: "POST",
                    data: arg,
                    timeout: 20000,
                    cache: false,
                    success: function (html) {
                        var nhtml = html.sms;
                        if (parseInt(nhtml) >= 1) {
                            //$('div#msgdivcomment').prop('class','successmsg');
                            //$('div#msgdivcomment').html('Comment addition successfully done.');
                            var arg = 'commentid=' + nhtml;
                            $.ajax({
                                url: sitepath + "/comment/" + nhtml,
                                type: "POST",
                                data: arg,
                                timeout: 20000,
                                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                                cache: false,
                                success: function (html) {
                                    $('#ajaxcomment').append(html);
                                    $('input#submitcomment').removeProp('disabled');
                                    $('input#submitcomment').removeClass('disabled');
                                    $('#progress').hide();
                                    $('div#files').html('');
                                    $("div#addcomment").slideUp(300);
                                    CKEDITOR.instances['description'].setData('')
                                    CKEDITOR.instances['description'].destroy();
                                    $(".files").html('');
                                    $("#commentFiles").val('');
                                    $("#working_time").val('00:00');
                                    $("#user-documents-row").slideDown(300);
                                    //$(".add-comment").click();
                                }
                            });
                        } else {
                            $('div#msgdivcomment').prop('class', 'errormsg');
                            $('div#msgdivcomment').html('Comment update failed. Sorry for the inconvenience');
                        }
                        $('div#msgdivcomment').fadeIn(100);
                        var et = setTimeout('$("div#msgdivcomment").fadeOut(100)', 5000);
                        return false;
                    }
                });
            });
    } else {
    $('#fileupload-0')
        .formValidation({
            framework: 'bootstrap',
            excluded: [':disabled'],
            icon: {
                valid: 'fas fa-check',
                invalid: 'fas fa-times',
                validating: 'fas fa-sync-alt'
            },
            fields: {
                description: {
                    validators: {
                        notEmpty: {
                            message: 'The comment is required and cannot be empty'
                        }
                    }
                },
                'loopemails[]': {
                    validators: {
                        callback: {
                            message: 'The input is not a valid email address',
                            callback: function (value, validator, $field) {
                                // Get the selected options
                                var options = validator.getFieldElements('loopemails[]').val();
                                return validateEmails(options);
                                //return (options != null && options.length >= 2 && options.length <= 3);
                            }
                        }
                    }
                }
            }
        })
        .on('success.form.fv', function (e) {
            e.preventDefault();
            var arg = $("form#fileupload-0").serialize();
            $.ajax({
                url: sitepath + "/comment/save",
                type: "POST",
                data: arg,
                timeout: 20000,
                cache: false,
                success: function (html) {
                    var nhtml = html.sms;
                    if (parseInt(nhtml) >= 1) {
                        //$('div#msgdivcomment').prop('class','successmsg');
                        //$('div#msgdivcomment').html('Comment addition successfully done.');
                        var arg = 'commentid=' + nhtml;
                        $.ajax({
                            url: sitepath + "/comment/" + nhtml,
                            type: "POST",
                            data: arg,
                            timeout: 20000,
                            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                            cache: false,
                            success: function (html) {
                                $('#ajaxcomment').append(html);
                                $('input#submitcomment').removeProp('disabled');
                                $('input#submitcomment').removeClass('disabled');
                                $('#progress').hide();
                                $('div#files').html('');
                                $("div#addcomment").slideUp(300);
                                CKEDITOR.instances['description'].setData('')
                                CKEDITOR.instances['description'].destroy();
                                $(".files").html('');
                                $("#commentFiles").val('');
                                $("#working_time").val('00:00');
                                $("#user-documents-row").slideDown(300);
                                //$(".add-comment").click();
                            }
                        });
                    } else {
                        $('div#msgdivcomment').prop('class', 'errormsg');
                        $('div#msgdivcomment').html('Comment update failed. Sorry for the inconvenience');
                    }
                    $('div#msgdivcomment').fadeIn(100);
                    var et = setTimeout('$("div#msgdivcomment").fadeOut(100)', 5000);
                    return false;
                }
            });
        });
    }

    $('div#commentIcons').on('click', 'a[id^="deletetodo-"]', function () {
        var taskinfo = $(this).prop('id').replace('deletetodo-', '');
        var taskinfoarr = taskinfo.split('|');
        var msg = "Are you sure you want to delete this to-do?";
        if (confirm(msg)) {
          var arg = 'taskid=' + taskinfoarr[0];
          $.ajax({
            url: sitepath + "/task/delete",
            type: "POST",
            data: arg,
            timeout: 20000,
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            cache: false,
            success: function (html) {
              var nhtml = html.sms;
              if (nhtml == 1) {
                setTimeout('window.location="'+sitepath+'/project/'+psn+'"',10);
              }
              return false;
            }
          });
        }
        return false;
      });

      $('div#commentIcons').on('click', 'a[id^="edittodo"]', function (){  
        $('div#todoeditpopup').show();
      });

      $('div[id^="todoeditclosepop"]').click(function () {
        $('div#todoeditpopup').hide();
      });
  
      $('a[id^="closeeditpopup"]').click(function () {
        $('div#todoeditpopup').hide();
      });

      $('form#frmtaskedit').formValidation({
        framework: 'bootstrap',
        message: 'This value is not valid',
        icon: {
            valid: 'fas fa-check',
            invalid: 'fas fa-times',
            validating: 'fas fa-sync-alt'
        },
        fields: {
          taskname: {
            validators: {
              notEmpty: {
                message: 'The to-do name is required'
              }
            }
          }
        }
      })
      .on('success.form.fv', function (e) {
        // Prevent form submission
        e.preventDefault();
        var arg = $('form#frmtaskedit').serialize();
        var taskid = $('input#taskid').val();
        loadingcontent ='<i class="fa fa-spinner fa-pulse fa-2x fa-fw"></i><span class="sr-only">Loading...</span>';
        $("span#loader-" + taskid).html(loadingcontent);
        $("span#loader-" + taskid).show();
        //alert(arg);
        $.ajax({
          url: sitepath + "/task/edit",
          type: "POST",
          data: arg,
          timeout: 20000,
          cache: false,
          success: function (html) {
            var nhtml = html.sms;
            if (parseInt(nhtml) == "2") {
                $('div#msgtodorename').prop('class', 'successmsg');
                $('div#msgtodorename').html('To-do update successfuly done.');
                $('div#msgtodorename').fadeIn(100);
                var et = setTimeout('$("div#msgtodorename").fadeOut(100)', 3000);
                setTimeout('window.location="' + sitepath + '/project/' + psn + '"', 2000);
            } else {
              $('div#msgtodorename').prop('class', 'errormsg');
              $('div#msgdivtask').html('To-do update failed. Sorry for the inconvenience');
            }
            return false;
          }
        });
      });


      $('div#commentIcons').on('click', 'a[id^="movetodo"]', function (){  
        $('div#todomovepopup').show();
      });

      $('div[id^="todomoveclosepop"]').click(function () {
        $('div#todomovepopup').hide();
      });
  
      $('a[id^="closemovepopup"]').click(function () {
        $('div#todomovepopup').hide();
      });

      $(".js-example-tokenizerprojects").select2({
        placeholder: "Choose a project…"
      });

      $(".js-example-tokenizertodolist").select2({
        placeholder: "Choose a todolist…"
      });

      $('select#moveprojectid').change(function () {
        var projectid = $(this).val();
        var arg = '';
        $.ajax({
            url: sitepath + "/label/" + projectid,
            type: "GET",
            data: arg,
            timeout: 20000,
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            cache: false,
            success: function (html) {
                if (html) {
                    $('div#movetodolist').show();
                    $('select#movelabelid').html(html);
                }
                return false;
            }
        });
    });

    $('form#frmtodomove').formValidation({
        framework: 'bootstrap',
        excluded: [':disabled'],
        icon: {
            valid: 'fas fa-check',
            invalid: 'fas fa-times',
            validating: 'fas fa-sync-alt'
        },
        fields: {
            moveprojectid: {
                validators: {
                    notEmpty: {
                        message: 'The project name is required'
                    }
                }
            },
            movelabelid: {
                validators: {
                    notEmpty: {
                        message: 'The to-do list name is required'
                    }
                }
            }
        }
    })
    .on('success.form.fv', function (e) {
        e.preventDefault();
        var arg = $('form#frmtodomove').serialize();
        var taskid = $('input#movetaskid').val();
        loadingcontent ='<i class="fa fa-spinner fa-pulse fa-2x fa-fw"></i><span class="sr-only">Loading...</span>';
        $("span#loader-" + taskid).html(loadingcontent);
        $("span#loader-" + taskid).show();
        $.ajax({
            url: sitepath + "/task/movetodo",
            type: "POST",
            data: arg,
            timeout: 20000,
            cache: false,
            success: function (html) {
                var nhtml = html.sms;
                var newhtml = nhtml.split('|');
                if (parseInt(newhtml[0]) == "1") {
                    $("select#moveprojectid").val('').trigger('change');
                    $('div#movetodolist').hide();
                    $('div#divmovetodo').hide();

                    $('div#overlaydiv').block({
                        message: '<h4>You have successfully move this todo.</h3><br><h4>' +newhtml[1] + '</h4>',
                        centerY: false,
                        css: {
                            border: '3px solid #a00',
                            padding: '10px',
                            top: '50px'
                        }
                    });
                } else {
                    $('div#msgmovetodo').prop('class', 'errormsg');
                    $('div#msgmovetodo').html('To-do move failed. Sorry for the inconvenience');
                    $('div#msgmovetodo').fadeIn(100);
                    var et = setTimeout('$("div#msgmovetodo").fadeOut(100)', 5000);
                }
                return false;
            }
        });
    });

    $('a[id^="commenthistory-"]').click(function () {
        var taskid = $(this).prop('id').replace('commenthistory-', '');
        var arg = "taskid=" + taskid;
        $.ajax({
            url: sitepath + "/task/commenthistory",
            type: "POST",
            data: arg,
            timeout: 20000,
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            cache: false,
            success: function (html) {
                $('.history').html(html);
                $('.history').toggle();
                return false;
            }
        });
    });

    $('div#overlaydiv').on('click', 'a[id^="uname-"]', function (){  
        var taskid = $(this).prop('id').replace('uname-', '');
        var arg = 'taskid=' + taskid + '&projectid=' + pid;
        $.ajax({
          url: sitepath + "/task/taskassign",
          type: "POST",
          data: arg,
          timeout: 20000,
          headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
          cache: false,
          success: function (html) {
            $('div#ajaxtaskassign-'+taskid).show(); 
            $('div#ajaxtaskassign-'+taskid).html(html);
            $(".js-example-basic-single-new-"+taskid).select2({
              placeholder: "The person you select will be notified by email"
            });
            
            $('#datetimepickerpop-'+taskid).datetimepicker({
              inline: true,
              sideBySide: true,
              format : 'LL',
              extraFormats: [ 'DD/MM/YY' ],
              minDate: new Date(currentYear, currentMonth, currentDate)
            }).on('dp.change', function(event) {
              var formatted_date = event.date.format('MMM DD, YYYY');
              $('#assigndate-'+taskid).val(formatted_date);
            });
          }
        });
    });

    $('div#overlaydiv').on('click', 'input[id^="cancel-assign-"]', function (){ 
        var taskid = $(this).prop('id').replace('cancel-assign-','');
        $('div#ajaxtaskassign-'+taskid).hide();
      });

      $('div#overlaydiv').on('click', 'div[id^="popoverBoxClose-"]', function (){ 
        var taskid = $(this).prop('id').replace('popoverBoxClose-','');
        $('div#ajaxtaskassign-'+taskid).hide();
      });
      
      $('div#overlaydiv').on('click', 'a[id^="no-due-date-"]', function (){ 
        var id = $(this).prop('id').replace('no-due-date-','');
        $("#assigndate-"+id).val('');
      });

      $('div#overlaydiv').on('click', 'input[id^="submitassign-"]', function () {
        var taskid = $(this).prop('id').replace('submitassign-', '');
        $('form#frmassign-' + taskid).formValidation({
        framework: 'bootstrap',
        excluded: [':disabled'],
        icon: {
            valid: 'fas fa-check',
            invalid: 'fas fa-times',
            validating: 'fas fa-sync-alt'
        },
          fields: {
            'emailpop[]': {
              validators: {
                callback: {
                    message: 'The input is not a valid email address',
                    callback: function(value, validator, $field) {
                        // Get the selected options
                        var options = validator.getFieldElements('emailpop[]').val();
                        return validateEmails(options);
                        //return (options != null && options.length >= 2 && options.length <= 3);
                    }
                }
            }
            }
          }
          })
          .on('success.form.fv', function (e) {
            // Prevent form submission
            e.preventDefault();
            labelid = $("#labelassignid-" + taskid).val();
            var arg = $('form#frmassign-' + taskid).serialize();
            loadingcontent ='<i class="fa fa-spinner fa-pulse fa-2x fa-fw"></i><span class="sr-only">Loading...</span>';
            $("span#loader-" + taskid).html(loadingcontent);
            $("span#loader-" + taskid).show();
            //alert(arg);
            $.ajax({
              url: sitepath + "/task/assign",
              type: "POST",
              data: arg,
              timeout: 20000,
              cache: false,
              success: function (html) {
                var nhtml = html.sms;
                if (parseInt(nhtml) == "1") {
                  var et = setTimeout('window.location.reload(true)', 5000);
                }
                return false;
              }
            });
          });
      });
    
});


function validateEmails(emails) {
    var email_regex = /^[a-zA-Z0-9._-]+@([a-zA-Z0-9.-]+\.)+[a-zA-Z0-9.-]{2,4}$/;
    //var res = emails.split(',');
    if (emails == null)
        return true;
    for (i = 0; i < emails.length; i++) {
        if (!email_regex.test(emails[i]))
            return false;
    }
    return true;
}

function checkiconfile(iconfilename) {
    $.ajax({
        url: sitepath + "/public/images/iconimg/" + iconfilename,
        success: function (data) {
            found = true;
        },
        error: function (data) {
            found = false;
        }
    });
}
function discussionlist(){
    var orderby = $('select#orderby').val();
    var searchtext = ($('input#searchtext').val() != '' ? $('input#searchtext').val() : '' );
    var arg = 'projectid='+pip+'&orderby='+orderby+'&searchtext='+searchtext;
    //alert(arg);
    $.ajax({
        url: sitepath + "/project/ajaxdiscussionlist",
        type: "POST",
        data: arg,
        timeout: 20000,
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
        cache: false,
        beforeSend: function()
        {
            $("div#ajaxdiscussionlist").html('');
            $('div.ajax-loading').show();
        }
    })
    .done(function(html)
    {
        if(html == ""){
            $('div.ajax-loading').html("No records found");
            return;
        }else{
            $('div.ajax-loading').hide();
            $("div#ajaxdiscussionlist").html(html);
        }
    })
    .fail(function(jqXHR, ajaxOptions, thrownError)
    {
        alert('server not responding...');
    });
}