/*notification sidebar*/
$(function(){
	 $('.sidebarIcon').click(function(){
		 $('.sideBarArea').addClass('sideBarAreaAdd')
	 });
	 $('.sideBarBoxAreaClose').click(function(){
		 $('.sideBarArea').removeClass('sideBarAreaAdd')
	 });
});


/*notification sidebar End*/

/*Search*/
$(function(){
	 $('#SearchBtn').click(function(){
		 $('.serachBar').fadeIn();
		 $('input#headerSearch').focus();
	 });
	 $('.searchClose').click(function(){
		 $('.serachBar').fadeOut();
	 });
});
/*Search End*/

/*project sidebar*/
$(function(){
	
	 $('.projectMenuBtn').click(function(){
		if(leftpanel == 1){
			leftpanel = 2;
		}else{
			leftpanel = 1;
		}
		var arg='leftpaneltype='+leftpanel+'&id='+uid;
		$.ajax({
				url: sitepath+"/user/setleftpaneltype",
				type: "POST",
				data: arg,
				timeout: 20000,
				headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
				cache: false,
				success: function(html)
				{
					var nhtml = html.sms;
					if(parseInt(nhtml) == 1)
					{
						$('.projectSidebar').toggleClass('projectSidebarAdd');
		 				$('.projectDetailsBg').toggleClass('projectDetailsBgAdd');
					}
					return false;
				}
			});
		 
	 });
	 $('.projectSidebarClose').click(function(){
		 $('.projectSidebar').removeClass('projectSidebarAdd');
	 });
	 $('input.number').keypress(function(event){
		//alert(event.which);
		if(event.which === 8 || event.keyCode === 9 || event.keyCode === 37 || event.keyCode === 39)
		{
				return true;
		}
		else if(event.which < 48 || event.which > 57)
		{
				event.preventDefault();
		}
	});

	$('input.decimal').keypress(function(event){
		var inputarr = $(this).val().split('.');
		if(event.which === 8 || event.keyCode === 9 || event.keyCode === 37 || event.keyCode === 39 || event.keyCode === 46)
		{
				
				return true;
		}
		else if((event.which !== 46 || $(this).val().indexOf('.') !== -1) && (event.which < 48 || event.which > 57))
		{
				event.preventDefault();
		}
		else if(inputarr[1]!='undefined' && inputarr[1]!=null && inputarr[1].length >= 2)
		{
				event.preventDefault();
		}
	});
});

$(window).resize(function(){
       if ($(window).width() <= 1199) {  
           $('.projectSidebar').removeClass('projectSidebarAdd');
		   $('.projectDetailsBg').removeClass('projectDetailsBgAdd');
       } 
	//    else{
	// 		if(leftpanel == 1){
	// 			$('.projectSidebar').addClass('projectSidebarAdd');
	// 			$('.projectDetailsBg').addClass('projectDetailsBgAdd');
	// 		}else if(leftpanel == 2){
	// 			$('.projectSidebar').removeClass('projectSidebarAdd');
	// 			$('.projectDetailsBg').removeClass('projectDetailsBgAdd');
	// 		}
	//    }    
});
$(window).load(function(){
       if ($(window).width() <= 1199) {  
           $('.projectSidebar').removeClass('projectSidebarAdd');
		   $('.projectDetailsBg').removeClass('projectDetailsBgAdd');
       } 
	//    else{
	// 		if(leftpanel == 1){
	// 			$('.projectSidebar').addClass('projectSidebarAdd');
	// 			$('.projectDetailsBg').addClass('projectDetailsBgAdd');
	// 		}else if(leftpanel == 2){
	// 			$('.projectSidebar').removeClass('projectSidebarAdd');
	// 			$('.projectDetailsBg').removeClass('projectDetailsBgAdd');
	// 		}
	//    }    
});

$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('.projectSidebar').addClass('projectSidebarAdd2')
    } else {
        $('.projectSidebar').removeClass('projectSidebarAdd2')
    }
});

/*project sidebar End*/

/*Extension of select2 start*/

$.fn.cloneSelect2 = function (withDataAndEvents, deepWithDataAndEvents) {
	var $oldSelects2 = this.is('select') ? this : this.find('select');
	$oldSelects2.select2('destroy');
	var $clonedEl = this.clone(withDataAndEvents, deepWithDataAndEvents);
	$oldSelects2.select2();
	$clonedEl.is('select') ? $clonedEl.select2() : $clonedEl.find('select').select2();
	return $clonedEl;
};

/*Extension of select2 end*/