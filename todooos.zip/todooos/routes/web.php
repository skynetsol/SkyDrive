<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'LoginController@getSignUp');
Route::get('/signup', 'LoginController@getSignUp');
Route::get('/signin', ['uses' => 'LoginController@getSignIn']);
Route::get('/login', ['uses' => 'LoginController@getSignIn']);
Route::get('/logout', 'LoginController@getLogout');
Route::post('/signinpost', ['uses' => 'LoginController@postSignIn']);
Route::get('/forgotpassword', 'LoginController@getForgotPassword');
Route::post('/user/forgotpasswordpost', 'LoginController@postForgotPassword');
Route::get('/resetpassword/{keycode}', 'UserController@getResetPassword');
Route::post('/company/save', ['uses' => 'CompanyController@postSaveCompany']);
Route::get('/register/confirm/{confirmation_code}', 'UserController@getConfirmUser');
Route::get('/register/confirmation/{confirmation_code}', 'UserController@getConfirmationUser');
Route::get('/register/success', 'UserController@getSuccessUser');
Route::get('/checkactivity/{keycode}', 'UserController@getCheckActivity');
Route::get('/securityalert/{keycode}', 'UserController@getSecurityAlert');
Route::get('/securitycheckup/{keycode}', 'UserController@getSecurityCheckup');
Route::post('/checkup/removelog', ['uses' => 'UserController@postLogRemoved']);
Route::get('/companynotexists', 'CompanyController@getCompanyNotExists');


//For Company
Route::group(['middleware' => ['web']], function ()
{
    Route::get('/choose-company', 'UserController@getCompanyList');

    Route::post('/company/setcompany', ['uses' => 'UserController@postSetCompany']);

    Route::get('/paypal-settings', 'CompanyController@getPaypalSettings');
    Route::post('/user/savepaypal', ['uses' => 'UserController@postSavePaypal']);
    Route::post('/company/saveautorenew', ['uses' => 'CompanyController@postSaveAutorenew']);
    Route::get('/manage-account', 'CompanyController@getManageAccount');
    Route::get('/project-status', 'CompanyController@getProjectStatus');
    Route::post('/company/saveprojectstatus', ['uses' => 'CompanyController@postUpdateProjectStatus']);
    Route::get('/add-someone', 'CompanyController@getAddSomeone');
    Route::post('/company/savesomeone', ['uses' => 'CompanyController@postSaveSomeone']);
    Route::get('/change-whateuser', 'CompanyController@getChangeWhateUser');
    Route::post('/company/changewhatuser', ['uses' => 'CompanyController@postChangeWhatUser']);
    Route::get('/remove-someone', 'CompanyController@getRemoveSomeone');
    Route::post('/company/removesomeone', ['uses' => 'CompanyController@postRemoveSomeone']);
    Route::get('/edit-someone', 'CompanyController@getEditSomeone');
    Route::post('/company/editsomeone', ['uses' => 'CompanyController@postEditSomeone']);
    Route::get('/edit-user', 'CompanyController@getEditUser');
    Route::post('/company/editsomeoneuser', ['uses' => 'CompanyController@postEditUser']);
    Route::get('/change-someone', 'CompanyController@getChangeSomeone');
    Route::post('/company/changesomeoneaccess', ['uses' => 'CompanyController@postChangeSomeoneAccess']);
    Route::get('/usersuperpowers', 'CompanyController@getUserSuperpowers');
    Route::post('/company/usersuperpowers', ['uses' => 'CompanyController@postUserSuperPowers']);
    Route::get('/move-someone', 'CompanyController@getMoveSomeone');
    Route::post('/company/movesomeone', ['uses' => 'CompanyController@postMoveSomeone']);
    Route::get('/change-whichorg', 'CompanyController@getChangeWhichorg');
    Route::post('/company/changewhichorg', ['uses' => 'CompanyController@postChangeWhichorg']);
    Route::get('/setwhoelseisanadministrator', 'CompanyController@getSetWhoElseIsAnAdministrator');
    Route::post('/company/removeadministratorrole', ['uses' => 'CompanyController@postRemoveAdministratorRole']);
    Route::post('/company/addadministratorrole', ['uses' => 'CompanyController@postAddAdministratorRole']);
    Route::get('/setwhoelseisanaccountowner', 'CompanyController@getSetWhoElseIsAnAccountOwner');
    Route::post('/company/removeaccountownerrole', ['uses' => 'CompanyController@postRemoveAccountOwnerRole']);
    Route::post('/company/addaccountownerrole', ['uses' => 'CompanyController@postAddAccountOwnerRole']);
    Route::get('/accessanyproject', 'CompanyController@getAccessAnyProject');
    Route::get('/rename-organization', 'CompanyController@getRenameOrganization');
    Route::post('/company/update', ['uses' => 'CompanyController@postUpdateCompany']);
    Route::get('/exportyourdata', 'CompanyController@getExportYourData');
    Route::get('/buyandupgrade', 'UserController@getBuyAndUpgrade');
    Route::post('/setpaymentmethod', 'PaymentController@setPaymentMethod');
    Route::get('/payment-method', 'PaymentController@getPaymentMethod');
    Route::post('/payment/checkout', 'PaymentController@postPayment');
    Route::post('/payment/wait', 'PaymentController@getPaymentWait');
    Route::get('/payment/thankyou', 'PaymentController@getPaymentThankyou');
    Route::get('/payment/makepayment', 'PaymentController@getMakePayment');

    Route::get('/cancel-account', 'CompanyController@getCancelThisAccount');
    
    Route::get('/needtotakecare', 'TaskController@getNeedToTakeCare');
    Route::get('/daily-recap', 'TaskController@getDailyRecap');
});

//For User
Route::group(['middleware' => ['web']], function ()
{
    Route::get('/profile', 'UserController@getProfile');
    Route::post('/updateprofile', 'UserController@postUpdateProfile');
    Route::post('/changepass', 'UserController@postChangePassword');
    Route::post('/user/resetpasswordpost', 'UserController@postResetPassword');
    Route::post('/user/setlistingtype', 'UserController@postListingType');
    Route::post('/user/setleftpaneltype', 'UserController@postLeftPanelType');
    Route::get('/mysettings', 'TaskController@getMySettings');
    Route::get('/everyone', 'CompanyController@getEveryone');
    Route::get('/user/{userid}', 'TaskController@getUserMe');
    Route::post('/user/projectnotification', 'UserController@postProjectNotification');
    Route::post('/user/editemail', 'UserController@postEditEmail');
    Route::post('/user/completetodo', 'UserController@postCompleteTodo');
    Route::post('/user/dailyrecap', 'UserController@postDailyRecap');
    Route::post('/user/needtakecare', 'UserController@postNeedTakeCare');
    Route::post('/user/eachitemrightaway', 'UserController@postEachItemRightAway');
    Route::post('/user/notifiedproject', 'UserController@postNotifiedProject');
    Route::get('/user/{userid}/all-updates', 'ProjectController@getUserAllUpdates');
    

    Route::get('/progress', 'TaskController@getProgress');
    Route::post('/ajaxprogress', 'TaskController@getAjaxProgress');
});

//For project
Route::group(['middleware' => ['web']], function ()
{
    Route::get('/projects', 'ProjectController@getProjectList');
    Route::post('/project/ajaxprojectlist', 'ProjectController@getAjaxProjectList');
    Route::get('/archived-projects', 'ProjectController@getArchivedProjects');
    Route::post('/project/ajaxarchivedprojectlist', 'ProjectController@getAjaxArchivedProjectList');
    Route::get('/project/{seoname}', ['as' => 'project', 'uses' => 'ProjectController@getProjectDetails']);
    Route::get('/project/{seoname}/all-updates', 'ProjectController@getAllUpdates');
    Route::get('/project/{seoname}/invite', 'ProjectController@getInvite');
    Route::post('/project/removeinvite', 'ProjectController@postRemoveInvite');
    Route::post('/project/removeclientinvite', 'ProjectController@postRemoveClientInvite');
    Route::post('/project/manager', 'ProjectController@postProjectManager');
    Route::post('/project/invitation', 'ProjectController@postProjectInvite');
    Route::post('/project/clientinvitation', 'ProjectController@postProjectClientInvite');
    Route::get('/add-project', 'ProjectController@getAddProject');
    Route::get('/project/{seoname}/edit', 'ProjectController@getEditProject');
    Route::post('/project/save', 'ProjectController@postSaveProject');
    Route::post('/project/archived', 'ProjectController@postProjectArchived');
    Route::post('/project/delete', 'ProjectController@postProjectDelete');
    Route::post('/project/favourite', 'ProjectController@postProjectFavourite');
    Route::post('/project/clientaccess', 'ProjectController@postClientAccess');
    Route::get('/project/{seoname}/discussion', 'ProjectController@getDiscussions');
    Route::post('/project/ajaxdiscussionlist', 'ProjectController@getAjaxDiscussionList');
    Route::get('/project/{seoname}/time-entry-report', 'ProjectController@getTimeEntryReport');
    Route::post('/project/{seoname}/ajaxtimeentryreport', 'ProjectController@getTimeEntryReportByRange');
    Route::post('/project/updateprojectstatus', 'ProjectController@postProjectStatus');
    Route::post('/project/projecthistory', 'ProjectController@getProjectHistory');
    Route::post('/project/projectedit', ['uses' => 'ProjectController@postProjectUpdate']);
    
    //project files
    Route::get('/project/{seoname}/files', 'ProjectController@getFileList');
    Route::post('/project/ajaxfilelist', 'ProjectController@getAjaxFileList');
    Route::post('/project/file/delete', 'ProjectController@postDeleteFile');

    //project notes
    Route::get('/project/{seoname}/notes', 'ProjectController@getNotes');
    Route::get('/project/{seoname}/add-note', 'ProjectController@getAddNote');
    Route::post('/note/save', 'ProjectController@postSaveNote');
    Route::get('/project/{seoname}/note/{noteseoname}', 'ProjectController@getEditNote');
    Route::post('/note/copynote', 'ProjectController@postNoteCopy');
    Route::post('/note/deletenote', 'ProjectController@postNoteDelete');
    Route::post('/note/protect', 'ProjectController@postProtectNote');
    Route::get('/project/{seoname}/note/{noteseoname}/share', 'ProjectController@getShareNote');
    Route::post('/note/renamenote', 'ProjectController@postNoteRename');
    Route::post('/note/sharenote', 'ProjectController@postNoteShare');
    Route::post('/note/removeshare', 'ProjectController@postRemoveNoteShare');
});

//For To-do
Route::group(['middleware' => ['web']], function ()
{
    //To-do list
    Route::get('/project/{seoname}/todolist', 'ProjectController@getTodolist');
    Route::get('/project/{seoname}/todolist/{labelseoname}', 'ProjectController@getTodoByLabelSeo');
    Route::post('/label/editlabel', 'TaskController@getEditLabel');
    Route::post('/label/save', 'TaskController@postSaveLabel');
    Route::post('/label/ajaxlabelwpdproject', 'TaskController@getAjaxLabelWPDProject');
    Route::post('/label/ajaxtodolist', 'TaskController@getAjaxTodolist');
    Route::post('/label/ajaxtodolistdetails', 'TaskController@getAjaxTodoListDetails');
    Route::get('/label/{projectid}', 'TaskController@getLabelList');
    //One Time
    Route::get('/adduserpackage', 'TaskController@postAddUserPackage');
    Route::get('/addcompanyprojectstatus', 'TaskController@postAddCompanyProjectStatus');
    Route::get('/projectstatusonetime', 'ProjectController@postProjectStatusOneTime');

    
    Route::post('/label/delete', 'TaskController@postDeleteLabel');

    //To-do
    Route::get('/project/{seoname}/todo/{todoseoname}', 'ProjectController@getTaskDetails');
    Route::get('/project/{seoname}/todolist/{labelseoname}/todo/{todoseoname}', 'ProjectController@getTaskDetails');
    Route::get('/project/{seoname}/discussion/{todoseoname}', 'ProjectController@getTaskDetails');
    Route::get('/project/{seoname}/completed-todo', 'ProjectController@getCompletedTodo');
    Route::post('/task/save', 'TaskController@postSaveTask');
    Route::post('/task/edit', 'TaskController@postEditTask');
    Route::post('/task/complete', 'TaskController@postCompleteTask');
    Route::post('/task/ajaxlabelwtasklist', 'TaskController@getAjaxLabelWTaskList');
    Route::post('/task/ajaxtasklist', 'TaskController@getAjaxTaskList');
    Route::post('/task/ajaxtasklistwoaddtodo', 'TaskController@getAjaxTaskListWOAddTodo');
    
    Route::post('/task/ajaxmastertodo', 'TaskController@getAjaxMasterTodo');
    Route::post('/task/ajaxeditmastertodo', 'TaskController@getAjaxEditMasterTodo');
    Route::post('/task/delete', 'TaskController@postDeleteTask');
    Route::post('/task/taskassign', 'TaskController@getTaskAssign');
    Route::post('/task/assign', 'TaskController@postAssignTask');

    Route::post('/task/complete', 'TaskController@postCompleteTask');
    Route::post('/task/reopen', 'TaskController@postReOpenTask');
    Route::post('/task/movetodo', 'TaskController@postMoveTodo');
    Route::post('/task/commenthistory', 'TaskController@getCommentHistory');

    //Comment
    Route::post('/comment/discussionsave', 'TaskController@postSaveCommentWithDiscussion');
    Route::post('/comment/save', 'TaskController@postSaveComment');
    Route::post('/comment/commentedit/{id}', 'TaskController@getCommentEdit');
    Route::post('/comment/deletecomment/{cid}', 'TaskController@postDeleteComment');
    Route::post('/comment/{id}', 'TaskController@getComment');
    Route::post('/comment/update/{commentid}', 'TaskController@postUpdateComment');
    Route::post('/commentviewbulkcomment', 'TaskController@postViewCommentBulk');
    Route::post('/comment/readcomment', 'TaskController@postReadComment');

    //Download Files
    Route::get('/download/{foldername}/{filename}', 'DownloadsController@getDownload');
    Route::get('/project/download/{projectid}', 'DownloadsController@getDownloadAll');
    Route::get('/commentdownload/{commentid}', 'DownloadsController@getDownloadCommentFiles');

    //
    Route::get('/me', 'TaskController@getMe');
    Route::post('/me/ajaxpendingtodolist', 'TaskController@getAjaxPendingTodoList');
});



//Invoice as on 09-06-2019
Route::group(['middleware' => ['web']], function ()
{
    Route::get('/invoice-dashboard', 'InvoiceController@getInvoiceDashboard');
    Route::get('/invoicelist', 'InvoiceController@getInvoices');
    Route::get('/invoice/invoicelist/{id}', 'InvoiceController@getInvoiceList');
    
    Route::get('/pending-invoicelist', 'InvoiceController@getPendingInvoices');
    Route::get('/invoice/pendinginvoicelist/{id}', 'InvoiceController@getPendingInvoicelist');
    // Route::get('/invoice/receivedinvoicelist/{iid}', 'InvoiceController@getReceivedInvoicelist');
    // Route::get('/received-invoicelist', 'InvoiceController@getReceivedInvoices');
    // Route::get('/invoice-details', 'InvoiceController@getInvoiceDetails');
    
    Route::get('/add-invoice', 'InvoiceController@getAddInvoice');
    Route::get('/view-invoice/{invoiceid}', 'InvoiceController@getViewInvoice');
    Route::get('/invoice/{invoiceid}', 'InvoiceController@getEditInvoice');
    Route::get('/pending-invoice/{invoiceid}', 'InvoiceController@getEditPendingInvoice');

    Route::post('/invoice/delete', 'InvoiceController@postDeleteInvoice');
    // Route::post('/invoice/pendingdelete', 'InvoiceController@postDeletePendingInvoice');
    // Route::get('/invoice/tableline/{clientid}', 'InvoiceController@getTableLine');
    Route::post('/invoice/save', 'InvoiceController@postSaveInvoice');
    Route::post('/invoice/psave', 'InvoiceController@postSavePendingInvoice');
    Route::post('/invoice/csave', 'InvoiceController@postSaveClient');
    Route::post('/invoice/sendemail', 'InvoiceController@postSendEmail');
});
//end invoice
